--
-- PostgreSQL database dump
--

\restrict 6MI1mXOh0IInO3lbnpTavmZYQ6czEELev4XphexGEYcbcgvm6AlTxL0aA5XVwmf

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: anorectal_cases; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.anorectal_cases (
    id uuid NOT NULL,
    tenant_id uuid,
    title character varying(300) NOT NULL,
    disease_type character varying(50) NOT NULL,
    patient_info text,
    chief_complaint text,
    symptoms text,
    tongue_pulse text,
    syndrome character varying(200),
    treatment_principle text,
    formula text,
    treatment_process text,
    outcome text,
    follow_up text,
    key_points text,
    source character varying(200),
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.anorectal_cases OWNER TO zhilou_user;

--
-- Name: anorectal_formulas; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.anorectal_formulas (
    id uuid NOT NULL,
    tenant_id uuid,
    name character varying(200) NOT NULL,
    source character varying(200),
    composition jsonb NOT NULL,
    usage text,
    function text,
    indications text,
    syndrome_type character varying(100),
    disease_types jsonb NOT NULL,
    modifications text,
    formula_type character varying(30),
    notes text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.anorectal_formulas OWNER TO zhilou_user;

--
-- Name: anorectal_herbs; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.anorectal_herbs (
    id uuid NOT NULL,
    tenant_id uuid,
    name character varying(100) NOT NULL,
    pinyin character varying(100),
    category character varying(50),
    properties text,
    meridians jsonb NOT NULL,
    effects text,
    indications text,
    contraindications text,
    dosage character varying(100),
    usage_notes text,
    is_common boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.anorectal_herbs OWNER TO zhilou_user;

--
-- Name: bill_items; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.bill_items (
    id uuid NOT NULL,
    bill_id uuid NOT NULL,
    charge_item_id uuid,
    name character varying(200) NOT NULL,
    category character varying(50),
    unit character varying(20) NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.bill_items OWNER TO zhilou_user;

--
-- Name: bill_payments; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.bill_payments (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    bill_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_method character varying(30) NOT NULL,
    reference_no character varying(100),
    notes text,
    created_by uuid,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.bill_payments OWNER TO zhilou_user;

--
-- Name: bills; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.bills (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    consultation_id uuid,
    bill_no character varying(50) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    discount_amount numeric(10,2) NOT NULL,
    paid_amount numeric(10,2) NOT NULL,
    status character varying(20) NOT NULL,
    notes text,
    created_by uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.bills OWNER TO zhilou_user;

--
-- Name: charge_items; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.charge_items (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    category character varying(50) NOT NULL,
    unit character varying(20) NOT NULL,
    price numeric(10,2) NOT NULL,
    description text,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.charge_items OWNER TO zhilou_user;

--
-- Name: consultations; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.consultations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    doctor_id uuid NOT NULL,
    disease_type character varying(50),
    chief_complaint text,
    symptoms jsonb NOT NULL,
    tongue text,
    pulse text,
    diagnosis text,
    syndrome text,
    treatment_principle text,
    treatment text,
    prescription_text text,
    symptom_score integer,
    status character varying(20) NOT NULL,
    images jsonb NOT NULL,
    ai_analysis jsonb NOT NULL,
    physical_exam jsonb NOT NULL,
    four_examinations jsonb,
    selected_symptoms jsonb,
    syndrome_result jsonb,
    formula_modifications text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.consultations OWNER TO zhilou_user;

--
-- Name: COLUMN consultations.four_examinations; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.consultations.four_examinations IS '四诊数据结构化存储';


--
-- Name: COLUMN consultations.selected_symptoms; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.consultations.selected_symptoms IS '用户选择的症状';


--
-- Name: COLUMN consultations.syndrome_result; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.consultations.syndrome_result IS '辨证结果及置信度';


--
-- Name: COLUMN consultations.formula_modifications; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.consultations.formula_modifications IS '加减化裁说明';


--
-- Name: daily_revenue; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.daily_revenue (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    date date NOT NULL,
    total_revenue numeric(12,2) NOT NULL,
    cash_amount numeric(12,2) NOT NULL,
    wechat_amount numeric(12,2) NOT NULL,
    alipay_amount numeric(12,2) NOT NULL,
    card_amount numeric(12,2) NOT NULL,
    insurance_amount numeric(12,2) NOT NULL,
    bill_count integer NOT NULL,
    patient_count integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.daily_revenue OWNER TO zhilou_user;

--
-- Name: diagnosis_records; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.diagnosis_records (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    consultation_id uuid,
    disease_type character varying(50) NOT NULL,
    selected_symptoms jsonb NOT NULL,
    syndrome_result jsonb NOT NULL,
    primary_syndrome_code character varying(50),
    primary_syndrome_name character varying(100),
    confidence double precision,
    selected_formula character varying(200),
    formula_modifications text,
    efficacy_rating integer,
    efficacy_notes text,
    follow_up_date timestamp with time zone,
    doctor_notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.diagnosis_records OWNER TO zhilou_user;

--
-- Name: COLUMN diagnosis_records.tenant_id; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.tenant_id IS '租户ID';


--
-- Name: COLUMN diagnosis_records.patient_id; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.patient_id IS '患者ID';


--
-- Name: COLUMN diagnosis_records.consultation_id; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.consultation_id IS '就诊记录ID';


--
-- Name: COLUMN diagnosis_records.disease_type; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.disease_type IS '病种';


--
-- Name: COLUMN diagnosis_records.selected_symptoms; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.selected_symptoms IS '选择的症状（完整四诊数据）';


--
-- Name: COLUMN diagnosis_records.syndrome_result; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.syndrome_result IS '辨证结果（完整返回数据）';


--
-- Name: COLUMN diagnosis_records.primary_syndrome_code; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.primary_syndrome_code IS '主证型代码';


--
-- Name: COLUMN diagnosis_records.primary_syndrome_name; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.primary_syndrome_name IS '主证型名称';


--
-- Name: COLUMN diagnosis_records.confidence; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.confidence IS '置信度';


--
-- Name: COLUMN diagnosis_records.selected_formula; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.selected_formula IS '选用的方剂';


--
-- Name: COLUMN diagnosis_records.formula_modifications; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.formula_modifications IS '加减化裁内容';


--
-- Name: COLUMN diagnosis_records.efficacy_rating; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.efficacy_rating IS '疗效评分 1-5分';


--
-- Name: COLUMN diagnosis_records.efficacy_notes; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.efficacy_notes IS '疗效说明';


--
-- Name: COLUMN diagnosis_records.follow_up_date; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.follow_up_date IS '复诊日期';


--
-- Name: COLUMN diagnosis_records.doctor_notes; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.doctor_notes IS '医生备注';


--
-- Name: COLUMN diagnosis_records.created_by; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.diagnosis_records.created_by IS '创建人（医生ID）';


--
-- Name: external_treatment_records; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.external_treatment_records (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    consultation_id uuid,
    treatment_id uuid NOT NULL,
    treatment_name character varying(200) NOT NULL,
    treatment_type character varying(30) NOT NULL,
    usage_instruction text,
    prescribed_date timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.external_treatment_records OWNER TO zhilou_user;

--
-- Name: external_treatments; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.external_treatments (
    id uuid NOT NULL,
    tenant_id uuid,
    name character varying(200) NOT NULL,
    treatment_type character varying(30) NOT NULL,
    composition jsonb NOT NULL,
    preparation text,
    usage text NOT NULL,
    frequency character varying(100),
    duration character varying(100),
    function text,
    indications text,
    syndrome_types jsonb NOT NULL,
    disease_types jsonb NOT NULL,
    contraindications text,
    precautions text,
    source character varying(200),
    priority integer NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.external_treatments OWNER TO zhilou_user;

--
-- Name: followups; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.followups (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    consultation_id uuid,
    doctor_id uuid NOT NULL,
    scheduled_date timestamp with time zone NOT NULL,
    actual_date timestamp with time zone,
    status character varying(20) NOT NULL,
    symptom_score integer,
    notes text,
    recovery_status character varying(50),
    images jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.followups OWNER TO zhilou_user;

--
-- Name: images; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.images (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    consultation_id uuid,
    patient_id uuid NOT NULL,
    file_path text NOT NULL,
    file_name character varying(255),
    file_size integer,
    image_type character varying(30) NOT NULL,
    stage character varying(20) NOT NULL,
    ai_result jsonb NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.images OWNER TO zhilou_user;

--
-- Name: medical_cases; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.medical_cases (
    id uuid NOT NULL,
    tenant_id uuid,
    case_number character varying(50) NOT NULL,
    case_title character varying(200) NOT NULL,
    source character varying(100),
    case_date date,
    patient_info jsonb,
    inspection jsonb,
    auscultation jsonb,
    inquiry jsonb,
    palpation jsonb,
    disease_type character varying(50) NOT NULL,
    syndrome_analysis text,
    syndrome_type character varying(100),
    treatment_principle character varying(200),
    internal_formula jsonb,
    external_treatment jsonb,
    other_treatments text,
    follow_ups jsonb,
    outcome character varying(50),
    outcome_notes text,
    key_points text,
    teaching_notes text,
    tags jsonb,
    is_classic boolean,
    difficulty_level integer,
    view_count integer,
    reference_count integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.medical_cases OWNER TO zhilou_user;

--
-- Name: medicine_batches; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.medicine_batches (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    medicine_id uuid NOT NULL,
    batch_no character varying(100) NOT NULL,
    quantity integer NOT NULL,
    remaining_quantity integer NOT NULL,
    purchase_price numeric(10,2),
    production_date date,
    expiry_date date,
    supplier character varying(200),
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.medicine_batches OWNER TO zhilou_user;

--
-- Name: medicines; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.medicines (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    pinyin character varying(100),
    category character varying(50),
    specification character varying(100),
    unit character varying(20) NOT NULL,
    purchase_price numeric(10,2),
    selling_price numeric(10,2),
    stock_quantity integer NOT NULL,
    min_stock integer NOT NULL,
    max_stock integer NOT NULL,
    supplier character varying(200),
    storage_condition character varying(100),
    is_active boolean NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.medicines OWNER TO zhilou_user;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.patients (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    gender character varying(10),
    age integer,
    phone character varying(20),
    id_card character varying(20),
    doctor_id uuid,
    medical_history text,
    allergies text,
    tags jsonb NOT NULL,
    occupation character varying(100),
    address text,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.patients OWNER TO zhilou_user;

--
-- Name: prescriptions; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.prescriptions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    consultation_id uuid,
    patient_id uuid NOT NULL,
    doctor_id uuid NOT NULL,
    formula_name character varying(200),
    medicines jsonb NOT NULL,
    dosage_instructions text,
    duration_days integer NOT NULL,
    notes text,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.prescriptions OWNER TO zhilou_user;

--
-- Name: prevention_guides; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.prevention_guides (
    id uuid NOT NULL,
    tenant_id uuid,
    disease_type character varying(50) NOT NULL,
    title character varying(200) NOT NULL,
    prevention_points jsonb NOT NULL,
    dietary_advice text,
    lifestyle_advice text,
    exercise_advice text,
    postop_care text,
    acupuncture_points jsonb NOT NULL,
    sitz_bath_formula text,
    warning_signs jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.prevention_guides OWNER TO zhilou_user;

--
-- Name: safety_rules; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.safety_rules (
    id uuid NOT NULL,
    rule_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    herb_name character varying(100),
    conflicting_herbs jsonb,
    contraindication_info jsonb,
    max_dosage double precision,
    warning_message text NOT NULL,
    suggestion text,
    is_active integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.safety_rules OWNER TO zhilou_user;

--
-- Name: COLUMN safety_rules.rule_type; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.rule_type IS '规则类型：incompatibility/pregnancy/dosage/allergy';


--
-- Name: COLUMN safety_rules.severity; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.severity IS '严重程度：critical/warning/info';


--
-- Name: COLUMN safety_rules.herb_name; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.herb_name IS '中药名称';


--
-- Name: COLUMN safety_rules.conflicting_herbs; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.conflicting_herbs IS '相冲突药物列表（十八反十九畏）';


--
-- Name: COLUMN safety_rules.contraindication_info; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.contraindication_info IS '禁忌信息';


--
-- Name: COLUMN safety_rules.max_dosage; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.max_dosage IS '最大剂量（克/日）';


--
-- Name: COLUMN safety_rules.warning_message; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.warning_message IS '警告信息';


--
-- Name: COLUMN safety_rules.suggestion; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.suggestion IS '建议';


--
-- Name: COLUMN safety_rules.is_active; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.safety_rules.is_active IS '是否启用';


--
-- Name: stock_alerts; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.stock_alerts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    medicine_id uuid NOT NULL,
    alert_type character varying(30) NOT NULL,
    message text,
    is_resolved boolean NOT NULL,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.stock_alerts OWNER TO zhilou_user;

--
-- Name: stock_transactions; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.stock_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    medicine_id uuid NOT NULL,
    batch_id uuid,
    transaction_type character varying(20) NOT NULL,
    quantity integer NOT NULL,
    reason character varying(200),
    reference_id uuid,
    operator_id uuid,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.stock_transactions OWNER TO zhilou_user;

--
-- Name: symptom_dictionary; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.symptom_dictionary (
    id uuid NOT NULL,
    category character varying(50) NOT NULL,
    subcategory character varying(50),
    name character varying(100) NOT NULL,
    display_name character varying(100),
    options jsonb,
    weight integer,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.symptom_dictionary OWNER TO zhilou_user;

--
-- Name: COLUMN symptom_dictionary.category; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_dictionary.category IS '望/闻/问/切';


--
-- Name: COLUMN symptom_dictionary.subcategory; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_dictionary.subcategory IS '主症/次症/舌诊/脉诊等';


--
-- Name: COLUMN symptom_dictionary.name; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_dictionary.name IS '症状名称';


--
-- Name: COLUMN symptom_dictionary.display_name; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_dictionary.display_name IS '显示名称';


--
-- Name: COLUMN symptom_dictionary.options; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_dictionary.options IS '选项配置：程度、性质、时机等';


--
-- Name: COLUMN symptom_dictionary.weight; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_dictionary.weight IS '辨证权重';


--
-- Name: COLUMN symptom_dictionary.description; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_dictionary.description IS '症状说明';


--
-- Name: symptom_templates; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.symptom_templates (
    id uuid NOT NULL,
    tenant_id uuid,
    created_by uuid,
    disease_type character varying(50) NOT NULL,
    syndrome_code character varying(50),
    template_name character varying(100) NOT NULL,
    description character varying(200),
    symptoms_data jsonb NOT NULL,
    template_type character varying(20),
    usage_count integer,
    is_active integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.symptom_templates OWNER TO zhilou_user;

--
-- Name: COLUMN symptom_templates.tenant_id; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.tenant_id IS '租户ID（null为系统模板）';


--
-- Name: COLUMN symptom_templates.created_by; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.created_by IS '创建人ID（个人模板）';


--
-- Name: COLUMN symptom_templates.disease_type; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.disease_type IS '病种';


--
-- Name: COLUMN symptom_templates.syndrome_code; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.syndrome_code IS '关联证型代码';


--
-- Name: COLUMN symptom_templates.template_name; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.template_name IS '模板名称';


--
-- Name: COLUMN symptom_templates.description; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.description IS '模板描述';


--
-- Name: COLUMN symptom_templates.symptoms_data; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.symptoms_data IS '症状数据（完整四诊）';


--
-- Name: COLUMN symptom_templates.template_type; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.template_type IS 'system/personal';


--
-- Name: COLUMN symptom_templates.usage_count; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.usage_count IS '使用次数';


--
-- Name: COLUMN symptom_templates.is_active; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.symptom_templates.is_active IS '是否启用';


--
-- Name: syndrome_rules; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.syndrome_rules (
    id uuid NOT NULL,
    disease_type character varying(50) NOT NULL,
    syndrome_name character varying(100) NOT NULL,
    syndrome_code character varying(50),
    required_symptoms jsonb,
    optional_symptoms jsonb,
    tongue_pulse jsonb,
    treatment_principle text NOT NULL,
    recommended_formulas jsonb,
    confidence_threshold double precision,
    modification_rules jsonb,
    priority integer,
    is_active integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.syndrome_rules OWNER TO zhilou_user;

--
-- Name: COLUMN syndrome_rules.disease_type; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.disease_type IS '病种：痔疮/肛裂/脱垂等';


--
-- Name: COLUMN syndrome_rules.syndrome_name; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.syndrome_name IS '证型名称';


--
-- Name: COLUMN syndrome_rules.syndrome_code; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.syndrome_code IS '证型代码';


--
-- Name: COLUMN syndrome_rules.required_symptoms; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.required_symptoms IS '必需症状';


--
-- Name: COLUMN syndrome_rules.optional_symptoms; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.optional_symptoms IS '可选症状';


--
-- Name: COLUMN syndrome_rules.tongue_pulse; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.tongue_pulse IS '舌脉特征';


--
-- Name: COLUMN syndrome_rules.treatment_principle; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.treatment_principle IS '治则';


--
-- Name: COLUMN syndrome_rules.recommended_formulas; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.recommended_formulas IS '推荐方剂列表';


--
-- Name: COLUMN syndrome_rules.confidence_threshold; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.confidence_threshold IS '置信度阈值';


--
-- Name: COLUMN syndrome_rules.modification_rules; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.modification_rules IS '加减规则库';


--
-- Name: COLUMN syndrome_rules.priority; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.priority IS '优先级';


--
-- Name: COLUMN syndrome_rules.is_active; Type: COMMENT; Schema: public; Owner: zhilou_user
--

COMMENT ON COLUMN public.syndrome_rules.is_active IS '是否启用';


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    plan character varying(50) NOT NULL,
    trial_end timestamp with time zone,
    contact_phone character varying(20),
    address text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.tenants OWNER TO zhilou_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: zhilou_user
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(100) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    phone character varying(20),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO zhilou_user;

--
-- Data for Name: anorectal_cases; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.anorectal_cases (id, tenant_id, title, disease_type, patient_info, chief_complaint, symptoms, tongue_pulse, syndrome, treatment_principle, formula, treatment_process, outcome, follow_up, key_points, source, created_at) FROM stdin;
27663c4c-b67f-4e70-a3ed-42244711a506	\N	实热内蕴痔疮出血案	痔疮	男，40岁	大便带血一月余	便干难解，3-4日一次，小便短赤。舌红、苔黄，脉弦数	舌红苔黄，脉弦数	实热内蕴，血热肠燥	清热止血，润肠通便	槐花散加减	槐花12克，侧柏叶10克，炒荆芥10克，枳壳10克，防风10克，生地15克，地榆10克，仙鹤草15克，麻仁9克，生甘草10克	五日后复诊，便血已止。续用前方五剂而痊愈。	\N	实热内蕴者治以清热止血为主，佐以润肠通便	临床经验	2026-08-14 12:16:51.316877+00
da2e44dd-aa96-4d33-8455-6a74be14bf44	\N	湿热下注血栓外痔案	痔疮	男，24岁	肛门肿痛三天	便干，无血，口苦，纳食欠佳。舌质红，苔黄腻，脉弦滑数	舌质红，苔黄腻，脉弦滑数	湿热下注，气滞血瘀	清热利湿，活血化瘀	五神汤加减	茯苓10克，金银花20克，牛膝10克，车前子10克，地丁15克，黄芩10克，归尾10克，赤芍10克，甘草10克。三日后疼痛减轻，改用活血散瘀汤加减	初诊三日后疼痛减轻，改方后五日痊愈。	\N	湿热瘀滞型痔疮先清热利湿，继以活血化瘀	临床经验	2026-08-14 12:16:51.316887+00
25b67049-c78b-478a-a0cb-465c4cc2d90f	\N	气血亏损产后痔疮案	痔疮	女，28岁（产后）	大便带血三个月	面色无华，神疲乏力，少气懒言，纳食差。脉细弱，舌淡白	脉细弱，舌淡白	气血亏损，气不摄血	补气益血	八珍汤	熟地15克，白芍10克，当归15克，川芎10克，党参15克，白术12克，茯苓10克，炙黄芪30克，木香10克，炙甘草6克	七日后便血已止。续服前方半个月，诸症均消。嘱服人参养荣丸巩固。	\N	产后气血两虚致便血，宜补气益血，不宜单用止血之品	临床经验	2026-08-14 12:16:51.316893+00
53ad764f-df02-40b0-bddd-3795b7722b84	\N	实热壅盛肛周脓肿消散案	肛周脓肿	男，32岁	肛旁肿胀疼痛二天	身热，口渴喜冷饮，大便秘结，小便短赤。舌质红，苔黄腻，脉弦滑数	舌质红，苔黄腻，脉弦滑数	实热壅盛，下注肛门	清泻实热，宣散郁结	内疏黄连汤加减	黄连10克，黄芩6克，大黄6克，栀子10克，桔梗6克，木香6克，槟榔6克，连翘10克，赤白芍各10克，全当归10克，甘草6克	五日后肛旁肿痛消失。继用前方三剂清余热，痊愈。	\N	肛周脓肿初期实热壅盛者，及时清泻实热可使脓肿消散，免去手术之苦	临床经验	2026-08-14 12:16:51.316903+00
4ea8cdee-3371-4574-96a9-daeae46a1d44	\N	正虚邪恋肛周脓肿溃后不收案	肛周脓肿	男，45岁	肛周脓肿切开术后两月余创口不愈	脓汁清稀，时有潮热盗汗，懒言乏力，面色无华。脉细弱，舌淡红苔薄白	脉细弱，舌淡红苔薄白	正虚邪恋，气血不足	益气补血，托里排脓	托里消毒散加味	黄芪20克，党参10克，当归10克，白芍10克，白术10克，茯苓10克，金银花15克，白芷6克，桔梗6克，皂角刺10克，甘草6克	服药十剂后创面逐渐缩小，脓汁转浓。续服二十剂，创口完全愈合。	\N	脓肿溃后久不收口者多属正虚邪恋，宜托里补虚	临床经验	2026-08-14 12:16:51.316908+00
7339aa43-fc6c-4631-a492-96c87b228fae	\N	血热肠燥肛裂案	肛裂	女，35岁	肛门疼痛伴便血半年	便干如羊粪，便时及便后肛门剧痛，持续数小时，便纸带血。舌红苔黄，脉弦数	舌红苔黄，脉弦数	血热肠燥	凉血止血，养阴润燥	凉血地黄汤	生地15克，当归10克，地榆10克，槐花10克，黄芩10克，天花粉10克，升麻6克，赤芍10克，甘草6克	服药七剂后疼痛明显减轻，大便转软。续服十剂，肛裂愈合。	\N	肛裂多因大便干燥所致，治疗当润肠通便为先	临床经验	2026-08-14 12:16:51.316912+00
1dd3853d-ed5f-4f31-b900-365c75462c2e	\N	湿热下注肛裂疼痛案	肛裂	男，42岁	肛门疼痛三月	便时肛门剧痛难忍，便后持续疼痛，坐立不安。口苦，小便黄。舌质红，苔黄腻，脉滑数	舌质红，苔黄腻，脉滑数	湿热下注	活血祛风，清热利湿	止痛如神汤	秦艽10克，桃仁10克，皂角子6克，苍术10克，防风10克，黄柏10克，当归10克，泽泻10克，大黄6克（后下），槟榔10克，甘草6克	服药五剂疼痛大减，十剂后基本无痛。配合温水坐浴，一月后裂口愈合。	\N	肛裂疼痛剧烈者用止痛如神汤，配合外治法效果更佳	临床经验	2026-08-14 12:16:51.316915+00
dfaabbe0-7669-4618-bb4d-3300f99e76aa	\N	湿热下注肛门湿疹案	肛门疣赘	男，38岁	肛门瘙痒伴赘皮半年	肛门潮湿瘙痒，局部皮肤肥厚，小便黄赤。舌红苔黄腻，脉滑数	舌红苔黄腻，脉滑数	湿热下注	清热利湿	萆薢渗湿汤	萆薢10克，苡仁15克，黄柏10克，赤茯苓10克，丹皮10克，泽泻10克，通草6克，滑石10克（包煎）	服药十剂后瘙痒明显减轻，湿疹消退。续服半月，诸症消失。	\N	肛门湿疹多属湿热下注，治以清热利湿为主	临床经验	2026-08-14 12:16:51.31692+00
9606d69c-3d2d-4e25-b29a-20c5ad87f3d7	\N	肝肾阴虚肛门瘙痒案	肛门疣赘	女，50岁	肛门瘙痒三年	夜间瘙痒尤甚，伴腰膝酸软，头晕耳鸣，口干。舌红少苔，脉细数	舌红少苔，脉细数	肝肾阴虚	滋补肝肾	杞菊地黄汤	熟地15克，山萸肉15克，山药12克，泽泻12克，茯苓12克，丹皮12克，枸杞子15克，菊花12克	服药二十剂后瘙痒大减，腰膝酸软改善。继服一月，瘙痒消失。	\N	顽固性肛门瘙痒日久者多属阴虚，宜滋补肝肾	临床经验	2026-08-14 12:16:51.316924+00
34673176-ba26-4e9e-92e3-7509bb8f52ff	\N	热毒蕴结肛门疖肿案	肛门疖肿	男，28岁	肛旁红肿疼痛三天	局部红肿灼热，触痛明显，伴发热。舌红苔黄，脉数	舌红苔黄，脉数	热毒蕴结	清热解毒	五味消毒饮	金银花20克，野菊花15克，蒲公英15克，紫地丁15克，天葵子10克	服药三剂后红肿消退，疼痛减轻。续服五剂，疖肿消散。	\N	肛门疖肿初起用五味消毒饮清热解毒可使其消散	临床经验	2026-08-14 12:16:51.316927+00
e7453f82-6be5-4825-a672-418ea6b4b242	\N	湿热搏结肛门疖肿案	肛门疖肿	男，40岁	肛旁反复生疖半年	局部红肿反复发作，伴口苦口黏，小便黄。舌红苔黄腻，脉滑数	舌红苔黄腻，脉滑数	湿热搏结	清热利湿	黄芩滑石汤加减	黄芩15克，茯苓10克，木通6克，猪苓10克，泽泻10克，苡仁20克，滑石15克，甘草10克	服药十五剂后疖肿不再复发，湿热症状消失。随访半年未复发。	\N	反复发作的肛门疖肿多属湿热内蕴，治以清热利湿	临床经验	2026-08-14 12:16:51.316931+00
f3e211af-136a-4264-9fa0-0f18de37bdfe	\N	气虚下陷小儿直肠脱垂案	直肠脱垂	男，3.5岁	便后肛门有物脱出半年	食少，睡眠不佳，面色恍白，目睛无彩。舌淡苔少，脉象虚弱	舌淡苔少，脉象虚弱	脾肺气虚，中气下陷	补脾益肺，升提固涩	补中益气汤加减	黄芪15克，党参10克，白术8克，当归6克，陈皮4克，升麻4克，柴胡4克，五味子5克，甘草4克	服药七剂后脱出明显减少。续服半月痊愈，随访一年未复发。	\N	小儿直肠脱垂多属气虚下陷，用补中益气汤加减	临床经验	2026-08-14 12:16:51.316934+00
6b6586ba-778f-413c-b95d-0dde858d2a88	\N	气血亏损产后脱肛案	直肠脱垂	女，29岁（产后）	产后脱肛两个月	便后脱肛需手托回纳，面色苍白，神疲乏力，头晕心悸。舌淡苔白，脉细弱	舌淡苔白，脉细弱	气血两虚	调荣养血，益气固脱	参茸提肛散	人参6克，鹿茸4克（研末冲服），炒白术8克，全当归8克，补骨脂6克，肉豆蔻4克，黄芪20克，乌梅10克，甘草3克	服药十五剂后脱肛明显减轻。续服一月，脱肛痊愈。配合提肛锻炼，随访两年未复发。	\N	产后脱肛多因气血亏损，用参茸提肛散效果显著	临床经验	2026-08-14 12:16:51.316938+00
726996c4-9c1f-4bf2-8851-fc3348234d55	\N	脾肾阳虚老年脱肛案	直肠脱垂	男，68岁	脱肛十年，加重半年	稍用力即脱肛，难以回纳，畏寒肢冷，腰膝酸软，小便清长。舌淡胖有齿痕，脉沉细无力	舌淡胖有齿痕，脉沉细无力	脾肾阳虚	温补脾肾，固涩提升	补中益气汤合金匮肾气丸加减	黄芪30克，党参15克，白术12克，当归10克，升麻6克，柴胡6克，熟地15克，山药12克，山萸肉10克，肉桂3克，附子6克，补骨脂10克，炙甘草6克	服药一月后脱肛明显改善，畏寒症状好转。续服两月，脱肛基本控制。	\N	老年脱肛日久多属脾肾阳虚，需温补脾肾	临床经验	2026-08-14 12:16:51.316941+00
\.


--
-- Data for Name: anorectal_formulas; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.anorectal_formulas (id, tenant_id, name, source, composition, usage, function, indications, syndrome_type, disease_types, modifications, formula_type, notes, created_at) FROM stdin;
d5893ea1-034a-4adf-9a2d-e3a648e3ca6c	\N	补中益气汤	《脾胃论》	"黄芪30克，党参15克，白术12克，当归10克，陈皮6克，升麻6克，柴胡6克，炙甘草6克"	水煎服，日服一剂	补中益气，升阳举陷	直肠脱垂，脾虚气陷型痔疮	脾虚气陷	[]	\N	\N	\N	2026-08-14 12:16:51.322045+00
937d8844-b3ca-4a48-9cb5-1ebea1ac822a	\N	内疏黄连汤加减	《外科正宗》加减	"黄连10克，黄芩6克，大黄6克，栀子10克，桔梗6克，木香6克，槟榔6克，连翘10克，赤白芍各10克，全当归10克，甘草6克"	水煎服，日服一剂	清泻实热，宣散郁结	肛周脓肿初起，实热壅盛	热毒蕴结	[]	\N	\N	\N	2026-08-14 12:16:51.322049+00
3d409c82-9144-42fa-a480-33ec88c21d6d	\N	青蒿鳖甲汤加减	《温病条辨》加减	"青蒿12克，鳖甲12克，柴胡10克，黄芩10克，生地15克，白芍10克，知母10克，生黄芪15克，麦冬10克"	水煎服，日服一剂	清虚热，散毒气	虚热型肛周脓肿，阴虚精亏	正虚邪恋	[]	\N	\N	\N	2026-08-14 12:16:51.322052+00
080c21e3-a39b-4047-9098-6b3935db4cae	\N	托里消毒散加味	《外科正宗》加减	"黄芪20克，党参10克，当归10克，白芍10克，白术10克，茯苓10克，金银花15克，白芷6克，桔梗6克，皂角刺10克，甘草6克"	水煎服，日服一剂	益气补血，托里排脓	肛周脓肿后期，正虚邪恋	正虚邪恋	[]	\N	\N	\N	2026-08-14 12:16:51.322056+00
5fc55df5-a092-432c-85c1-efbe50f1a8a4	\N	杞菊地黄汤	《医级》	"熟地15克，山萸肉15克，山药12克，泽泻12克，茯苓12克，丹皮12克，枸杞子15克，菊花12克"	水煎服，日服一剂	滋补肝肾	肛门疣赘，肝肾阴虚型	肝肾阴虚	[]	\N	\N	\N	2026-08-14 12:16:51.322069+00
71661167-a43b-4b65-80e4-e586f8a0496c	\N	丹栀逍遥散	《内科摘要》	"丹皮12克，栀子10克，柴胡9克，当归12克，白芍12克，白术10克，茯苓12克，甘草6克，薄荷5克，生姜3片"	水煎服，日服一剂	行气活血	肛门疣赘，气滞血瘀型	气滞血瘀	[]	\N	\N	\N	2026-08-14 12:16:51.322073+00
220ed99e-0ceb-4052-ba04-5f1d42b23480	\N	五味消毒饮	《医宗金鉴》	"金银花20克，野菊花15克，蒲公英15克，紫地丁15克，天葵子10克"	水煎服，日服一剂	清热解毒	热毒疖肿	热毒蕴结	[]	\N	\N	\N	2026-08-14 12:16:51.322076+00
a716ce7e-81c1-4599-bf90-0e1e4f6a27e0	\N	黄芩滑石汤加减	《温病条辨》加减	"黄芩15克，茯苓10克，木通6克，猪苓10克，泽泻10克，苡仁20克，滑石15克，甘草10克"	水煎服，日服一剂	清热利湿	湿热疖肿，病程日久	湿热搏结	[]	\N	\N	\N	2026-08-14 12:16:51.32208+00
46575909-3288-462a-ac54-ffea02a8d1bc	\N	黄芪健中汤加减	《金匮要略》加减	"黄芪15克，桂枝10克，白芍10克，白术10克，生姜3片，大枣7枚，陈棕炭10克，侧柏叶10克，陈皮10克，甘草6克"	水煎服，日服一剂	固气升提，止血止泻	内痔脱出严重，长期便血，消化不良，腹泻者	脾胃虚寒	[]	\N	\N	\N	2026-08-14 12:16:51.322086+00
e0079d42-d666-4b1d-b950-d04c4f171f2b	\N	四物汤合增液汤	经典方合方	"生地16克，玄参16克，赤芍10克，当归10克，麦冬10克，大腹皮10克，车前子10克，川芎6克，碧玉散20克（包）"	水煎服，每日一剂，分二次服	生津润燥，活血化瘀，消肿利湿	嵌顿痔，血虚津乏，筋脉瘀阻	血虚津乏	[]	\N	\N	\N	2026-08-14 12:16:51.322093+00
337e25c8-283e-4ec7-bd31-10df75b83f21	\N	参茸提肛散	经验方	"人参6克，鹿茸4克（研末冲服），炒白术8克，全当归8克，补骨脂6克，肉豆蔻4克，黄芪20克，乌梅10克，甘草3克"	每日一剂，水煎服	调荣养血，益气固脱	产后气血亏损引起的直肠脱垂	气血两虚	[]	\N	\N	\N	2026-08-14 12:16:51.322083+00
fe29ab11-d4fe-4089-b14f-cf607711c0e2	\N	当归连翘汤	经验方	"当归12克，连翘12克，生地12克，白芍10克，白芷6克，党参16克，白术10克，阿胶12克，甘草6克，地榆10克，乌梅10克，大枣7枚"	水煎服，每日一剂	补虚清热，和血疏风	气血亏损兼有湿热的痔疮	虚中夹实	[]	\N	\N	\N	2026-08-14 12:16:51.32209+00
25a24b50-e544-4b72-9823-9dd5d97a9513	\N	消肿止痛洗剂	经验方	"瓦松30克，五倍子30克，马齿苋30克，艾叶30克，川椒30克"	煎水1000毫升熏洗，日1-2次	消肿止痛，收敛	外痔发炎、血栓外痔、内痔脱出嵌顿、直肠脱垂及术后伤口水肿疼痛等	通用	[]	\N	fumigation	\N	2026-08-14 12:16:51.322097+00
ef2a9626-6e96-4e8c-8db2-c72ad84725b1	\N	槐花散加味（临床扩展方）	经验方；非原文证治方，保留供医师复核	"槐花12克，侧柏叶10克，炒荆芥10克，枳壳10克，防风10克，生地15克，地榆10克，仙鹤草15克，麻仁9克，生甘草10克"	水煎服，日服一剂	清热疏风，和血止血	以便秘、出血、疼痛为主的各期内痔、混合痔、炎性外痔	实热证	[]	\N	\N	\N	2026-08-14 12:16:51.32202+00
79bd2293-8676-45e8-9bb7-fa7e8c05e059	\N	地榆散加味（临床扩展方）	经验方；非原文证治方，保留供医师复核	"地榆12克，黄芩10克，黄连10克，山栀10克，槐花10克，当归12克，赤芍10克，川芎6克，甘草6克"	水煎服，日服一剂	清热凉血，活血止血	血热型痔疮出血	实热证	[]	\N	\N	\N	2026-08-14 12:16:51.322027+00
d699e9ca-7641-4ea5-994d-a148f09fa378	\N	血竭散	《沈氏尊生》	"血竭3克，大黄20克，玄明粉30克，煅自然铜30克"	水煎，每日一剂，分二次熏洗	活血定痛，清热解毒，消肿利湿	嵌顿痔，外痔肿痛	通用	[]	\N	fumigation	\N	2026-08-14 12:16:51.322107+00
4ec0ceb4-3325-4f04-b705-7aa2195864f9	\N	金黄膏	传统方	"黄柏、大黄、姜黄、白芷各60克，川朴、陈皮、苍术、南星、甘草各25克，天花粉30克，共研细末"	以茶水调和外敷或配成30%凡士林软膏敷贴，日敷2次	软坚散结，清热消肿	慢性肛周脓肿，疮疡肿毒	通用	[]	\N	external	\N	2026-08-14 12:16:51.322113+00
6b12c5b5-5ff4-41d0-b554-a90537f02616	\N	玉露膏	传统方	"芙蓉花叶，晒干研成细末，用凡士林调匀成30%软膏"	敷患处，日2次	清热解毒，消肿止痛	急性肛周脓肿外敷	通用	[]	\N	external	\N	2026-08-14 12:16:51.322117+00
b988fe10-e85d-4dd4-8c8e-1b82cc0af436	\N	九华膏	传统方	"九华膏成品"	外用纱条换药，或直接涂抹患处	祛腐生肌	肛裂，术后创面换药	通用	[]	\N	external	化腐期使用，促进创面清洁	2026-08-14 12:16:51.32212+00
f1abdaca-b17f-47e5-95ce-edddb2121ad4	\N	生肌玉红膏	传统方	"玉红膏成品"	外用换药	生肌敛疮	肛瘘术后生肌期换药，创面促进愈合	通用	[]	\N	external	生肌期使用，促进肉芽生长	2026-08-14 12:16:51.322123+00
517e3e48-254e-46f6-a058-3f79cfb1fee2	\N	九华膏（完整配方）	传统名方	"当归60克，白芷60克，甘草60克，生地60克，黄连30克，黄芩30克，黄柏30克，天花粉30克，大黄30克，血竭15克，乳香15克，没药15克，轻粉9克，麻油1000ml，黄蜡240克"	制成膏药，用纱条蘸药膏外敷或插入瘘管、创面	祛腐生肌，消肿止痛，化腐清热	肛瘘术后化腐期换药，痔疮术后创面，肛裂	通用	[]	\N	external	制作方法：1.将当归、白芷、甘草、生地、黄连、黄芩、黄柏、天花粉、大黄入麻油中浸泡3天；2.用文火煎熬至药枯，去渣；3.继续熬至滴水成珠；4.加入黄蜡溶化；5.待温度降至60度左右，加入血竭、乳香、没药、轻粉粉末，搅匀；6.倾入水中冷却，制成膏剂。化腐期使用，促进腐肉脱落，创面清洁	2026-08-14 12:16:51.322147+00
3a79b440-cf76-4d07-893f-86da9ab3210c	\N	生肌散	传统方	"煅石膏30克，煅龙骨30克，煅赤石脂30克，血竭10克，乳香10克，没药10克，冰片3克，珍珠粉3克"	共研极细末，撒于创面或调麻油外敷	生肌敛疮，收口愈伤	肛瘘、痔疮术后生肌期换药	通用	[]	\N	external	制作方法：1.石膏、龙骨、赤石脂分别煅红，冷却研细；2.乳香、没药去油研末；3.血竭、珍珠粉研细；4.冰片另研；5.各药过120目筛，混合均匀，密封保存。生肌期使用，促进肉芽生长	2026-08-14 12:16:51.32215+00
63ae7927-d808-403b-a973-23dd9980e356	\N	珍珠散	传统方	"珍珠粉10克，琥珀粉10克，血竭10克，象皮10克，煅龙骨20克，煅石膏20克，冰片2克"	共研极细末，撒于创面	收口生肌，敛疮止痛	肛瘘、痔疮术后收口期，瘢痕中心小创面久不愈合	通用	[]	\N	external	制作方法：各药分别研成极细粉末，过120目筛，混合均匀，密封保存。收口期使用，促进创面最终愈合。如瘢痕中心有小创面仍不易愈合，在排除假愈合后，外用珍珠散常可收到比较满意的效果	2026-08-14 12:16:51.322154+00
c1eb4f89-587a-4729-aad5-4fd6e6c42c9b	\N	湿疹洗剂	经验方	"马齿苋30克，赤芍15克，地榆20克，苦参30克，白鲜皮20克，明矾10克，百部80克，川椒10克"	煎水坐浴	清热利湿，活血止痒	肛门湿疹，肛门瘙痒	湿热下注	[]	\N	fumigation	\N	2026-08-14 12:16:51.322103+00
035b9ff5-b4be-4af0-b554-e8045732038f	\N	红粉纱条	传统方	"红升丹（红粉）适量，凡士林适量"	将红粉与凡士林调成糊状（比例约1:3），涂于纱条上，插入瘘管或敷于创面	提脓去腐，化管祛腐	肛瘘术后化腐期换药，促进管道腐脱	通用	[]	\N	external	制作方法：取红升丹粉末，与凡士林按1:3比例调匀成糊状，涂于无菌纱条上即可使用。周老强调：初时宜重化腐，用红粉纱条蚀管祛腐，待创面腐脱管化，则应改用生肌玉红膏换药	2026-08-14 12:16:51.322157+00
00c659f8-2ede-4d1d-a3ab-f48f49d61ded	\N	小败毒膏	传统成药	"成药制剂"	每次20克，日服2-3次	清热解毒，消肿止痛	急性肛周脓肿内服	实热证	[]	\N	\N	用于急性肛周脓肿内治	2026-08-14 12:16:51.32216+00
56e29184-b9d8-4bd7-a5c2-3dd7cd30f41f	\N	犀黄丸	传统成药	"成药制剂"	每次20克，日服2次	软坚散结，清热消肿	慢性肛周脓肿	虚热证	[]	\N	\N	用于慢性肛周脓肿，气血虚弱，正虚邪恋者	2026-08-14 12:16:51.322164+00
a3fe95dc-da96-4bb0-9e15-9857328fe677	\N	麻仁润肠丸	传统成药	"火麻仁、苦杏仁、大黄、枳实、厚朴、白芍等"	每日1-2丸，温开水送服	润肠通便	肠燥便秘，大便干结，肛裂便秘	肠燥证	[]	\N	\N	用于肛裂、痔疮便秘患者	2026-08-14 12:16:51.322167+00
fcd77220-f1b2-48c8-817d-b333a0193c20	\N	麻仁滋脾丸	传统成药	"火麻仁、白术、枳实、厚朴、大黄、白芍、陈皮等"	每日1-2丸，温开水送服	润肠通便，健脾益气	脾虚便秘	脾虚证	[]	\N	\N	用于脾虚型便秘，肛门疾病伴脾虚者	2026-08-14 12:16:51.322171+00
029a62a6-59ae-44dd-a3f4-8052a42c3485	\N	消炎痛栓	西药制剂	"吲哚美辛"	每日1-2次，每次1粒，纳入肛内	消炎止痛	新鲜肛裂，痔疮术后疼痛	通用	[]	\N	external	用于肛裂病人止痛消炎	2026-08-14 12:16:51.322174+00
7125e7d1-9795-4324-b386-d9e32ca409b2	\N	利多卡因软膏（5%）	西药制剂	"盐酸利多卡因5%"	外涂肛裂局部	局部麻醉止痛	肛裂疼痛，缓解括约肌痉挛	通用	[]	\N	external	用于减轻肛门疼痛，缓解括约肌痉挛	2026-08-14 12:16:51.322177+00
cdac5335-4924-4c88-9923-0caaeff601df	\N	布比卡因封闭液	现代药物	"0.25%布比卡因6毫升"	在病人长强穴做扇形注射，隔日一次，5次为一疗程	长效局部麻醉，解除括约肌痉挛	肛裂疼痛，括约肌痉挛	通用	[]	\N	external	用于肛裂封闭疗法，缓解疼痛和括约肌痉挛	2026-08-14 12:16:51.322187+00
94b31fbb-05d4-431f-aa96-5a179433401f	\N	内疏黄连汤	《医宗金鉴》	[{"name": "黄连", "unit": "g", "dosage": 6}, {"name": "黄芩", "unit": "g", "dosage": 10}, {"name": "栀子", "unit": "g", "dosage": 9}, {"name": "连翘", "unit": "g", "dosage": 15}, {"name": "槐花", "unit": "g", "dosage": 12}, {"name": "当归", "unit": "g", "dosage": 10}, {"name": "赤芍", "unit": "g", "dosage": 10}, {"name": "木香", "unit": "g", "dosage": 6}, {"name": "枳壳", "unit": "g", "dosage": 10}, {"name": "大黄", "note": "后下", "unit": "g", "dosage": 6}, {"name": "甘草", "unit": "g", "dosage": 6}]	水煎服，日1剂，分2-3次温服	清热除湿，活血消肿	肛门肿痛，局部灼热，便血或脓血，口苦，舌红苔黄腻，脉滑数	\N	[]	脓肿：加金银花20g、蒲公英15g；便秘：重用大黄10g；肿痛剧烈：加延胡索10g、乳香6g	\N	周济民常用此方治疗急性期湿热证	2026-08-14 12:16:54.072581+00
3142efe0-905f-475b-9d91-395e3537badb	\N	封闭注射液（亚甲兰地卡因）	经验方	"亚甲兰0.26克，地卡因0.2克，蒸馏水加至100毫升"	局部封闭，每次5-10毫升，每周1-2次	局部麻醉，缓解痉挛，止痛	肛裂疼痛，括约肌痉挛	通用	[]	\N	external	制作：按比例配制，高压灭菌，分装。用于肛裂局部封闭治疗	2026-08-14 12:16:51.322181+00
acfa413f-74e6-4a69-9788-cd669484073d	\N	复方痔疮栓	经验方	"地榆粉20克，黄柏10克，次没食子酸铋10克，仙鹤草素6片，地卡因0.7克，冰片0.7克，栓剂基质100克，做成肛门栓70枚"	每晚临睡前纳入肛内1-2枚	消炎、止血、止痛	内痔出血、肛窦炎、肛裂出血疼痛	通用	[]	\N	external	\N	2026-08-14 12:16:51.322193+00
4d014139-705a-4f67-a17d-ad3c19f5d7ef	\N	参蚧散	原文·处方（原文第384行）	[{"name": "人参", "unit": "g", "dosage": 3}, {"name": "蛤蚧", "unit": "g", "dosage": 3}]	人参、蛤蚧各3克，分2次冲服。	补肾纳气，温阳固脱	直肠脱垂肾虚不固型：腰膝酸软、消化不良、身寒肢冷、尿频、体倦无力。	肾虚不固	["直肠脱垂"]	\N	internal	\N	2026-08-14 12:16:56.984392+00
8afb2505-b683-4075-8ff6-ad7f29e846ca	\N	三妙丸	经典方（周氏用于肛门瘙痒中气下陷之兼湿热者）	[{"name": "黄柏", "unit": "g", "dosage": 12}, {"name": "苍术", "unit": "g", "dosage": 12}, {"name": "牛膝", "unit": "g", "dosage": 10}]	水煎服，日服一剂。	清热燥湿	湿热下注之肛门瘙痒、下肢痿痹。周氏以补中益气丸合三妙丸化裁治顽固肛门瘙痒。	湿热下注	["肛门湿疹"]	\N	internal	\N	2026-08-14 12:16:58.366911+00
923917a9-d4b6-4b3d-9007-ff1bf55c7caa	\N	补中益气汤·痔疮气血亏损	原文·证治方（原文第146行）	[{"name": "黄芪", "unit": "g", "dosage": 15}, {"name": "党参", "unit": "g", "dosage": 10}, {"name": "白术", "unit": "g", "dosage": 10}, {"name": "柴胡", "unit": "g", "dosage": 10}, {"name": "陈皮", "unit": "g", "dosage": 10}, {"name": "升麻", "unit": "g", "dosage": 12}, {"name": "当归", "unit": "g", "dosage": 10}, {"name": "甘草", "unit": "g", "dosage": 10}]	水煎服，日服一剂。	补气益血，升提中气	痔疮气血亏损型：便血日久、面色无华、气短心悸、少气懒言、肛门坠重、痔脱难收。	气血两虚	["痔疮"]	\N	internal	\N	2026-08-14 12:16:56.989151+00
954d4d54-63ca-4de0-9fee-6447c8851f78	\N	归脾汤加味（临床扩展方）	《济生方》加减；非原文证治方，保留供医师复核	"人参10克，黄芪10克，白术10克，茯苓10克，枣仁10克，龙眼肉10克，远志10克，木香6克，甘草6克，灶心土80克，升麻10克"	水煎服，日服一剂	益气健脾，补血止血	脾虚不摄型痔疮出血	虚寒证	[]	\N	\N	\N	2026-08-14 12:16:51.322038+00
84822d66-1326-4f51-9b98-c0974b3e7605	\N	补中益气汤·脱垂中气下陷	原文·验案处方（原文第377行）	[{"name": "蜜炙黄芪", "unit": "g", "dosage": 20}, {"name": "太子参", "unit": "g", "dosage": 20}, {"name": "全当归", "unit": "g", "dosage": 6}, {"name": "升麻", "unit": "g", "dosage": 6}, {"name": "炒白术", "unit": "g", "dosage": 3}, {"name": "陈皮", "unit": "g", "dosage": 6}, {"name": "炙甘草", "unit": "g", "dosage": 6}, {"name": "柴胡", "unit": "g", "dosage": 3}, {"name": "生姜", "unit": "片", "dosage": 3}, {"name": "大枣", "unit": "枚", "dosage": 2}]	水煎服；小儿剂量须按体重与年龄由医师酌定，不可照搬成人。	补中益气，升阳举陷	直肠脱垂中气下陷/小儿气血未壮型：便时脱出、面色晄白、食少便溏、脉虚弱。	中气下陷	["直肠脱垂"]	\N	internal	\N	2026-08-14 12:16:56.990322+00
8affb16d-81be-43be-9828-6fd8ca6ecec3	\N	八珍汤（临床扩展方）	《正体类要》；非原文证治方，保留供医师复核	"熟地15克，白芍10克，当归15克，川芎10克，党参15克，白术12克，茯苓10克，炙黄芪30克，木香10克，炙甘草6克"	水煎服，日服一剂	补气益血	气血亏损型痔疮，便血日久	气血亏损型	[]	\N	\N	\N	2026-08-14 12:16:51.322041+00
036c9606-9847-4855-a60a-ac7f52767503	\N	五神汤加味（临床扩展方）	经验方；非原文证治方，保留供医师复核	"茯苓10克，金银花20克，牛膝10克，车前子10克，地丁15克，黄芩10克，归尾10克，赤芍10克，甘草10克"	水煎服，日服一剂	清热利湿，活血化瘀	湿热瘀滞型痔疮、血栓外痔、嵌顿性内痔	湿热瘀滞型	[]	\N	\N	\N	2026-08-14 12:16:51.322031+00
2cf04181-e7d8-4193-bc9a-6693e01de22a	\N	熏洗方（通用）	经验方	"朴硝30克，马齿苋20克，瓦松15克，归尾15克，赤芍15克，黄柏15克，苍术15克"	煎水约1000毫升，趁热先熏后洗，或浸布湿敷于患处，每日2-3次坐浴	清热解毒，活血祛瘀，利湿软坚，消肿止痛	痔瘘、肛痈炎症期，肛裂便后疼痛，以及全身所患之痈、疽、疔、疖属于急性期炎症者	通用	[]	\N	fumigation	\N	2026-08-14 12:16:51.3221+00
0e13cdbd-1176-4996-b93a-caba6366e577	\N	四黄膏	经验方	"黄连、黄芩、黄柏、栀子各等份，共研细末。凡士林70克，四黄粉30克，共同混合调匀成膏"	外敷患处	清热消肿，凉血止痛	内痔、外痔发炎、水肿、术后疼痛，痈、疽、疔、疖红肿	通用	[]	\N	external	\N	2026-08-14 12:16:51.32211+00
a917356a-5f0b-4c74-bca7-60c81c569f3a	\N	化腐生肌散	经验方	"红粉5克，珠砂10克，石膏15克，乳香10克，没药10克"	共研细末，调成糊状，以棉纸做成条，蘸药后插入瘘道中，每日2次	化腐生肌，托里透毒	肛瘘保守治疗，瘘道换药	通用	[]	\N	external	\N	2026-08-14 12:16:51.322126+00
663754bd-23e6-40cb-a250-bb0d6644d00c	\N	收肛散	经验方	"收敛固脱药物组成"	外敷，配合纱布垫加压固定	收敛固脱，消肿利湿	直肠脱垂外用	通用	[]	\N	external	\N	2026-08-14 12:16:51.32213+00
0f8464ff-bdff-426b-8149-39c1516daa4e	\N	无砒枯痔散	1955年改良	"白矾30克，雄黄15克，乳香15克，没药15克，儿茶15克，冰片3克"	共研极细末，用时取适量药末塞入痔核根部，7-10天换药一次	枯痔化痔，使痔核坏死脱落	I-II期内痔	通用	[]	周老1955年改进传统枯痔散，去掉剧毒白砒，避免砒中毒，使病人痛苦大大减轻，且治愈后不易复发	external	制作：各药分别研细末，过120目筛，混合均匀，密封保存。使用时需严格掌握适应症，操作规范，避免药物进入肛管粘膜造成损伤	2026-08-14 12:16:51.322133+00
a0240390-ea3f-47e8-b5bb-a02760eae66b	\N	二矾枯痔锭	经验方	"明矾（枯矾）40克，胆矾10克，乳香10克，没药10克，冰片2克"	共研细末，加黄蜡适量制成锭剂，每锭约2克。用时将药锭塞入痔核基底部，每周1次	枯痔收敛，化腐止血	I-II期内痔出血	通用	[]	\N	external	制作方法：1.明矾入锅炒至枯白，冷却研末；2.胆矾研细末；3.乳香、没药去油研末；4.冰片研细；5.黄蜡隔水溶化；6.将各药末混合均匀，趁热与黄蜡调和，制成锭状，冷却后密封保存。使用时用改制的枯痔锭投药器推送	2026-08-14 12:16:51.322137+00
d4708552-c697-456a-9712-50af565f0d96	\N	明矾注射液（4%）	1959年首创	"明矾4克，注射用水100ml"	用于注射治疗I-II期内痔。每个痔核注射2-4ml，每周1次	收敛固脱，使痔核硬化萎缩	I-II期内痔	通用	[]	\N	external	制作：1.取明矾4g，加注射用水至100ml；2.加热溶解，过滤；3.高压灭菌；4.分装安瓿。注射方法：在痔核基底部粘膜下注射，使粘膜隆起成丘状。周老1959年首先采用此法，为后来理想注射疗法奠定基础	2026-08-14 12:16:51.32214+00
e913634d-7f91-407a-bfb7-1206200c65ad	\N	明矾注射液（6%）	经验方	"明矾6克，注射用水100ml"	用于治疗成人完全性直肠脱垂。直肠粘膜下多点注射	收敛固脱，使粘膜下组织纤维化粘连	成人完全性直肠脱垂	通用	[]	根据'酸可收敛、涩可固脱'理论，周老从反复临床试验中总结出治疗直肠脱垂的新方法。1981年通过部级鉴定，全愈率99.5%，无直肠狭窄、性功能障碍等后遗症	external	制作同4%明矾液。注射方法：在脱出的直肠粘膜下分点注射，每点2-3ml，使粘膜隆起，总量20-40ml。注射后局部加压包扎，卧床休息	2026-08-14 12:16:51.322143+00
c092fbe7-ba57-4e82-8e8d-878232f392cf	\N	黄芪建中汤加味	《金匮要略》加减	[{"name": "黄芪", "unit": "g", "dosage": 30}, {"name": "桂枝", "unit": "g", "dosage": 9}, {"name": "白芍", "unit": "g", "dosage": 18}, {"name": "生姜", "unit": "g", "dosage": 9}, {"name": "大枣", "unit": "g", "dosage": 12}, {"name": "饴糖", "note": "烊化", "unit": "g", "dosage": 30}, {"name": "升麻", "unit": "g", "dosage": 6}, {"name": "柴胡", "unit": "g", "dosage": 6}, {"name": "枳壳", "unit": "g", "dosage": 10}]	水煎服，饴糖烊化兑入，日1剂，分2次温服	温中补虚，升阳举陷	脱肛，气短乏力，面色萎黄，纳差便溏，舌淡苔白，脉细弱	\N	[]	脱垂严重：加党参15g、黄精12g；腹痛：加白术12g、炙甘草6g；腹泻：加炮姜6g、诃子10g	\N	周济民经验：脱垂患者必升阳举陷，重用黄芪，配合升麻、柴胡	2026-08-14 12:16:54.067499+00
bee03a3a-1732-4e94-beea-2e6797636d38	\N	八珍汤加味	《瑞竹堂经验方》加减	[{"name": "党参", "unit": "g", "dosage": 15}, {"name": "白术", "unit": "g", "dosage": 12}, {"name": "茯苓", "unit": "g", "dosage": 12}, {"name": "甘草", "unit": "g", "dosage": 6}, {"name": "当归", "unit": "g", "dosage": 12}, {"name": "川芎", "unit": "g", "dosage": 9}, {"name": "白芍", "unit": "g", "dosage": 12}, {"name": "熟地黄", "unit": "g", "dosage": 15}, {"name": "黄芪", "unit": "g", "dosage": 30}, {"name": "升麻", "unit": "g", "dosage": 6}, {"name": "柴胡", "unit": "g", "dosage": 6}]	水煎服，日1剂，分2次温服，连服15-20剂	益气养血，升阳举陷	脱垂严重，神疲乏力，面色苍白，心悸气短，舌淡脉细弱	\N	[]	脱垂严重：加黄精15g、肉苁蓉12g；失血过多：加阿胶10g（烊化）、龙眼肉12g；便秘：加火麻仁12g、郁李仁10g	\N	周济民强调：III度脱垂患者必用此方打底，不可单纯升提	2026-08-14 12:16:54.069625+00
d1df8b99-2ec6-4b7f-82ef-93765f8d7141	\N	地槐止血丸	经验方	"地榆炭60克，槐角120克，防风60克，黄柏60克"	共研细末，炼蜜为丸，丸重10克，每日服二丸	清利湿热，止血通便	各期痔疮出血、肛裂疼痛出血、肠风下血	通用	[]	\N	internal	制作方法：1.地榆炒炭；2.槐角炒黄；3.防风、黄柏分别炒制；4.四药共研细末，过80目筛；5.炼蜜为丸，每丸10克；6.蜡皮封装。周老经验方，临床疗效确切	2026-08-14 12:16:51.32219+00
da2ec121-b65b-429b-ae31-fa8ae3f06120	\N	凉血地黄汤	原文·证治方（原文第282行）	[{"name": "细生地", "unit": "g", "dosage": 20}, {"name": "归尾", "unit": "g", "dosage": 10}, {"name": "地榆", "unit": "g", "dosage": 15}, {"name": "槐角", "unit": "g", "dosage": 10}, {"name": "黄连", "unit": "g", "dosage": 6}, {"name": "天花粉", "unit": "g", "dosage": 15}, {"name": "生甘草", "unit": "g", "dosage": 10}, {"name": "升麻", "unit": "g", "dosage": 10}, {"name": "赤芍", "unit": "g", "dosage": 10}, {"name": "枳壳", "unit": "g", "dosage": 6}, {"name": "黄芩", "unit": "g", "dosage": 10}, {"name": "荆芥", "unit": "g", "dosage": 6}]	水煎服，日服一剂。	凉血润燥，止血止痛	肛裂火燥证/血热肠燥：大便秘结、便时出血、便后疼痛、口苦咽干、心烦。	血热肠燥	["肛裂"]	\N	internal	\N	2026-08-14 12:16:51.322059+00
7f710164-2b4c-4212-b685-0b97abf3679f	\N	止痛如神汤	原文·证治方（原文第284行）	[{"name": "秦艽", "unit": "g", "dosage": 10}, {"name": "桃仁", "unit": "g", "dosage": 10}, {"name": "皂角子", "unit": "g", "dosage": 6}, {"name": "苍术", "unit": "g", "dosage": 10}, {"name": "防风", "unit": "g", "dosage": 10}, {"name": "黄柏", "unit": "g", "dosage": 10}, {"name": "归尾", "unit": "g", "dosage": 10}, {"name": "泽泻", "unit": "g", "dosage": 10}, {"name": "槟榔", "unit": "g", "dosage": 6}, {"name": "大黄", "unit": "g", "dosage": 15}]	水煎服，日服一剂。	清热利湿，润燥止痛	肛裂湿热证：大便秘结、肛门坠胀、便后持续疼痛、偶有脓汁或黏液。	湿热下注	["肛裂"]	\N	internal	\N	2026-08-14 12:16:51.322063+00
52227216-44f5-497f-be26-73cd52ec3e31	\N	萆薢渗湿汤	原文·证治方（原文第317行）	[{"name": "萆薢", "unit": "g", "dosage": 12}, {"name": "薏苡仁", "unit": "g", "dosage": 15}, {"name": "黄柏", "unit": "g", "dosage": 10}, {"name": "赤茯苓", "unit": "g", "dosage": 12}, {"name": "丹皮", "unit": "g", "dosage": 12}, {"name": "泽泻", "unit": "g", "dosage": 12}, {"name": "滑石", "unit": "g", "dosage": 15}, {"name": "通草", "unit": "g", "dosage": 6}]	水煎服，每日一剂。	清热解毒，利湿散结	肛门疣赘湿热下注证：肛门潮湿瘙痒、疣面糜烂渗出、基底潮红、便干溲赤。	湿热下注	["肛门疣赘"]	\N	internal	\N	2026-08-14 12:16:51.322066+00
d9cc3fc7-3c2e-4db1-ae73-b9a0f2fb9115	\N	升阳除湿汤	原文·处方（原文第385行）	[{"name": "升麻", "unit": "g", "dosage": 3}, {"name": "柴胡", "unit": "g", "dosage": 6}, {"name": "防风", "unit": "g", "dosage": 9}, {"name": "麦芽", "unit": "g", "dosage": 10}, {"name": "泽泻", "unit": "g", "dosage": 6}, {"name": "苍术", "unit": "g", "dosage": 9}, {"name": "神曲", "unit": "g", "dosage": 9}, {"name": "茯苓", "unit": "g", "dosage": 12}, {"name": "甘草", "unit": "g", "dosage": 6}, {"name": "木香", "unit": "g", "dosage": 6}]	每日一剂，水煎服。	清利湿热，通便降浊，兼顾升提	直肠脱垂湿热努挣型：肛门下坠肿痛、小便淋漓、胸闷口苦口腻、脉滑数。	湿热下注	["直肠脱垂"]	\N	internal	\N	2026-08-14 12:16:56.98266+00
f3875915-593b-44a9-966e-6ebb120e630e	\N	补肾固脱散	原文·处方（原文第384-385行）	[{"name": "龙骨", "unit": "g", "dosage": 9}, {"name": "牡蛎", "unit": "g", "dosage": 9}, {"name": "诃子", "unit": "g", "dosage": 6}, {"name": "赤石脂", "unit": "g", "dosage": 6}, {"name": "熟地", "unit": "g", "dosage": 12}, {"name": "五味子", "unit": "g", "dosage": 6}, {"name": "菟丝子", "unit": "g", "dosage": 6}, {"name": "罂粟壳", "unit": "g", "dosage": 6}]	研细末冲服，每次15克，每日2次。	补肾纳气，温阳固脱	直肠脱垂肾虚不固型的收涩固脱备用方。	肾虚不固	["直肠脱垂"]	\N	internal	含罂粟壳，属麻醉药品管制品种：须医师严格掌握、中病即止、不宜久服，避免依赖与成瘾。	2026-08-14 12:16:56.986642+00
02559474-036b-4a07-b5e6-2097491ced05	\N	定喘固脱汤	原文·处方（原文第383行）	[{"name": "太子参", "unit": "g", "dosage": 20}, {"name": "黄芪", "unit": "g", "dosage": 20}, {"name": "全当归", "unit": "g", "dosage": 8}, {"name": "杭白芍", "unit": "g", "dosage": 9}, {"name": "炒白术", "unit": "g", "dosage": 10}, {"name": "炙甘草", "unit": "g", "dosage": 6}, {"name": "桑白皮", "unit": "g", "dosage": 8}, {"name": "贝母", "unit": "g", "dosage": 8}, {"name": "羌活", "unit": "g", "dosage": 6}, {"name": "肉桂", "unit": "g", "dosage": 6}, {"name": "五味子", "unit": "g", "dosage": 16}]	每日一剂，水煎服；巩固可三倍量研末炼蜜为丸，丸重9克，每日2次、每服2丸。	温肺益气，定喘固脱	直肠脱垂肺虚咳喘、肠寒脱垂型：慢性咳喘、动则气短、舌淡苔白滑、脉沉细略滑。	肺虚咳喘	["直肠脱垂"]	\N	internal	\N	2026-08-14 12:16:56.987848+00
b8b38e49-cd12-4466-a4dd-e45f293429b1	\N	润肠汤	临床扩展（非原文）	[{"name": "当归", "unit": "g", "dosage": 12}, {"name": "生地", "unit": "g", "dosage": 15}, {"name": "火麻仁", "unit": "g", "dosage": 15}, {"name": "桃仁", "unit": "g", "dosage": 10}, {"name": "枳壳", "unit": "g", "dosage": 10}]	水煎服，日服一剂。	养阴润燥，润肠通便	肛裂阴虚津亏证（系统扩展证型）：大便干燥、数日一行、裂口久不愈、口干咽燥。	阴虚津亏	["肛裂"]	\N	internal	\N	2026-08-14 12:16:56.991511+00
1428aac4-3ce7-4cb6-b10b-65e0f4655369	\N	仙方活命饮	临床扩展·经典方（非原文）	[{"name": "金银花", "unit": "g", "dosage": 20}, {"name": "白芷", "unit": "g", "dosage": 6}, {"name": "贝母", "unit": "g", "dosage": 6}, {"name": "防风", "unit": "g", "dosage": 6}, {"name": "赤芍", "unit": "g", "dosage": 10}, {"name": "当归尾", "unit": "g", "dosage": 10}, {"name": "甘草节", "unit": "g", "dosage": 6}, {"name": "皂角刺", "unit": "g", "dosage": 10}, {"name": "天花粉", "unit": "g", "dosage": 10}, {"name": "乳香", "unit": "g", "dosage": 6}, {"name": "没药", "unit": "g", "dosage": 6}, {"name": "陈皮", "unit": "g", "dosage": 6}]	水煎服，日服一剂。	清热解毒，消肿溃坚，活血止痛	肛周脓肿热毒蕴结未成脓期的经典备用方（周氏原文首选内疏黄连汤）。	热毒蕴结	["肛周脓肿"]	\N	internal	\N	2026-08-14 12:16:56.992622+00
dcbfdfee-bfaf-4ac8-af8b-11191d47b48c	\N	增液汤	经典方参考（非原文证治方）	[{"name": "玄参", "unit": "g", "dosage": 30}, {"name": "麦冬", "unit": "g", "dosage": 24}, {"name": "生地", "unit": "g", "dosage": 24}]	水煎服，日服一剂。	增液润燥，滋阴通便	津亏肠燥便秘：大便秘结、口干咽燥、舌红少津。	肠燥津亏	["便秘"]	\N	internal	\N	2026-08-14 12:16:58.359271+00
2e82144c-523a-488c-b762-efd6eeb66701	\N	大黄附子汤	经典方参考（非原文证治方）	[{"name": "大黄", "unit": "g", "dosage": 9}, {"name": "炮附子", "unit": "g", "dosage": 9}, {"name": "细辛", "unit": "g", "dosage": 3}]	水煎服，日服一剂。	温里散寒，通便止痛	寒积便秘：大便艰涩、腹冷痛、苔白、脉沉迟。	寒结	["便秘"]	\N	internal	\N	2026-08-14 12:16:58.361606+00
26a65284-e2e9-49e2-979a-90d54dbfdc5a	\N	麻子仁丸	经典方参考（非原文证治方）	[{"name": "火麻仁", "unit": "g", "dosage": 20}, {"name": "白芍", "unit": "g", "dosage": 9}, {"name": "枳实", "unit": "g", "dosage": 9}, {"name": "大黄", "unit": "g", "dosage": 12}, {"name": "厚朴", "unit": "g", "dosage": 9}, {"name": "杏仁", "unit": "g", "dosage": 10}]	蜜丸，每服9克，日1-2次。	润肠泄热，行气通便	肠胃燥热、脾约便秘：大便干结、小便频数。	胃肠热结	["便秘"]	\N	internal	\N	2026-08-14 12:16:58.362902+00
7a87e7e7-049f-4017-acdb-ff13f3384e1c	\N	黄芪汤	经典方参考（非原文证治方）	[{"name": "黄芪", "unit": "g", "dosage": 20}, {"name": "陈皮", "unit": "g", "dosage": 10}, {"name": "火麻仁", "unit": "g", "dosage": 15}, {"name": "白蜜", "unit": "g", "dosage": 30}]	水煎服，日服一剂。	益气润肠通便	气虚便秘：排便无力、汗出气短、便后乏力。	气虚便结	["便秘"]	\N	internal	\N	2026-08-14 12:16:58.364492+00
98143aef-871e-4921-aad6-2385bb26359d	\N	六磨汤	经典方参考（非原文证治方）	[{"name": "木香", "unit": "g", "dosage": 6}, {"name": "沉香", "unit": "g", "dosage": 3}, {"name": "乌药", "unit": "g", "dosage": 9}, {"name": "槟榔", "unit": "g", "dosage": 9}, {"name": "枳实", "unit": "g", "dosage": 9}, {"name": "大黄", "unit": "g", "dosage": 6}]	水煎服，日服一剂。	行气导滞通便	气滞便秘：排便不畅、腹胀嗳气、胸胁痞满。	气滞不行	["便秘"]	\N	internal	\N	2026-08-14 12:16:58.365733+00
4a984b97-8fe7-4197-babd-2c25e1d0c651	\N	当归饮子	经典方参考（非原文证治方）	[{"name": "当归", "unit": "g", "dosage": 12}, {"name": "生地", "unit": "g", "dosage": 15}, {"name": "白芍", "unit": "g", "dosage": 12}, {"name": "川芎", "unit": "g", "dosage": 6}, {"name": "何首乌", "unit": "g", "dosage": 15}, {"name": "荆芥", "unit": "g", "dosage": 6}, {"name": "防风", "unit": "g", "dosage": 6}, {"name": "白蒺藜", "unit": "g", "dosage": 10}, {"name": "黄芪", "unit": "g", "dosage": 15}, {"name": "甘草", "unit": "g", "dosage": 6}]	水煎服，日服一剂。	养血润燥，祛风止痒	血虚风燥型肛门湿疹/瘙痒：皮肤干燥肥厚、入夜痒甚、面色无华。	血虚风燥	["肛门湿疹"]	\N	internal	\N	2026-08-14 12:16:58.368084+00
47121ee5-3e07-4cc7-9cee-b39d296f4714	\N	槐花散加味	原文·证治方（原文第132行）	[{"name": "槐花", "unit": "g", "dosage": 12}, {"name": "侧柏叶", "unit": "g", "dosage": 10}, {"name": "炒荆芥", "unit": "g", "dosage": 10}, {"name": "枳壳", "unit": "g", "dosage": 10}, {"name": "防风", "unit": "g", "dosage": 10}, {"name": "生地", "unit": "g", "dosage": 10}, {"name": "地榆", "unit": "g", "dosage": 10}, {"name": "仙鹤草", "unit": "g", "dosage": 15}, {"name": "麻仁", "unit": "g", "dosage": 9}, {"name": "生甘草", "unit": "g", "dosage": 10}]	水煎服，日服一剂（具体分服、疗程由医师审核）	清热润燥，止血通便；兼能清热疏风、和血止血	湿热内蕴、血热肠燥所致痔疮，见便秘、出血、肛门灼热疼痛；适用于内痔、混合痔、炎性外痔相应证候	周济民原著证治方	[]	原文说明可与地榆散加味交替、互相化裁；具体加减须结合复诊四诊资料	internal	原文证治方；与原文第185行医案方相比，生地剂量不同（证治方10克，医案方15克）。	2026-08-14 12:18:03.043783+00
b6557da5-963f-48f5-9189-545f4b80b92f	\N	地榆散加味	原文·证治方（原文第133行）	[{"name": "地榆", "unit": "g", "dosage": 12}, {"name": "黄芩", "unit": "g", "dosage": 10}, {"name": "黄连", "unit": "g", "dosage": 10}, {"name": "山栀", "unit": "g", "dosage": 10}, {"name": "槐花", "unit": "g", "dosage": 10}, {"name": "当归", "unit": "g", "dosage": 12}, {"name": "赤小豆", "unit": "g", "dosage": 15}, {"name": "丹皮", "unit": "g", "dosage": 10}, {"name": "甘草", "unit": "g", "dosage": 6}]	水煎服，日服一剂（具体分服、疗程由医师审核）	清热凉血，止血和血	实热证、湿热内蕴、血热肠燥所致痔疮便血、肛门灼热疼痛	周济民原著证治方	[]	原文说明可与槐花散加味交替、互相化裁；具体加减须结合复诊四诊资料	internal	原文证治方。数据库中的赤芍、川芎版本另标为医案/临床扩展方，不冒充原文组成。	2026-08-14 12:18:03.046439+00
60ad048a-501c-4149-a5c6-4a02c76be6b5	\N	五神汤加味	原文·证治方（原文第136行）	[{"name": "茯苓", "unit": "g", "dosage": 10}, {"name": "金银花", "unit": "g", "dosage": 20}, {"name": "牛膝", "unit": "g", "dosage": 10}, {"name": "车前子", "unit": "g", "dosage": 10}, {"name": "地丁", "unit": "g", "dosage": 15}, {"name": "黄芩", "unit": "g", "dosage": 10}, {"name": "归尾", "unit": "g", "dosage": 10}, {"name": "赤芍", "unit": "g", "dosage": 10}, {"name": "甘草", "unit": "g", "dosage": 10}]	水煎服，日服一剂（具体分服、疗程由医师审核）	清热除湿，活血化瘀	湿热瘀滞型痔疮，见腹胀纳呆、便秘溲赤、肛门坠胀疼痛、红肿结节不散；包括血栓外痔、静脉曲张性外痔、嵌顿性内痔相应证候	周济民原著证治方	[]	原文说明可与活血散瘀汤交替、互相加减；热象退而瘀滞存时由医师复诊决定转方	internal	原文证治方；牛夕按现代药名规范记为牛膝，归尾即当归尾。	2026-08-14 12:18:03.048147+00
6cf4bf71-3b71-4f15-91c7-e98fb42d4e50	\N	活血散瘀汤（临床扩展方）	经验方；非原文证治方，保留供医师复核	"桃仁10克，红花6克，当归10克，赤芍10克，丹皮10克，乌药10克，枳实6克，泽泻10克，大黄6克（后下）"	水煎服，日服一剂	活血化瘀，行气止痛	气滞血瘀型痔疮	气滞血瘀型	[]	\N	\N	\N	2026-08-14 12:16:51.322034+00
d6d23f27-6db8-42c2-8cad-ec8d2aa496e2	\N	活血散瘀汤	原文·证治方（原文第137行）	[{"name": "归尾", "unit": "g", "dosage": 10}, {"name": "赤芍", "unit": "g", "dosage": 10}, {"name": "桃仁", "unit": "g", "dosage": 10}, {"name": "大黄", "unit": "g", "dosage": 10}, {"name": "川芎", "unit": "g", "dosage": 10}, {"name": "丹皮", "unit": "g", "dosage": 10}, {"name": "枳壳", "unit": "g", "dosage": 10}, {"name": "瓜蒌仁", "unit": "g", "dosage": 10}, {"name": "槟榔", "unit": "g", "dosage": 10}]	水煎服，日服一剂（大黄后下等炮制方法由医师审核）	清利湿热，消除瘀滞，活血行气	湿热瘀滞型痔疮，尤其血栓外痔、静脉曲张性外痔、嵌顿性内痔；常用于热象减轻而瘀滞未消的复诊阶段	周济民原著证治方	[]	原文说明可与五神汤加味交替、互相加减；原文医案第193行为复诊加减方，须单独复核	internal	原文证治方；与数据库原有活血化瘀扩展版药味不同，扩展版另存为临床扩展方。	2026-08-14 12:18:03.049803+00
9b5465d1-f9a0-4ed9-802c-81727b52044a	\N	归脾汤加味	原文·证治方（原文第140行）	[{"name": "人参", "unit": "g", "dosage": 10}, {"name": "黄芪", "unit": "g", "dosage": 10}, {"name": "白术", "unit": "g", "dosage": 10}, {"name": "茯苓", "unit": "g", "dosage": 10}, {"name": "枣仁", "unit": "g", "dosage": 10}, {"name": "龙眼肉", "unit": "g", "dosage": 10}, {"name": "远志", "unit": "g", "dosage": 10}, {"name": "木香", "unit": "g", "dosage": 6}, {"name": "甘草", "unit": "g", "dosage": 6}, {"name": "灶心土", "unit": "g", "dosage": 80}, {"name": "升麻", "unit": "g", "dosage": 10}]	水煎服，日服一剂；灶心土按医师要求煎汤代水	健脾温中，固脱止血	虚寒证痔疮，见身倦神疲、面色晄白、便稀、小便清长、食少腹胀、内痔脱出及晦暗便血	周济民原著证治方	[]	原文说明可与黄芪建中汤加减交替；长期便血、脱出或腹泻需复诊调整	internal	原文证治方。数据库中的党参、地榆、槐花等版本另标为临床扩展方。	2026-08-14 12:18:03.051464+00
c498010d-35e2-43c9-aebd-0a02318157d2	\N	黄芪建中汤加减	原文·证治方（原文第141行）	[{"name": "黄芪", "unit": "g", "dosage": 15}, {"name": "桂枝", "unit": "g", "dosage": 10}, {"name": "白芍", "unit": "g", "dosage": 10}, {"name": "白术", "unit": "g", "dosage": 10}, {"name": "生姜", "unit": "片", "dosage": 3}, {"name": "大枣", "unit": "枚", "dosage": 7}, {"name": "陈棕炭", "unit": "g", "dosage": 10}, {"name": "侧柏叶", "unit": "g", "dosage": 10}, {"name": "陈皮", "unit": "g", "dosage": 10}, {"name": "甘草", "unit": "g", "dosage": 6}]	水煎服，日服一剂（具体分服、疗程由医师审核）	健脾温中，固气升提，止血止泻	虚寒证痔疮，内痔脱出严重、长期便血、消化不良或腹泻	周济民原著证治方	[]	原文说明可与归脾汤加味交替；白芍、生姜、大枣及陈棕炭等用量须按原文和患者情况审核	internal	原文写作“黄芪健中汤加减”，系统统一名称为“黄芪建中汤加减”；不与后续温补扩展方混同。	2026-08-14 12:18:03.052668+00
56c2bc1d-83da-4add-ba50-ddce6479ea9a	\N	八珍汤	原文·证治方（原文第145行）	[{"name": "熟地", "unit": "g", "dosage": 15}, {"name": "白芍", "unit": "g", "dosage": 10}, {"name": "当归", "unit": "g", "dosage": 10}, {"name": "川芎", "unit": "g", "dosage": 10}, {"name": "党参", "unit": "g", "dosage": 15}, {"name": "白术", "unit": "g", "dosage": 10}, {"name": "甘草", "unit": "g", "dosage": 10}]	水煎服，日服一剂（具体分服、疗程由医师审核）	补气益血	气血亏损型痔疮，便血日久、面色无华、气短心悸、肛门坠重、痔脱难收或血燥便秘	周济民原著证治方	[]	原文气血亏损型可与补中益气汤互参；原文医案第197行另为八珍汤加味，须单独复核	internal	原文证治方；与原文第197行医案加味方药味、剂量不同。	2026-08-14 12:18:03.054246+00
\.


--
-- Data for Name: anorectal_herbs; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.anorectal_herbs (id, tenant_id, name, pinyin, category, properties, meridians, effects, indications, contraindications, dosage, usage_notes, is_common, created_at) FROM stdin;
334517c0-046f-44bc-9f7d-fd8e78e1dc30	\N	槐花	\N	止血药	苦，微寒	["肝", "大肠经"]	凉血止血，清肝泻火	肠风便血，痔血	脾胃虚寒者慎用	6-15克	\N	t	2026-08-14 12:16:51.329592+00
c3992387-c9a4-410f-87f4-fd25a87ebf38	\N	地榆	\N	止血药	苦酸，微寒	["肝", "大肠经"]	凉血止血，解毒敛疮	便血，痔血，血痢，疮疡	大面积烧伤不宜外用	10-15克	\N	t	2026-08-14 12:16:51.329598+00
c5f1336c-5db6-4dd8-9cb9-87d3ae3acd43	\N	侧柏叶	\N	止血药	苦涩，微寒	["肺", "肝", "大肠经"]	凉血止血，化痰止咳	各种出血证	无	10-15克	\N	t	2026-08-14 12:16:51.329602+00
48945621-d504-4c57-8530-2dbc47472024	\N	仙鹤草	\N	止血药	苦涩，平	["肺", "肝", "脾经"]	收敛止血，截疟，止痢	各种出血证	无明显禁忌	10-15克	\N	t	2026-08-14 12:16:51.329605+00
c0967ad9-93b8-42d0-a0bf-eac0840647ae	\N	槐角	\N	止血药	苦，寒	["肝", "大肠经"]	清热泻火，凉血止血	肠风便血，痔疮肿痛	脾胃虚寒者慎用	6-12克	\N	t	2026-08-14 12:16:51.329608+00
274493ca-9de9-406a-b015-4de70a10fe09	\N	黄芪	\N	补气药	甘，微温	["脾", "肺经"]	补气升阳，益卫固表，托毒生肌	脾虚气陷，直肠脱垂，气虚便血	实证、阳证疮疡不宜	15-30克	\N	t	2026-08-14 12:16:51.329612+00
c0c11e9c-61a7-4609-b919-2e2fb85a2a54	\N	党参	\N	补气药	甘，平	["脾", "肺经"]	补中益气，健脾益肺	脾肺气虚，气短乏力	实证慎用	10-15克	\N	t	2026-08-14 12:16:51.329615+00
4ce36c4f-907b-4547-82f8-ac53da356c7b	\N	白术	\N	补气药	苦甘，温	["脾", "胃经"]	健脾益气，燥湿利水	脾虚食少，大便溏薄	阴虚燥渴者慎用	10-15克	\N	t	2026-08-14 12:16:51.329619+00
c8a13323-7677-4c52-ab77-b590c4b5ae4e	\N	当归	\N	补血药	甘辛，温	["肝", "心", "脾经"]	补血活血，调经止痛，润肠通便	血虚便秘，痔疮出血	湿盛中满、大便溏泄者慎用	6-12克	\N	t	2026-08-14 12:16:51.329623+00
185f3d42-c2c6-4461-b3ac-e7926985e8c1	\N	熟地	\N	补血药	甘，微温	["肝", "肾经"]	补血滋阴，益精填髓	血虚萎黄，眩晕心悸	脾虚便溏者慎用	10-15克	\N	t	2026-08-14 12:16:51.329626+00
fc3ee414-0d11-454f-acdf-c696f2179645	\N	生地	\N	补血药	甘，寒	["心", "肝", "肾经"]	清热凉血，养阴生津	血热妄行，便血	脾虚泄泻者慎用	10-15克	\N	t	2026-08-14 12:16:51.329629+00
bc580035-d266-4af4-85ce-b77c03f462d4	\N	黄连	\N	清热药	苦，寒	["心", "脾", "胃", "胆", "大肠经"]	清热燥湿，泻火解毒	湿热痢疾，肛门肿痛	脾胃虚寒者忌用	3-10克	\N	t	2026-08-14 12:16:51.329633+00
556d5c95-c421-4e28-9061-2c51be7dac3b	\N	黄芩	\N	清热药	苦，寒	["肺", "胆", "脾", "大肠经"]	清热燥湿，泻火解毒，止血安胎	湿热泻痢，便血	脾胃虚寒者不宜	6-15克	\N	t	2026-08-14 12:16:51.329636+00
84161cbd-2bb7-4261-9326-bcf8d62e6409	\N	黄柏	\N	清热药	苦，寒	["肾", "膀胱", "大肠经"]	清热燥湿，泻火除蒸，解毒疗疮	湿热下注，肛门肿痛	脾胃虚寒者慎用	6-12克	\N	t	2026-08-14 12:16:51.329639+00
438c8676-03de-4604-8891-47eb1bc5bb4e	\N	栀子	\N	清热药	苦，寒	["心", "肺", "三焦经"]	泻火除烦，清热利湿，凉血解毒	热毒壅盛，便血	脾虚便溏者慎用	6-10克	\N	t	2026-08-14 12:16:51.329643+00
e9592592-729d-415e-ba14-e39a413805a1	\N	金银花	\N	清热药	甘，寒	["肺", "心", "胃经"]	清热解毒，疏散风热	肛周脓肿，疮疡肿毒	脾胃虚寒者慎用	10-20克	\N	t	2026-08-14 12:16:51.329646+00
74ca4faa-19a6-431a-b3e1-d232d949bb83	\N	连翘	\N	清热药	苦，微寒	["肺", "心", "小肠经"]	清热解毒，消肿散结	痈疽疮毒，瘰疬痰核	脾胃虚弱者慎用	6-15克	\N	t	2026-08-14 12:16:51.329649+00
31fc0ab4-7be2-480f-81f2-cedab3a8bf40	\N	赤芍	\N	活血化瘀药	苦，微寒	["肝经"]	清热凉血，散瘀止痛	血瘀肿痛，痈肿疮疡	血虚无瘀者不宜	6-12克	\N	t	2026-08-14 12:16:51.329653+00
9cb8a4b2-3814-4158-adbd-fb743bcaefeb	\N	白芍	\N	补血药	苦酸，微寒	["肝", "脾经"]	养血调经，敛阴止汗，柔肝止痛	血虚萎黄，腹痛	虚寒腹痛者慎用	6-15克	\N	t	2026-08-14 12:16:51.329656+00
f69cfeae-3316-4387-b8e4-577dd3c90b86	\N	川芎	\N	活血化瘀药	辛，温	["肝", "胆", "心包经"]	活血行气，祛风止痛	血瘀气滞诸痛证	阴虚火旺者慎用	3-10克	\N	t	2026-08-14 12:16:51.329664+00
7749d78d-da1a-4db9-8670-84c93ef74d88	\N	桃仁	\N	活血化瘀药	苦甘，平	["心", "肝", "大肠经"]	活血祛瘀，润肠通便	血瘀经闭，跌打损伤，肠燥便秘	孕妇慎用	5-10克	\N	t	2026-08-14 12:16:51.329667+00
7c72d442-78ee-4bf1-abd0-acabf02ce668	\N	红花	\N	活血化瘀药	辛，温	["心", "肝经"]	活血通经，散瘀止痛	痛经，血瘀腹痛	孕妇禁用	3-10克	\N	t	2026-08-14 12:16:51.329671+00
a86ed3e5-d50a-422c-9b76-892ee5269e72	\N	丹皮	\N	清热凉血药	苦辛，微寒	["心", "肝", "肾经"]	清热凉血，活血散瘀	热入营血，血滞经闭	孕妇及月经过多者慎用	6-12克	\N	t	2026-08-14 12:16:51.329674+00
fa5fa924-a212-4ac2-a996-e813ec17de49	\N	木香	\N	理气药	辛苦，温	["脾", "胃", "大肠", "胆经"]	行气止痛，健脾消食	脘腹胀痛，泻痢后重	阴虚津亏者慎用	3-10克	\N	t	2026-08-14 12:16:51.329677+00
706b7996-3115-4656-94f7-dc555e811055	\N	枳壳	\N	理气药	苦辛，微寒	["脾", "胃经"]	理气宽中，行滞消胀	胸胁气滞，胀满疼痛，食积不化	脾胃虚弱者慎用	6-10克	\N	t	2026-08-14 12:16:51.329681+00
3747065d-cc30-4fd9-8737-0986651e20c7	\N	槟榔	\N	驱虫药	苦辛，温	["胃", "大肠经"]	杀虫，消积，行气，利水	食积气滞，腹胀便秘	脾虚便溏者慎用	3-10克	\N	t	2026-08-14 12:16:51.329684+00
1401621f-e765-49d7-a7d3-64daacdc3d31	\N	麻仁	\N	润下药	甘，平	["脾", "胃", "大肠经"]	润肠通便	肠燥便秘	便溏者慎用	10-30克	\N	t	2026-08-14 12:16:51.329687+00
af34832c-634f-45e6-ba7d-50e532740c59	\N	茯苓	\N	利水渗湿药	甘淡，平	["心", "脾", "肾经"]	利水渗湿，健脾安神	水肿尿少，脾虚食少	阴虚而无湿热者慎用	10-15克	\N	t	2026-08-14 12:16:51.329691+00
d01d7160-919c-4b3c-abb2-5e2acddd2f05	\N	泽泻	\N	利水渗湿药	甘淡，寒	["肾", "膀胱经"]	利水渗湿，泄热	小便不利，水肿胀满	肾虚精滑者慎用	6-12克	\N	t	2026-08-14 12:16:51.329694+00
0f8eabcb-1a52-4950-a7b3-3314eeb6c941	\N	车前子	\N	利水渗湿药	甘，寒	["肝", "肾", "肺", "小肠经"]	清热利尿，渗湿止泻，明目祛痰	水肿尿少，湿热泄泻	肾虚精滑者慎用	10-15克	\N	t	2026-08-14 12:16:51.329697+00
1839ceb2-6cba-497f-9b84-53bd1d72e236	\N	苍术	\N	芳香化湿药	辛苦，温	["脾", "胃经"]	燥湿健脾，祛风散寒	湿阻中焦，脘腹胀满	阴虚内热者慎用	5-10克	\N	t	2026-08-14 12:16:51.329701+00
2199fbe1-d336-4826-b1dc-f146d5b0e1c5	\N	五倍子	\N	收涩药	酸涩，寒	["肺", "大肠", "肾经"]	敛肺降火，涩肠止泻，固精止遗，敛汗止血	肺虚久咳，久泻久痢	外感咳嗽慎用	3-10克	\N	t	2026-08-14 12:16:51.329704+00
74d3a437-ddbf-4233-ba6e-3e46854e548e	\N	乌梅	\N	收涩药	酸涩，平	["肝", "脾", "肺", "大肠经"]	敛肺，涩肠，生津，安蛔	久泻久痢，便血脱肛	实邪未清者慎用	6-12克	\N	t	2026-08-14 12:16:51.329707+00
6442b889-50d3-4a87-8a7c-73df1af9aafa	\N	防风	\N	解表药	辛甘，微温	["膀胱", "肝", "脾经"]	祛风解表，胜湿止痛，止痉	外感风寒，风湿痹痛	阴血亏虚者慎用	5-10克	\N	t	2026-08-14 12:16:51.329711+00
2846141d-1c37-4c07-82db-df6e80f7bfaa	\N	荆芥	\N	解表药	辛，微温	["肺", "肝经"]	祛风解表，透疹止痒，止血	感冒风寒，麻疹不透，便血崩漏	表虚自汗者慎用	5-10克	\N	t	2026-08-14 12:16:51.329714+00
e68a737d-bc89-4164-9b5a-1a68927fd339	\N	升麻	\N	解表药	辛甘，微寒	["肺", "脾", "胃", "大肠经"]	发表透疹，清热解毒，升举阳气	气虚下陷，脱肛	阴虚火旺者慎用	3-10克	\N	t	2026-08-14 12:16:51.329717+00
a63f2a84-e5da-443e-aa3e-3574c7b02e5d	\N	柴胡	\N	解表药	苦辛，微寒	["肝", "胆经"]	疏散退热，疏肝解郁，升举阳气	气虚下陷，脱肛	肝阳上亢者慎用	3-10克	\N	t	2026-08-14 12:16:51.329721+00
9044bb77-5724-4d9f-a4b2-ed60f859991b	\N	人参	\N	补气药	甘，微温	["脾", "肺", "心经"]	大补元气，复脉固脱，补脾益肺，生津安神	元气虚脱，气血亏虚	实证、热证忌用	3-10克	\N	t	2026-08-14 12:16:51.329724+00
053f592d-3ddb-430d-9580-80d25acab358	\N	酸枣仁	\N	安神药	甘酸，平	["心", "肝", "胆经"]	养心补肝，宁心安神，敛汗生津	虚烦不眠，惊悸多梦	实邪郁火者慎用	10-15克	\N	t	2026-08-14 12:16:51.329727+00
b0e020a4-12da-4158-beb7-faf6646773f4	\N	龙眼肉	\N	补血药	甘，温	["心", "脾经"]	补益心脾，养血安神	气血不足，心悸失眠	痰火内盛者慎用	10-15克	\N	t	2026-08-14 12:16:51.32973+00
f0e37b61-4beb-45d6-8083-3b89f5240ca9	\N	远志	\N	安神药	苦辛，微温	["心", "肾", "肺经"]	安神益智，祛痰开窍，消肿	心肾不交之失眠多梦	胃溃疡及胃炎患者慎用	3-10克	\N	t	2026-08-14 12:16:51.329734+00
a43ef6b0-ec03-4f7d-8c95-b22a94c725af	\N	大黄	\N	泻下药	苦，寒	["脾", "胃", "大肠", "肝", "心经"]	泻下攻积，清热泻火，凉血解毒，逐瘀通经	实热便秘，血热妄行	孕妇慎用	3-12克	后下	t	2026-08-14 12:16:51.329737+00
0846405e-5126-4600-b366-956e507fbd41	\N	枳实	\N	理气药	苦辛，微寒	["脾", "胃经"]	破气消积，化痰除痞	积滞内停，痰湿阻滞	脾胃虚弱者慎用	3-10克	\N	t	2026-08-14 12:16:51.32974+00
4ba6477c-913a-4439-b8da-8a7962893b67	\N	瓜蒌仁	\N	清热化痰药	甘，寒	["肺", "胃", "大肠经"]	清热化痰，宽胸散结，润肠通便	痰热咳嗽，肠燥便秘	脾虚便溏者慎用	10-15克	\N	t	2026-08-14 12:16:51.329744+00
ad51eebd-a88d-4a88-b8b9-c2c414bf10ea	\N	乌药	\N	理气药	辛，温	["肺", "脾", "肾", "膀胱经"]	行气止痛，温肾散寒	气滞疼痛，小便频数	气虚及内热者慎用	6-10克	\N	t	2026-08-14 12:16:51.329747+00
3cfbcede-65c6-4df1-8a5f-16070e5e065a	\N	牛膝	\N	活血药	苦酸，平	["肝", "肾经"]	逐瘀通经，补肝肾，强筋骨，利尿通淋，引血下行	瘀血阻滞，肝肾不足	孕妇忌用	6-15克	\N	t	2026-08-14 12:16:51.32975+00
e2c8ed8b-55e7-41a9-a777-a4693b7073ad	\N	秦艽	\N	祛风湿药	苦辛，微寒	["胃", "肝", "胆经"]	祛风湿，清湿热，舒筋络	风湿痹痛，湿热黄疸	久病体虚者慎用	5-10克	\N	t	2026-08-14 12:16:51.329753+00
eca9b659-b232-4cd9-8e98-4c3d0dfc42bb	\N	皂角刺	\N	消肿药	辛，温	["肝", "胃经"]	消肿托毒，排脓，杀虫	痈疽肿毒，瘰疬疮疡	孕妇忌用	3-10克	\N	t	2026-08-14 12:16:51.329757+00
177bfeed-9aa9-44f9-8e74-34142e5c1e21	\N	白芷	\N	解表药	辛，温	["肺", "胃经"]	解表散风，燥湿止痛，消肿排脓	风寒感冒，头痛，疮疡肿毒	阴虚火旺者慎用	3-10克	\N	t	2026-08-14 12:16:51.32976+00
38923190-42a5-4aa9-bd02-8bd54ff9c654	\N	桔梗	\N	化痰药	苦辛，平	["肺经"]	宣肺，利咽，祛痰，排脓	咳嗽痰多，咽喉肿痛，肺痈吐脓	阴虚久咳者慎用	3-10克	\N	t	2026-08-14 12:16:51.329763+00
bfa99b0c-d0d2-48e9-8447-e4f7473c2e8a	\N	山栀	\N	清热药	苦，寒	["心", "肺", "三焦经"]	泻火除烦，清热利湿，凉血解毒	热病心烦，湿热黄疸	脾虚便溏者慎用	6-10克	\N	t	2026-08-14 12:16:51.329766+00
c07988b7-8783-4dea-88f4-34a073366570	\N	归尾	\N	活血药	甘辛，温	["肝", "心", "脾经"]	活血祛瘀，调经止痛	瘀血阻滞，跌打损伤	孕妇慎用	6-12克	\N	t	2026-08-14 12:16:51.32977+00
c341fb1f-ed36-4d6d-a10d-e6bf066c6add	\N	地丁	\N	清热解毒药	苦辛，寒	["肝", "胃经"]	清热解毒，消痈散结	疔疮肿毒，乳痈肠痈	脾胃虚寒者慎用	15-30克	\N	t	2026-08-14 12:16:51.329773+00
8d0a660e-6762-47c2-897f-bda88c696446	\N	天花粉	\N	清热药	甘微苦，微寒	["肺", "胃经"]	清热生津，消肿排脓	热病伤津，痈肿疮疡	脾胃虚寒者慎用	10-15克	\N	t	2026-08-14 12:16:51.329776+00
09bc7bd9-0585-4bfa-b096-693a85538523	\N	知母	\N	清热药	苦甘，寒	["肺", "胃", "肾经"]	清热泻火，滋阴润燥	热病烦渴，阴虚火旺	脾胃虚寒者慎用	6-12克	\N	t	2026-08-14 12:16:51.32978+00
ce5cbf6c-82bc-490f-b09c-3fad3d58269e	\N	麦冬	\N	养阴药	甘微苦，微寒	["心", "肺", "胃经"]	养阴润肺，益胃生津，清心除烦	肺燥干咳，虚劳烦热	脾胃虚寒者慎用	6-12克	\N	t	2026-08-14 12:16:51.329783+00
db1d9e74-0b12-48b1-89fe-a50ecd89ad22	\N	青蒿	\N	清虚热药	苦辛，寒	["肝", "胆经"]	清虚热，凉血，解暑	阴虚发热，暑邪发热	脾胃虚寒者慎用	6-12克	\N	t	2026-08-14 12:16:51.329786+00
77616a39-3577-4c95-9d53-1ccd7a5c95dc	\N	鳖甲	\N	滋阴药	咸，微寒	["肝", "肾经"]	滋阴潜阳，软坚散结	阴虚内热，瘰疬痰核	脾胃虚寒者慎用	9-24克	先煎	t	2026-08-14 12:16:51.32979+00
09801096-b9ce-44e2-9967-0d65aa036716	\N	补骨脂	\N	补阳药	辛苦，温	["肾", "脾经"]	补肾壮阳，固精缩尿，温脾止泻	肾阳不足，脾肾阳虚	阴虚火旺者忌用	6-10克	\N	t	2026-08-14 12:16:51.329793+00
838b19bf-71dd-49fe-9d46-1ccc1f84a290	\N	肉豆蔻	\N	收涩药	辛，温	["脾", "胃", "大肠经"]	涩肠止泻，温中行气	虚泻久泻，脘腹胀痛	湿热泻痢者忌用	3-10克	\N	t	2026-08-14 12:16:51.329797+00
d6294fa1-9fda-4357-8606-592d3486682d	\N	灶心土	\N	止血药	辛，温	["脾", "胃经"]	温中止血，止呕止泻	脾胃虚寒，呕吐泄泻，便血崩漏	阴虚火旺者慎用	30-60克	煎汤代水	t	2026-08-14 12:16:51.3298+00
f384481a-5738-4572-98ee-350b666fde9c	\N	陈皮	\N	理气药	苦辛，温	["脾", "肺经"]	理气健脾，燥湿化痰	脾胃气滞，脘腹胀满，呕吐	气虚及阴虚燥咳者慎用	3-10克	\N	t	2026-08-14 12:16:51.329806+00
c3ee3dc0-4226-45ba-ae84-96baeae56662	\N	桂枝	\N	解表药	辛甘，温	["心", "肺", "膀胱经"]	发汗解肌，温通经脉，助阳化气	风寒感冒，寒凝血滞	温热病及阴虚阳盛者忌用	3-10克	\N	t	2026-08-14 12:16:51.329809+00
354d3c2f-a060-4732-9717-daed2686fe6f	\N	朴硝	\N	泻下药	咸苦，寒	["胃", "大肠经"]	泻热通便，润燥软坚，清热消肿	实热便秘，痈肿疮疡	孕妇忌用	10-15克	外用适量	t	2026-08-14 12:16:51.329813+00
9d4a1754-a179-458e-bbd6-88c2efb60fd4	\N	马齿苋	\N	清热解毒药	酸，寒	["肝", "大肠经"]	清热解毒，凉血止血，止痢	热毒血痢，痈肿疔疮	脾胃虚寒者慎用	15-30克	外用适量	t	2026-08-14 12:16:51.329816+00
b518fc6b-858d-4f5d-b38c-7b3003844071	\N	瓦松	\N	清热解毒药	酸，平	["肝", "脾经"]	清热解毒，止血，利湿	吐血便血，痔疮肿痛，湿疹	脾胃虚寒者慎用	15-30克	外用适量	t	2026-08-14 12:16:51.329819+00
f4650975-9fba-4bcc-ad01-dfcb21ac8950	\N	艾叶	\N	温里药	辛苦，温	["肝", "脾", "肾经"]	温经止血，散寒止痛	虚寒性出血，脘腹冷痛	阴虚血热者忌用	3-10克	外用适量	t	2026-08-14 12:16:51.329822+00
bb52878f-1daf-4657-a159-3161d5de04fd	\N	川椒	\N	温里药	辛，热	["脾", "胃", "肾经"]	温中止痛，杀虫止痒	脘腹冷痛，虫积腹痛，湿疹瘙痒	阴虚火旺者忌用	3-6克	外用适量	t	2026-08-14 12:16:51.329826+00
d5df814c-8e7f-490d-bf4b-68f10fe5fdef	\N	明矾	\N	收涩药	酸涩，寒	["肺", "脾", "肝", "大肠经"]	收敛止血，解毒杀虫，燥湿止痒	久泻久痢，便血，湿疹瘙痒	无湿热者慎用	1-3克	外用适量	t	2026-08-14 12:16:51.329829+00
f347d527-e9fc-4f42-82c0-39fd109a7b7f	\N	百部	\N	止咳平喘药	甘苦，微温	["肺经"]	润肺止咳，杀虫灭虱	新久咳嗽，蛲虫病，体虱	热咳者慎用	3-10克	外用适量	t	2026-08-14 12:16:51.329832+00
76d24cf3-74c0-4545-bf94-b03d0180ed29	\N	白鲜皮	\N	清热燥湿药	苦，寒	["脾", "胃经"]	清热燥湿，祛风止痒，解毒	湿热疮毒，黄疸，风湿痹痛	虚寒证忌用	6-15克	\N	t	2026-08-14 12:16:51.329835+00
c1186587-2a23-4781-9752-af32b3662cd8	\N	苦参	\N	清热燥湿药	苦，寒	["心", "肝", "胃", "大肠", "膀胱经"]	清热燥湿，杀虫，利尿	湿热泻痢，黄疸，湿疹瘙痒	脾胃虚寒者慎用	5-10克	外用适量	t	2026-08-14 12:16:51.329839+00
\.


--
-- Data for Name: bill_items; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.bill_items (id, bill_id, charge_item_id, name, category, unit, quantity, unit_price, subtotal, created_at) FROM stdin;
\.


--
-- Data for Name: bill_payments; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.bill_payments (id, tenant_id, bill_id, amount, payment_method, reference_no, notes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.bills (id, tenant_id, patient_id, consultation_id, bill_no, total_amount, discount_amount, paid_amount, status, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: charge_items; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.charge_items (id, tenant_id, name, category, unit, price, description, is_active, created_at) FROM stdin;
10c280b7-5bea-4dc7-9ec6-70faced62a88	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	挂号费	诊疗费	次	10.00	\N	t	2026-08-14 12:17:00.381963+00
805cf1c8-6d56-4fb7-8571-8578bf88050c	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	诊疗费	诊疗费	次	50.00	\N	t	2026-08-14 12:17:00.381973+00
e467138e-12e0-4adb-843a-f91d42f0deb5	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	专家诊疗费	诊疗费	次	100.00	\N	t	2026-08-14 12:17:00.38198+00
954c15a1-5be7-438b-82b5-04f8298dfb71	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	换药费	诊疗费	次	30.00	\N	t	2026-08-14 12:17:00.381989+00
87dd06ce-6ad2-4cb5-9e86-27911397cfdd	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	复查费	诊疗费	次	20.00	\N	t	2026-08-14 12:17:00.381994+00
96ea9714-08bd-4433-b007-c2218d83928b	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	肛门镜检查	检查费	次	80.00	\N	t	2026-08-14 12:17:00.381998+00
76bed6e7-4bdb-47c0-8b93-17bfff1bb3af	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	直肠指检	检查费	次	30.00	\N	t	2026-08-14 12:17:00.382002+00
0d0171bb-24f5-4f2c-935e-94e0bf5469c7	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	痔疮注射术	手术费	次	500.00	\N	t	2026-08-14 12:17:00.382007+00
99809329-56c4-4ccf-92da-3b0e15b886c7	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	套扎术	手术费	次	600.00	\N	t	2026-08-14 12:17:00.382011+00
e1b4b85d-ee17-44b9-aae8-fadf0ff335cd	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	脓肿切开引流术	手术费	次	800.00	\N	t	2026-08-14 12:17:00.382014+00
9c34a1ea-029d-4d13-b0d2-47544d331b39	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	肛裂切除术	手术费	次	1200.00	\N	t	2026-08-14 12:17:00.382017+00
b8b109c3-ba56-443d-a924-8de715a19992	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	混合痔外剥内扎术	手术费	次	2000.00	\N	t	2026-08-14 12:17:00.382021+00
9973c55c-ab51-4c34-b514-8d62e464a4f2	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	针灸治疗	治疗费	次	60.00	\N	t	2026-08-14 12:17:00.382024+00
180745fb-bc5b-47ec-8bb4-a584957da12f	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	艾灸治疗	治疗费	次	40.00	\N	t	2026-08-14 12:17:00.382028+00
fc751d8c-3afb-4555-95dd-ca2dcaa4f99a	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	中药熏洗	治疗费	次	50.00	\N	t	2026-08-14 12:17:00.382031+00
c60c6820-6eb6-498e-bc79-85abff306fe5	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	中药坐浴	治疗费	次	40.00	\N	t	2026-08-14 12:17:00.382035+00
d6f7f427-fd1e-43dc-bbc0-bf9a4d18d2dd	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	一次性肛门镜	材料费	个	15.00	\N	t	2026-08-14 12:17:00.382038+00
9cdf708c-3435-4607-9e09-9f36eb8d92c5	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	手术包	材料费	套	80.00	\N	t	2026-08-14 12:17:00.382042+00
77b00f5b-3e65-494a-85c5-5892eb643eb9	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	换药包	材料费	套	20.00	\N	t	2026-08-14 12:17:00.382045+00
c08f499f-a58c-475f-ac76-70cb2bb92215	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	油纱条	材料费	条	5.00	\N	t	2026-08-14 12:17:00.382049+00
8c569fdb-db5d-4e93-acf5-cd3a7bc4ea44	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	中药饮片	药费	克	0.50	\N	t	2026-08-14 12:17:00.382052+00
d1d09bc9-dab3-4b4f-89b2-24f53ed48aee	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	痔疮膏	药费	支	25.00	\N	t	2026-08-14 12:17:00.382057+00
ce934708-c405-40aa-99a8-233cff06945d	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	化痔栓	药费	盒	30.00	\N	t	2026-08-14 12:17:00.382062+00
d88d2ba9-3dc5-43fe-b9a8-8a526d55a14a	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	九华膏	药费	支	35.00	\N	t	2026-08-14 12:17:00.382068+00
\.


--
-- Data for Name: consultations; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.consultations (id, tenant_id, patient_id, doctor_id, disease_type, chief_complaint, symptoms, tongue, pulse, diagnosis, syndrome, treatment_principle, treatment, prescription_text, symptom_score, status, images, ai_analysis, physical_exam, four_examinations, selected_symptoms, syndrome_result, formula_modifications, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: daily_revenue; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.daily_revenue (id, tenant_id, date, total_revenue, cash_amount, wechat_amount, alipay_amount, card_amount, insurance_amount, bill_count, patient_count, created_at) FROM stdin;
\.


--
-- Data for Name: diagnosis_records; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.diagnosis_records (id, tenant_id, patient_id, consultation_id, disease_type, selected_symptoms, syndrome_result, primary_syndrome_code, primary_syndrome_name, confidence, selected_formula, formula_modifications, efficacy_rating, efficacy_notes, follow_up_date, doctor_notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: external_treatment_records; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.external_treatment_records (id, tenant_id, patient_id, consultation_id, treatment_id, treatment_name, treatment_type, usage_instruction, prescribed_date, created_at) FROM stdin;
\.


--
-- Data for Name: external_treatments; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.external_treatments (id, tenant_id, name, treatment_type, composition, preparation, usage, frequency, duration, function, indications, syndrome_types, disease_types, contraindications, precautions, source, priority, notes, created_at) FROM stdin;
2a590cb1-e4fb-464e-bebf-532f06acc296	\N	复方痔疮栓	suppository	[{"name": "地榆粉", "unit": "g", "dosage": 20}, {"name": "黄柏粉", "unit": "g", "dosage": 10}, {"name": "次没食子酸铋", "unit": "g", "dosage": 10}, {"name": "仙鹤草素", "unit": "片", "dosage": 6}, {"name": "地卡因", "unit": "g", "dosage": 0.7}, {"name": "冰片", "unit": "g", "dosage": 0.7}]	上药混合均匀，加入可可豆脂或半合成脂肪酸甘油酯为基质，制成栓剂，每粒约2g	每晚临睡前排空大便后，将栓剂纳入肛内	每晚1-2枚	连续使用7-14天	消炎止血，止痛收敛，清热解毒	各期内痔出血、肛窦炎、肛裂出血疼痛、混合痔	["湿热下注型", "实热内蕴型", "血热肠燥型"]	["内痔", "肛裂", "肛窦炎", "混合痔"]	肛门外部病变不宜用；孕妇慎用	1. 纳入后保持卧位10分钟；2. 次日可能有少量药渣排出属正常；3. 地卡因过敏者禁用	经验方	92	经验方，对内痔出血、肛裂疼痛效果显著	2026-08-14 12:16:54.75314+00
8e1415f1-270d-4377-9fbd-c4b04e40e565	\N	4%明矾液注射疗法	injection	[{"name": "明矾", "unit": "g", "dosage": 4}, {"name": "注射用水", "unit": "ml", "dosage": 100}]	明矾4g溶于100ml注射用水中，煮沸消毒，冷却后备用	I-II期内痔：痔核基底部注射2-5ml；完全性直肠脱垂：6%明矾液于直肠黏膜下多点注射	每个痔核或脱垂注射点1次，间隔7-14天可重复	根据病情决定，一般1-3次	酸可收敛，涩可固脱，使痔核萎缩硬化	I-II期内痔、完全性直肠脱垂	["脾虚气陷型", "气血亏损型"]	["I-II期内痔", "直肠脱垂"]	III-IV期内痔、血栓外痔、肛周脓肿、孕妇禁用	1. 严格无菌操作；2. 注射层次准确（黏膜下层）；3. 避免注射过浅或过深；4. 术后观察有无出血、感染	1959年创新疗法	75	首创明矾注射疗法，1981年治疗成人完全性直肠脱垂全愈率99.5%	2026-08-14 12:16:54.754322+00
8b1c086e-605b-4353-884f-55a1689d8d96	\N	四黄膏	ointment	"黄连、黄芩、黄柏、栀子各等份研末；凡士林70g + 四黄粉30g 调匀成膏"	四黄各等份研细末，凡士林70g与四黄粉30g混合调匀成膏	外敷患处	每日2-3次	连续使用至红肿消退	清热消肿，凉血止痛	内痔外痔发炎、水肿、术后疼痛，痈疽疔疖红肿	["实热内蕴", "湿热下注", "热毒蕴结"]	["痔疮", "肛周脓肿", "肛门疖肿", "术后水肿"]	皮肤破损渗液较多者慎用	涂药前清洁患处；过敏者停用	原文·辅助治疗（原文第154-157行）	90	周氏用于痔、痈、疽、疔、疖红肿的外敷要药	2026-08-14 12:16:54.749223+00
781896f4-34de-4d4e-a5c2-cc5f9c780d05	\N	高锰酸钾坐浴液	fumigation	[{"name": "高锰酸钾", "unit": "g", "dosage": 0.1}, {"name": "温开水", "unit": "ml", "dosage": 1000}]	取高锰酸钾0.1g溶于1000ml温开水中，配成1:10000溶液（淡紫红色）	坐浴，每次15-20分钟	每日1-2次	连续使用至症状缓解	消毒杀菌，清洁创面，促进愈合	痔疮术后、肛瘘术后、肛周感染、保持肛周清洁	["通用"]	["术后护理", "肛周感染", "痔疮", "肛瘘"]	浓度过高会灼伤皮肤	1. 浓度不宜过高，以淡紫红色为宜；2. 现配现用，久置失效；3. 水温40℃左右	现代常规疗法	70	术后常规坐浴方法，简便有效	2026-08-14 12:16:54.755402+00
ed832e08-aeab-4a7a-b0d8-0f750cec30c6	\N	朴硝马齿苋熏洗方	fumigation	[{"name": "朴硝", "unit": "g", "dosage": 30}, {"name": "马齿苋", "unit": "g", "dosage": 20}, {"name": "瓦松", "unit": "g", "dosage": 15}, {"name": "归尾", "unit": "g", "dosage": 15}, {"name": "赤芍", "unit": "g", "dosage": 15}, {"name": "黄柏", "unit": "g", "dosage": 15}, {"name": "苍术", "unit": "g", "dosage": 15}]	上药加水煎煮去渣，药液约1000ml，趁热先熏后洗	先熏后洗，或浸布湿敷患处；肛门红肿热痛者每日坐浴	每日2-3次	连续使用至炎症缓解	清热解毒，活血祛瘀，利湿软坚，消肿止痛	痔、瘘、肛痈之炎症期，肛裂便后疼痛，痈疽疔疖急性期炎症	["湿热下注", "湿热瘀滞", "热毒蕴结"]	["痔疮", "肛周脓肿", "肛裂", "肛瘘", "肛门疖肿"]	术后大出血者禁用	朴硝易吸潮，密封保存；水温适宜	原文·辅助治疗（原文第150-153行）	96	周氏治嵌顿痔、炎性外痔、血栓外痔重视外治，此方为通用熏洗方	2026-08-14 12:16:54.747905+00
b7279416-a992-48ab-b5d4-4a5456a2a853	\N	九华膏	ointment	"传统名方（黄连、黄柏、冰片、血竭、乳香、没药等，制为膏剂）"	传统制膏法	外敷裂口，每次2-3ml	每日1-2次	连续使用至裂口愈合	消炎止痛，止血生肌	新鲜肛裂	["血热肠燥"]	["肛裂"]	感染化脓者慎用	配合通便、熏洗，打破便秘-疼痛恶性循环	传统名方（原文第288行）	86	周氏以九华膏外敷治疗新鲜肛裂	2026-08-14 12:16:57.695226+00
3dfbe6d8-c578-4212-8a49-cf6857a60ecb	\N	利多卡因软膏（5%）	ointment	"5%利多卡因软膏"	成品制剂	外涂肛裂局部	按需	疼痛缓解即止	局部止痛，缓解括约肌痉挛	肛裂便后疼痛、括约肌痉挛	["通用"]	["肛裂"]	对酰胺类局麻药过敏者禁用	避免大面积长期使用	现代药物（原文第290行）	60	辅助止痛，缓解肛裂括约肌痉挛	2026-08-14 12:16:57.696294+00
4f2290fa-0b2b-4f18-963a-71a8eb33190a	\N	生肌玉红膏	ointment	[{"name": "白芷", "unit": "g", "dosage": 15}, {"name": "甘草", "unit": "g", "dosage": 12}, {"name": "当归身", "unit": "g", "dosage": 6}, {"name": "白蜡", "unit": "g", "dosage": 12}, {"name": "轻粉", "unit": "g", "dosage": 12}, {"name": "血竭", "unit": "g", "dosage": 12}, {"name": "紫草", "unit": "g", "dosage": 6}, {"name": "麻油", "unit": "ml", "dosage": 500}]	白芷等入麻油炸枯去渣，下白蜡，离火后入轻粉、血竭等细粉搅匀成膏	清洁创面后涂抹或药纱覆盖	每日1-2次	创面接近愈合时使用	活血化瘀，解毒生肌	肛瘘术后生肌期、创面腐脱后肉芽生长	["生肌期", "收口期"]	["肛瘘"]	感染化脓期不宜用	待腐脱管化后使用，防止过早封口形成假愈合	《外科正宗》（原文第92行）	72	周氏术后换药规律：腐脱管化后改生肌玉红膏促进肉芽生长	2026-08-14 12:16:54.750595+00
b95b9656-87b9-4682-8511-00a77bf28654	\N	珍珠散	ointment	"传统名方（珍珠、冰片、血竭等，制为散剂）"	制为散剂	撒敷于瘢痕中心不易愈合的小创面	每日换药1次	至创面愈合	生肌敛口	肛瘘术后瘢痕中心小创面久不愈合（排除假愈合后）	["收口期"]	["肛瘘"]	未排除假愈合者禁用	须先排除假愈合，再以珍珠散收口	传统名方（原文第92行）	58	周氏用于瘢痕中心小创面难愈，排除假愈合后外用常获良效	2026-08-14 12:16:57.705866+00
195fc543-c24f-4ccf-a9b9-ff6b88c7a6cc	\N	消炎痛栓	suppository	"吲哚美辛栓（成品）"	成品制剂	纳入肛内，每次1粒	每日1-2次	疼痛缓解即止	消炎止痛，止血	肛裂疼痛、内痔出血	["血热肠燥", "湿热"]	["肛裂"]	消化性溃疡、阿司匹林过敏者慎用	按说明书使用，注意胃肠道不良反应	现代药物（原文第288行）	62	周氏用于肛裂消炎止痛止血	2026-08-14 12:16:57.706925+00
829102ec-6911-4cd9-b754-5b76da7f2703	\N	消肿止痛洗剂	fumigation	[{"name": "瓦松", "unit": "g", "dosage": 30}, {"name": "五倍子", "unit": "g", "dosage": 30}, {"name": "马齿苋", "unit": "g", "dosage": 30}, {"name": "艾叶", "unit": "g", "dosage": 30}, {"name": "川椒", "unit": "g", "dosage": 30}]	上药煎水1000ml	先熏后洗	每日1-2次	连续使用至肿痛缓解	消肿止痛，收敛	外痔发炎、血栓外痔、内痔脱出嵌顿、直肠脱垂及术后伤口水肿疼痛	["湿热下注", "湿热瘀滞", "气滞血瘀"]	["痔疮", "血栓外痔", "直肠脱垂", "术后恢复"]	孕妇慎用；开放性创面较大者慎用	水温40-45℃，避免烫伤；药液不重复使用	经验方（原文第167-170行）	100	经验熏洗方，消肿止痛、收敛固脱	2026-08-14 12:16:54.745254+00
f0374d98-e32a-4401-996a-382fbf0a730c	\N	肛裂熏洗方	fumigation	[{"name": "瓦松", "unit": "g", "dosage": 30}, {"name": "苦参", "unit": "g", "dosage": 30}, {"name": "马齿苋", "unit": "g", "dosage": 30}, {"name": "川椒", "unit": "g", "dosage": 15}, {"name": "防风", "unit": "g", "dosage": 16}, {"name": "赤芍", "unit": "g", "dosage": 16}, {"name": "黄柏", "unit": "g", "dosage": 18}]	上药加水煎煮，取药液约1000ml	先熏后洗，每次20分钟	每日1-2次	连续使用至疼痛出血缓解	清热利湿，消肿止痛	肛裂便后疼痛、出血，括约肌痉挛	["血热肠燥", "湿热"]	["肛裂"]	皮肤破损渗血较多者慎用	水温适宜，避免烫伤	原文·辅助治疗（原文第287行）	88	周氏以熏洗缓解肛裂括约肌痉挛、消肿止痛	2026-08-14 12:16:57.686392+00
6e46989f-fcb4-4b74-9bd8-412f642e606c	\N	疣赘熏洗方	fumigation	[{"name": "五倍子", "unit": "g", "dosage": 20}, {"name": "马齿苋", "unit": "g", "dosage": 30}, {"name": "土茯苓", "unit": "g", "dosage": 30}, {"name": "板蓝根", "unit": "g", "dosage": 30}, {"name": "赤芍", "unit": "g", "dosage": 20}, {"name": "黄柏", "unit": "g", "dosage": 20}, {"name": "白鲜皮", "unit": "g", "dosage": 30}]	上药加水煎煮，取药液外洗	水煎外洗患处	每日1-2次	连续使用至疣赘消退	清热解毒，利湿散结	肛门疣赘（尖锐湿疣等）	["湿热下注"]	["肛门疣赘"]	皮肤破溃感染者慎用	需配合专科病原学与病理检查，伴侣管理与随访按现行指南	原文·辅助治疗（原文第330行）	80	周氏外洗配合内服与腐蚀疗法（如鸦胆子仁、枯痔散），须专科辨证	2026-08-14 12:16:57.6882+00
89c026ed-7eb5-4b84-b9ea-574fc38bb31f	\N	五味消毒饮熏洗	fumigation	[{"name": "金银花", "unit": "g", "dosage": 20}, {"name": "野菊花", "unit": "g", "dosage": 15}, {"name": "蒲公英", "unit": "g", "dosage": 15}, {"name": "紫花地丁", "unit": "g", "dosage": 15}, {"name": "天葵子", "unit": "g", "dosage": 10}]	头二煎内服，第三煎加水煎煮后外洗	取第三煎药液外洗疖肿患处	每日1-2次	连续使用至疖肿消退	清热解毒，消肿排脓	肛门疖肿（热毒型）	["热毒蕴结"]	["肛门疖肿"]	虚寒型慎用	疖肿不可挤压，脓栓未脱时配合化腐散点顶	原文·辅助治疗（原文第355行）	85	周氏以内服五味消毒饮、第三煎外洗同治热毒疖肿	2026-08-14 12:16:57.689402+00
ead9faf4-4099-488a-b623-e2c6c64c71ac	\N	直肠脱垂熏洗方	fumigation	[{"name": "五倍子", "unit": "g", "dosage": 10}, {"name": "白矾", "unit": "g", "dosage": 15}, {"name": "朴硝", "unit": "g", "dosage": 80}, {"name": "生甘草", "unit": "g", "dosage": 10}, {"name": "薄荷", "unit": "g", "dosage": 10}]	上药加水煎汤	每日熏洗两次	每日2次	按疗程使用至脱垂缓解	收敛固脱，消肿利湿	直肠脱垂、脱出肠段充血水肿糜烂	["通用"]	["直肠脱垂"]	黏膜紫黑坏死者禁用	初诊方为乌梅10g、五倍子10g、草河车30g、生甘草10g；收敛后改本方	原文·验案处方（原文第400、405行）	82	周氏外用熏洗收涩固脱，配合内服与收肛散外敷	2026-08-14 12:16:57.690637+00
b44979dc-3731-4414-9984-fdac2b40d599	\N	湿疹洗剂	fumigation	[{"name": "马齿苋", "unit": "g", "dosage": 30}, {"name": "赤芍", "unit": "g", "dosage": 15}, {"name": "地榆", "unit": "g", "dosage": 20}, {"name": "苦参", "unit": "g", "dosage": 30}, {"name": "白鲜皮", "unit": "g", "dosage": 20}, {"name": "明矾", "unit": "g", "dosage": 10}, {"name": "百部", "unit": "g", "dosage": 80}, {"name": "川椒", "unit": "g", "dosage": 10}]	上药加水1500-2000ml煎煮，置温	置温后坐浴，每次20分钟	每日2-3次	连续使用至瘙痒渗出缓解	清热利湿，活血止痒	肛门湿疹、肛门瘙痒	["通用"]	["肛门湿疹"]	急性渗出伴感染重者需专科评估	忌热水烫洗、避免搔抓，忌辛辣刺激	原文·验方选论（原文第474-490行）	78	周氏治疗顽固肛门湿疹瘙痒的验方，临证常获奇效	2026-08-14 12:16:57.691825+00
8d7c6875-b755-4d7b-bbbd-918f08a239f9	\N	玉露膏	ointment	"芙蓉花叶晒干研末，用凡士林调匀成30%软膏"	芙蓉花叶晒干研细末，与凡士林调匀成30%软膏	外敷患处	每日2次	连续使用至红肿消退	清热消肿，凉血解毒	肛周脓肿急性期、疖肿红肿	["热毒蕴结"]	["肛周脓肿", "肛门疖肿"]	成脓波动明显者应切开引流，不宜仅外敷	脓已成宜早期切开，不能以膏药替代引流	原文·辅助治疗（原文第239行）	84	周氏用于肛痈、疖肿急性炎症期的外敷	2026-08-14 12:16:57.693025+00
64a25373-985e-45ac-90b8-5b796880a47a	\N	金黄膏	ointment	[{"name": "黄柏", "unit": "g", "dosage": 60}, {"name": "大黄", "unit": "g", "dosage": 60}, {"name": "姜黄", "unit": "g", "dosage": 60}, {"name": "白芷", "unit": "g", "dosage": 60}, {"name": "厚朴", "unit": "g", "dosage": 25}, {"name": "陈皮", "unit": "g", "dosage": 25}, {"name": "苍术", "unit": "g", "dosage": 25}, {"name": "天南星", "unit": "g", "dosage": 25}, {"name": "甘草", "unit": "g", "dosage": 25}, {"name": "天花粉", "unit": "g", "dosage": 30}]	共研细末，以茶水调和外敷，或配成30%凡士林软膏	外敷或贴敷患处	每日2次	连续使用至肿消痛减	清热消肿，软坚散结	肛周脓肿慢性/虚热型、肿块平塌者	["虚热"]	["肛周脓肿"]	皮肤破溃处慎用	周氏用于虚热型脓肿，配合内服青蒿鳖甲汤加减	原文·辅助治疗（原文第242行）	76	虚热型肛痈外敷首选，散瘀消肿	2026-08-14 12:16:57.694131+00
1d1a3154-2884-454d-8fe8-de5dc1a0caf4	\N	枯痔散	ointment	[{"name": "白矾", "unit": "g", "dosage": 60}, {"name": "白砒", "unit": "g", "dosage": 6}, {"name": "硼砂", "unit": "g", "dosage": 6}, {"name": "雄黄", "unit": "g", "dosage": 6}, {"name": "硫黄", "unit": "g", "dosage": 6}]	分别研细，除硫黄外混匀入沙罐，纸封留孔，炭火煅制；药化声匀时自孔倾入硫黄，减低火力，声消取下冷却研末	撒于疣赘表面（多发性疣每次用量<1g），周围涂凡士林保护；单发者以盐水调少许点于疣顶	每日换药1次	至疣赘变黑变硬完全脱落，改敷生肌玉红膏	腐蚀疣赘，去腐生新	肛门疣赘（尖锐湿疣、传染性软疣、扁平湿疣）	["通用"]	["肛门疣赘"]	含白砒（砒霜），毒性反应明显者停用；孕妇禁用	密切观察砒霜毒性反应，如有及时停用；周围皮肤须涂凡士林保护	原文·辅助治疗（原文第323-327行）	55	历史腐蚀疗法，仅作院内专科学习；现代须按性病与皮肤专科规范评估	2026-08-14 12:16:57.697334+00
35ec6185-50e0-4b4d-8a54-56b9614d99e1	\N	鸦胆子仁	ointment	"鸦胆子仁适量（捣烂）"	取鸦胆子仁捣烂	直接敷于疣赘顶端，保护周围健康皮肤	每日换药1次	至疣赘完全脱落	腐蚀疣赘	肛门疣赘（尖锐湿疣等）	["湿热下注", "气滞血瘀"]	["肛门疣赘"]	周围皮肤须保护，避免灼伤	注意保护周围健康皮肤，避免腐蚀正常组织	原文·辅助治疗（原文第328-329行）	58	周氏验案中配合内服萆薢渗湿汤/丹栀逍遥散治疗尖锐湿疣	2026-08-14 12:16:57.698466+00
fd48d8ea-7e1d-4e39-8c3b-55afdd3cc5ff	\N	化腐散	ointment	[{"name": "红粉", "unit": "g", "dosage": 5}, {"name": "朱砂", "unit": "g", "dosage": 10}, {"name": "石膏", "unit": "g", "dosage": 15}, {"name": "乳香", "unit": "g", "dosage": 10}, {"name": "没药", "unit": "g", "dosage": 10}]	共研细末	点于疖肿白头处促脓栓脱落；或调糊做成药条插入瘘道	每日1-2次	至脓栓脱落/腐肉脱尽	化腐祛腐，排脓生新	肛门疖肿脓栓、肛瘘换药化腐期	["化腐期", "托毒期", "热毒蕴结"]	["肛门疖肿", "肛瘘"]	含红粉（氧化汞），汞过敏者禁用；孕妇禁用	红粉为含汞制剂，须专科掌握、严格限量	原文·处方（原文第460-462行）	54	即化腐生肌散，周氏用于疖肿点顶与肛瘘药条换药	2026-08-14 12:16:57.699538+00
face83f6-840c-457f-b4eb-31456a42fff3	\N	收肛散	ointment	"周氏验方（收敛固脱之药，方从略）"	制为散剂	熏洗后将脱出直肠还纳，外敷收肛散，纱布垫加压固定于肛门两侧	每次便后及换药时	脱垂回纳稳定后停用	收敛固脱，消肿利湿	直肠脱垂脱出后回纳固定	["中气下陷", "气血两虚"]	["直肠脱垂"]	黏膜紫黑坏死者禁用	需先还纳脱出肠段，配合内服升阳固脱	原文·验案处方（原文第402行）	70	周氏以收肛散外敷并纱布加压固定，阻止再度脱出	2026-08-14 12:16:57.700685+00
ac11c343-3b36-42b3-b578-1cee1d6180d9	\N	红粉纱条	ointment	"红粉（升丹）药纱条"	以红粉制剂浸制纱条	置入创面/瘘道，蚀管祛腐	每日换药1次	创面腐脱管化后停用	蚀管祛腐，保持引流	肛瘘术后化腐期、腐败组织未尽	["化腐期"]	["肛瘘"]	含汞制剂，汞过敏者禁用；孕妇禁用	红粉为含汞制剂，仅限专科换药、严格限量	原文·换药规律（原文第92行）	52	周氏强调肛瘘术后初时宜重化腐，用红粉纱条蚀管祛腐	2026-08-14 12:16:57.701818+00
adb7db6c-89eb-482b-a44e-f7dfc7cc9891	\N	盐水纱条	ointment	"生理盐水浸润纱条"	以无菌生理盐水浸润无菌纱条	换药时敷于创面	每日换药1次	肉芽水肿消退后停用	消肿，促进肉芽新鲜	肛瘘术后肉芽生长不良、水肿	["生肌期"]	["肛瘘"]	无特殊	周氏经验：肉芽水肿时用盐水纱条换药	原文·换药规律（原文第92行）	60	周氏用于肉芽生长不良和水肿，促进肉芽新鲜消肿	2026-08-14 12:16:57.704798+00
339c9560-8aab-468c-9268-75e6e4c242f3	\N	6%明矾液注射疗法	injection	[{"name": "明矾", "unit": "g", "dosage": 6}, {"name": "注射用水", "unit": "ml", "dosage": 100}]	明矾6g溶于100ml注射用水中，煮沸消毒，冷却备用	成人完全性直肠脱垂：6%明矾液于直肠黏膜下多点注射	按疗程由专科执行	按病情决定	酸可收敛，涩可固脱	成人完全性直肠脱垂（1981年部级鉴定，全愈率99.5%）	["中气下陷", "气血两虚", "肾虚不固"]	["直肠脱垂"]	黏膜坏死、感染、孕妇等	严格无菌、层次准确，仅限资质人员执行	经验方（原文第88-89行）	50	周氏创新疗法，成人完全性直肠脱垂非手术治疗的里程碑	2026-08-14 12:16:57.707968+00
5f8d1ed1-6356-435c-a7e5-a514bdbdf775	\N	肛裂封闭疗法	injection	"0.25%布比卡因6ml（长强穴扇形注射）；或亚甲蓝0.26g+地卡因0.2g+蒸馏水加至100ml（局部封闭）"	按无菌原则配制	布比卡因于长强穴扇形注射；或亚甲蓝地卡因液局部封闭，每次5-10ml	布比卡因隔日一次，5次一疗程；亚甲蓝每周1-2次	按疗程	止痛，缓解括约肌痉挛	肛裂顽固疼痛、括约肌痉挛	["通用"]	["肛裂"]	对局麻药过敏者禁用	仅限专科医师执行，注意无菌与过敏反应	原文·辅助治疗（原文第291行）	48	周氏用于缓解肛裂疼痛与括约肌痉挛的封闭疗法	2026-08-14 12:16:57.708983+00
\.


--
-- Data for Name: followups; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.followups (id, tenant_id, patient_id, consultation_id, doctor_id, scheduled_date, actual_date, status, symptom_score, notes, recovery_status, images, created_at) FROM stdin;
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.images (id, tenant_id, consultation_id, patient_id, file_path, file_name, file_size, image_type, stage, ai_result, description, created_at) FROM stdin;
\.


--
-- Data for Name: medical_cases; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.medical_cases (id, tenant_id, case_number, case_title, source, case_date, patient_info, inspection, auscultation, inquiry, palpation, disease_type, syndrome_analysis, syndrome_type, treatment_principle, internal_formula, external_treatment, other_treatments, follow_ups, outcome, outcome_notes, key_points, teaching_notes, tags, is_classic, difficulty_level, view_count, reference_count, created_at, updated_at) FROM stdin;
be6ce1ab-0e86-4d03-9ba3-023596c3b372	\N	ZJM-A-001	气血两亏、中气下陷型直肠脱垂（八珍汤加味内外合治案）	临床经验·医案述评（原文386-407行）	\N	{"age": 50, "name": "赵某某", "gender": "女", "history": "十余年前产后长期便秘致便后脱出，初能自行还纳，渐重需手托，时有带血及黏液；多方治疗效果不佳。", "occupation": "北京华水大厦职工", "chief_complaint": "便后有物脱出十余年"}	{"舌": "舌淡，少苔", "局部": "蹲位用力时脱出肠段黏膜充血、水肿，部分溃疡、糜烂，有血性及黏液样分泌物，脱出长约8厘米", "面唇": "面色、口唇淡白"}	{"语声": "气短倦怠"}	{"主诉": "便后有物脱出十余年", "大便": "干燥，2-3日一行", "精神": "精神差、气短、倦怠"}	{"脉": "脉虚", "检查": "直肠脱垂（II度）"}	直肠脱垂	产后长期便秘，气血两亏，中气下陷，气虚不能升提，血虚失于濡养。	气血两亏，中气下陷	补气养血，升举固脱	{"name": "八珍汤加味", "usage": "七剂，每日一剂，水煎服二次", "composition": "炙黄芪30克，党参15克，白术12克，熟地12克，当归15克，川芎9克，升麻6克，柴胡12克，五味子15克，肉苁蓉15克，乌梅10克，炙甘草6克，麻仁12克"}	[{"name": "熏洗方", "usage": "七剂，煎汤熏洗，日一剂，分二次", "composition": "乌梅10克，五倍子10克，草河车30克，生甘草10克"}, {"name": "收肛散", "usage": "熏洗后外敷，将脱出直肠还纳，纱布垫加压固定于肛门两侧"}]	\N	[{"变化": "精神渐好，脱出肠段偶可自行还纳，充血水肿消失，溃疡糜烂减轻", "诊次": "二诊", "调整": "上方去柴胡、熟地、麻仁，加生地、枳壳；外用药同前，各七剂"}, {"变化": "脱出物可自还纳，溃疡糜烂渐愈", "诊次": "三诊", "调整": "上方去党参，加茯苓12克；熏洗改用五倍子10克、白矾15克、朴硝80克、生甘草10克、薄荷10克；停收肛散及布垫加压"}, {"变化": "大便正常时已无肿物脱出", "诊次": "四诊", "调整": "改补中益气丸连服半年巩固，嘱做收肛锻炼"}]	痊愈	三年随访无复发。	直肠脱垂虽多属虚证，但须审证求因，本例为产后气血两亏、中气下陷\n内服八珍汤补气养血，升麻柴胡升阳，乌梅五味子酸敛收涩，苁蓉麻仁润肠通便\n外用熏洗与收肛散直达病所，收敛固脱、消肿利湿\n复诊随证加减：先润肠通便之品减量，后去党参加茯苓，终以补中益气丸巩固	按：脱肛多因先天不足、脏气不实、产育用力、久泻久痢、酒食伤脾、久咳伤肺等引起。治疗既要重视局部致病因素，更要注意全身整体状况。此案以参、芪、归、术、川芎、甘草、升麻升阳举陷，乌梅、五味子酸涩收敛，兼用苁蓉、麻仁养阴通便；外用熏洗、外敷收涩固脱。补虚为本、内外合治、立足局部、顾及整体。	["直肠脱垂", "八珍汤", "中气下陷", "内外合治", "经典医案"]	t	3	0	0	2026-08-14 12:16:55.541599+00	2026-08-14 12:16:55.541599+00
acff6ddb-74db-4981-b6e5-116f82f33d52	\N	ZJM-A-002	阴虚精亏、邪毒结聚型肛周脓肿（青蒿鳖甲汤加减案）	临床经验·医案述评（原文408-425行）	\N	{"age": 35, "name": "解某某", "gender": "女", "history": "二周前腹泻后肛旁肿痛，无发热寒战，疼痛不甚，自服消炎药无效；因惧怕手术而来诊。", "occupation": "海淀区四季青乡农民", "chief_complaint": "肛门局部肿胀疼痛二周"}	{"舌": "舌苔薄腻", "局部": "截石位3-4点距肛缘2-3厘米处3x4厘米肿块，略隆起，色暗红，皮温不高，边界不清", "面色": "两颧潮红"}	{"语声": "全身倦怠无力"}	{"主诉": "肛门局部肿胀疼痛二周", "全身": "五心烦热，消瘦"}	{"脉": "脉弦细", "检查": "触痛不甚，质中等硬度，位置较深，无明显波动感；指诊肛管直肠下端光滑"}	肛周脓肿	平素体弱，腹泻伤脾，脾病及肾，脾肾两虚；阴精亏损，邪毒乘虚下注大肠，蕴阻肛门而发病。	阴虚精亏，邪毒结聚	清虚热，散毒邪	{"name": "青蒿鳖甲汤加减", "usage": "每日一剂，水煎服", "composition": "青蒿12克，鳖甲12克，柴胡12克，黄芩15克，生地15克，白芍10克，知母10克，生黄芪15克，麦冬10克，当归12克，川芎10克"}	[{"name": "金黄膏", "usage": "外敷，每日二次"}]	\N	[{"变化": "诸症减轻，肿块缩小，疼痛消失，舌脉同前", "诊次": "二诊", "调整": "前方加桃仁9克、红花9克，增强活血消散之功，再服十剂"}]	痊愈	肿块消散，症状消失。半年后随访未复发。	肛周脓肿须辨虚实寒热与部位；本例属虚热型（阴虚精亏、邪毒结聚）\n内治以青蒿鳖甲汤养阴清热散毒气，虚证不宜一味清热解毒\n外治以金黄膏散瘀消肿止痛，内外合参标本同治\n二诊正气渐复、毒邪外出，加桃仁红花活血消散收功	按：肛周脓肿属「脏毒」「悬痈」「坐马痈」范畴。治疗不但要辨虚实寒热，还要辨别脓肿部位。内治实证宜清热解毒为主，虚证宜养阴清热祛湿为主；外治初起可用金黄膏、四黄膏或玉露膏外敷，脓已成则及早切开引流。	["肛周脓肿", "青蒿鳖甲汤", "虚热", "内外合治", "经典医案"]	t	3	0	0	2026-08-14 12:16:55.541599+00	2026-08-14 12:16:55.541599+00
71de20fd-300b-4e0b-be8d-d9ce9d4b2c09	\N	ZJM-A-003	血虚津乏、筋脉瘀阻型嵌顿痔（四物汤合增液汤加味案）	临床经验·医案述评（原文426-446行）	\N	{"age": 50, "name": "孙某某", "gender": "男", "history": "三年前因大便长期干燥、临厕时间过长致便后脱出，初能还纳，伴便血；二天前脱出不能还纳，坠胀疼痛、便血量多。", "occupation": "北京市包装机械厂工人", "chief_complaint": "便后有物脱出三年，加重不能还纳二天"}	{"舌": "舌质红，苔黄燥，边有瘀斑", "局部": "痔核环状脱出，色紫暗，有散在出血点及糜烂面，血性及黏液样分泌物渗出", "面色": "急性痛苦病容，精神差"}	{"语声": "坐卧不宁"}	{"主诉": "便后脱出三年，加重不能还纳二天", "全身": "口干，心烦，食少纳减，夜寐不安", "大便": "二日未解", "小便": "短少"}	{"脉": "脉弦滑", "检查": "无明显血栓形成，触痛明显"}	痔疮	本虚标实：血虚津乏、筋脉瘀阻，肠燥便结而痔核嵌顿。	血虚津乏，筋脉瘀阻	生津润燥，活血化瘀，兼消肿、利湿、止痛	{"name": "四物汤合增液汤加味", "usage": "三剂，水煎服，每日一剂，分二次服", "composition": "生地16克，玄参16克，赤芍10克，当归10克，麦冬10克，大腹皮子各10克，川芎6克，碧玉散20克（包）"}	[{"name": "血竭散（熏洗）", "usage": "三剂，水煎，每日一剂，分二次熏洗", "composition": "血竭3克，大黄20克，玄明粉30克，煅自然铜30克"}, {"name": "四黄膏", "usage": "熏洗后局部外敷"}]	\N	[{"变化": "大便已解，脱出痔核明显萎缩，出血及糜烂减轻，可手法复位", "诊次": "二诊", "调整": "守方同前，各三剂"}, {"变化": "大便正常，每日一行，脱出痔核可自行还纳，水肿出血消失", "诊次": "三诊", "调整": "停用口服及外用药，改复方痔疮栓20枚纳肛，每日二次；忌辛辣温燥、保持大便通畅"}]	痊愈	随访一年未复发。	嵌顿痔属本虚标实，标本兼顾：四物汤合增液汤生津润燥养血益阴治其本\n血竭散合四黄膏外用活血祛瘀、消肿止痛、利湿解毒治其标\n《丹溪心法》「痔者，皆因脏腑本虚……气血下坠，结聚肛边」，治疗无论虚实寒热均辅以行气活血\n后期以复方痔疮栓收尾，忌辛辣、防努挣	按：痔的成因不外内伤、外感两类，病理实质均属经脉气血俱滞。此病例以四物汤合增液汤生津润燥养血益阴治本，以血竭散合四黄膏外用活血祛瘀消肿止痛治标，内外同治、双管齐下。	["嵌顿痔", "四物汤合增液汤", "血竭散", "本虚标实", "经典医案"]	t	3	0	0	2026-08-14 12:16:55.541599+00	2026-08-14 12:16:55.541599+00
4168d7f0-4b6e-471a-b36c-1315c14acf57	\N	ZJM-A-004	气血两虚型低位复杂性肛瘘（托里消毒散→八珍汤加味脱管案）	临床经验·医案述评（原文447-472行）	\N	{"age": 60, "name": "张某某", "gender": "男", "history": "二年前无明显诱因肛旁肿痛，一周后自行破溃流黄稠脓液，此后反复肿痛流脓；因惧怕手术未采纳手术建议。", "occupation": "北京市四季青乡农民", "chief_complaint": "肛旁间断性反复肿痛伴流脓水二年，加重一周"}	{"舌": "舌淡，苔薄白", "局部": "截石位3点、7点分别距肛门3厘米、5厘米处见瘘道外口，清稀脓液溢出，条索状物通向肛内后正中位", "面色": "面色无华"}	{"语声": "少言懒语"}	{"主诉": "肛旁反复肿痛流脓水二年，加重一周", "全身": "神疲乏力，纳差", "大便": "大便秘结"}	{"脉": "脉细弱无力", "检查": "指诊6点位齿线处触及凹陷；探针自3点、7点外口探入，自6点内口探出"}	肛瘘	漏之日久，耗伤气血，正虚邪实，缠绵难愈。	气血两虚	补气养血，兼清湿热	{"name": "托里消毒散加味", "usage": "七剂，水煎分二次服，每日一剂", "composition": "党参10克，黄芪20克，当归10克，白术12克，茯苓10克，桔梗6克，银花15克，白芷10克，山甲6克，皂刺6克，丹参30克，炙甘草6克"}	[{"name": "化腐生肌散", "usage": "共研细末调糊，以棉纸做条蘸药插入瘘道，每日二次", "composition": "红粉5克，朱砂10克，石膏15克，乳香10克，没药10克"}]	\N	[{"变化": "精神好转，大便正常，脓液稠厚", "诊次": "二诊", "调整": "守方七剂，外治法同前"}, {"变化": "脓出渐尽，腐肉渐脱", "诊次": "三诊", "调整": "改八珍汤加味（当归16克，熟地15克，白芍15克，川芎12克，白术12克，茯苓12克，肉桂6克，炙黄芪20克，乳没各6克）；外用生肌玉红膏"}, {"变化": "精神饮食睡眠俱佳，瘘口无异常分泌物", "诊次": "四诊", "调整": "续服上方七剂，外用玉红膏脱管法换药"}]	痊愈	漏去而伤口自愈。	肛瘘须明确内口、主管、支管和死腔；本例为低位复杂性肛瘘（3点、7点外口，6点内口）\n初期托里消毒散补气养血、托里透毒、扶正生肌，取「腐不去何以生肌，肌不生何以敛皮」\n外治以化腐生肌散药条插入瘘道脱管，邪尽后改八珍汤加味益气补血、生肌敛口\n脱管之法对不愿手术者，辨证准确、用药精良亦可取得良效	按：肛瘘多因脓肿溃后余毒未尽，蕴结不散、血行不畅，或肺脾两虚所致。初期宜轻剂解散以求内消；中期宜托里透脓、清化湿热；成脓之后宜补气养血、兼清湿热。至于脱管之法，宋《太平圣惠方》已有将砒溶于黄蜡捻为条纳疮窍之记载。	["肛瘘", "托里消毒散", "八珍汤", "脱管法", "经典医案"]	t	4	0	0	2026-08-14 12:16:55.541599+00	2026-08-14 12:16:55.541599+00
08475bc2-90a2-47e5-9944-1253a476a967	\N	ZJM-ZC-001	湿热瘀滞型痔疮典型案例	临床经验	1985-03-15	{"age": 42, "gender": "男", "duration": "1周", "occupation": "办公室职员", "chief_complaint": "痔核肿痛3天，便血1周"}	{"local": "肛门周围可见3个暗紫色痔核，肿胀明显，触之疼痛", "tongue": "舌质红", "tongue_coating": "黄腻"}	{}	{"pain": {"degree": "剧烈", "nature": "胀痛", "present": true}, "sleep": "难寐", "appetite": "纳差", "bleeding": {"color": "鲜红", "volume": "中量", "present": true}, "urination": "短赤", "dry_throat": true, "bitter_mouth": true, "stool_condition": "干结"}	{"pulse": "弦滑数"}	痔疮	\n周济民辨证分析：\n1. 症状特点：痔核肿痛剧烈、便血鲜红、大便干结，属实证、热证\n2. 全身症状：口苦咽干、小便短赤，提示湿热内蕴\n3. 舌脉：舌质红、苔黄腻、脉弦滑数，确证湿热下注\n4. 病机：湿热下注肛门，气滞血瘀，瘀热互结\n\n周氏指出："痔之临证所见，实证者多，虚证者少。此患者正值壮年，体质尚实，\n加之饮食不节、嗜食辛辣，致湿热下注，气血瘀滞于肛门。治当清热除湿，活血化瘀。"\n        	湿热瘀滞型	清热除湿，活血化瘀	{"name": "五神汤加味", "usage": "水煎服，每日1剂，分2次温服", "composition": [{"herb": "茯苓", "dosage": "10g"}, {"herb": "金银花", "dosage": "20g"}, {"herb": "牛膝", "dosage": "10g"}, {"herb": "车前子", "dosage": "10g"}, {"herb": "地丁", "dosage": "15g"}, {"herb": "黄芩", "dosage": "10g"}, {"herb": "归尾", "dosage": "10g"}, {"herb": "赤芍", "dosage": "10g"}, {"herb": "大黄", "dosage": "6g"}, {"herb": "甘草", "dosage": "10g"}], "modifications": "便秘严重加芒硝6g；疼痛剧烈加延胡索10g"}	[{"name": "朴硝马齿苋熏洗方", "usage": "先熏后洗，每次20-30分钟", "frequency": "每日2次"}, {"name": "四黄膏", "usage": "外敷患处，厚度2-3mm", "frequency": "每日3次"}]	卧床休息，避免久坐；忌食辛辣刺激食物	[{"date": "1985-03-18", "days": 3, "notes": "疗效显著", "adjustment": "守方继续，大黄减至3g", "symptoms_change": "肿痛明显减轻，便血减少，大便转软"}, {"date": "1985-03-22", "days": 7, "notes": "临床治愈", "adjustment": "停用内服药，继续外洗3天巩固", "symptoms_change": "肿痛基本消失，便血停止，大便正常"}]	痊愈	7天临床治愈，随访3个月未复发	\n周济民点评要点：\n1. 辨证准确：抓住"湿热"和"瘀滞"两个关键\n2. 内外兼治：内服清热活血，外用熏洗消肿，疗效倍增\n3. 用药精当：五神汤清利湿热，加大黄、归尾增强活血化瘀\n4. 及时调整：见效后及时减轻攻伐药物剂量，防止伤正\n5. 预防复发：强调饮食起居调护，从根本上防止复发\n\n教学意义：本案例典型体现周济民"注重湿邪为患"和"内外兼治"学术思想，\n是学习痔疮实证治疗的经典案例。\n        	\n适合教学场景：\n- 中医外科临床带教\n- 肛肠病辨证施治培训\n- 学术思想学习\n- 实证型痔疮典型案例参考\n        	["典型案例", "内外兼治", "湿热证", "疗效显著"]	t	2	0	0	2026-08-14 12:18:26.653102+00	2026-08-14 12:18:26.653102+00
bf59a97d-ee20-4ef5-8303-474bc322018b	\N	ZJM-TC-001	气血两虚型直肠脱垂 - 明矾注射疗法	临床经验	1981-06-20	{"age": 65, "gender": "女", "duration": "3年", "occupation": "退休工人", "chief_complaint": "直肠脱出3年，加重半年"}	{"local": "直肠黏膜脱出约5cm，色淡红，表面光滑", "tongue": "舌质淡", "tongue_coating": "薄白"}	{}	{"fatigue": true, "prolapse": true, "dizziness": true, "poor_appetite": true, "pale_complexion": true, "prolapse_trigger": "咳嗽、用力时脱出", "shortness_of_breath": true}	{"pulse": "细弱"}	直肠脱垂	\n周济民辨证分析：\n1. 病史特点：老年女性，脱垂3年，反复发作\n2. 局部表现：直肠黏膜脱出，色淡红而非暗紫，提示虚证\n3. 全身症状：神疲乏力、气短懒言、面色萎黄，典型气血两虚\n4. 舌脉：舌淡苔薄白、脉细弱，确证气血不足\n\n周氏指出："直肠脱垂虽属虚证，但病因很多。此患者年老体弱，气血两虚，\n中气下陷，不能固摄，致直肠脱出。单纯补益气血，疗程长、疗效慢。\n根据'酸可收敛、涩可固脱'理论，宜采用明矾注射疗法，配合内服补益气血方剂。"\n        	气血两虚型	补益气血，升举固脱	{"name": "八珍汤加味", "usage": "水煎服，每日1剂，分2次温服", "composition": [{"herb": "人参", "dosage": "10g"}, {"herb": "白术", "dosage": "10g"}, {"herb": "茯苓", "dosage": "10g"}, {"herb": "炙甘草", "dosage": "6g"}, {"herb": "当归", "dosage": "12g"}, {"herb": "川芎", "dosage": "10g"}, {"herb": "白芍", "dosage": "10g"}, {"herb": "熟地黄", "dosage": "15g"}, {"herb": "黄芪", "dosage": "30g"}, {"herb": "升麻", "dosage": "6g"}, {"herb": "柴胡", "dosage": "6g"}], "modifications": "加黄芪、升麻、柴胡增强升举固脱之力"}	[{"name": "6%明矾液注射疗法", "notes": "周济民1959年首创，1981年治疗成人完全性直肠脱垂全愈率99.5%", "usage": "直肠黏膜下多点注射，每点2-3ml", "frequency": "首次治疗"}]	提肛运动：每日3次，每次50下；避免久站、便时勿过度用力	[{"date": "1981-06-27", "days": 7, "notes": "注射疗效显著", "adjustment": "继续内服方剂，暂不追加注射", "symptoms_change": "脱垂明显减轻，仅用力时轻度脱出"}, {"date": "1981-07-11", "days": 21, "notes": "巩固疗效", "adjustment": "二次明矾注射，剂量减半", "symptoms_change": "脱垂基本控制，日常活动不脱出"}, {"date": "1981-08-20", "days": 60, "notes": "临床痊愈", "adjustment": "停药，嘱继续提肛锻炼", "symptoms_change": "直肠脱垂完全治愈，无复发"}]	痊愈	2个月治愈，随访1年无复发，疗效巩固	\n周济民点评要点：\n1. 创新疗法：明矾注射疗法是周济民1959年首创，理论依据"酸可收敛、涩可固脱"\n2. 内外结合：注射疗法解决局部脱垂，内服方剂调理气血，标本兼治\n3. 分次治疗：首次注射观察疗效，酌情追加第二次，避免过度治疗\n4. 疗效确切：1981年鉴定数据显示全愈率99.5%，且无直肠狭窄等后遗症\n5. 预防复发：强调功能锻炼（提肛运动），从根本上恢复肛门功能\n\n历史意义：本案例是周济民明矾注射疗法的经典应用，为成人完全性直肠脱垂\n的非手术治疗开辟了新路，具有重要学术价值和临床价值。\n        	\n适合教学场景：\n- 中医外科创新疗法学习\n- 学术思想传承\n- 直肠脱垂非手术治疗培训\n- 虚证型肛肠病治疗参考\n\n重点教学内容：\n1. 明矾注射疗法的理论依据\n2. 注射技术要点（层次、剂量、部位）\n3. 内外兼治的临床应用\n4. 疗效评价与随访管理\n        	["经典案例", "创新疗法", "明矾注射", "内外兼治", "虚证"]	t	3	0	0	2026-08-14 12:18:26.653102+00	2026-08-14 12:18:26.653102+00
ee717f61-c1da-4a36-8107-c72a023e0a44	\N	ZJM-GL-001	虚热内蕴型肛瘘 - 术后换药经验	临床经验	1978-09-10	{"age": 48, "gender": "男", "duration": "3个月", "occupation": "教师", "chief_complaint": "肛瘘术后创面不愈3个月"}	{"local": "肛门旁见手术创面，肉芽组织苍白，脓汁清稀，愈合缓慢", "tongue": "舌质红", "tongue_coating": "少苔"}	{}	{"fatigue": true, "discharge": {"color": "清稀", "present": true}, "low_fever": true, "night_sweats": true, "poor_appetite": true, "chronic_fistula": true, "delayed_healing": true}	{"pulse": "细数"}	肛瘘	\n周济民辨证分析：\n1. 病史特点：术后3个月创面不愈，脓汁清稀，属虚证\n2. 局部表现：肉芽苍白、生长不良，提示气血不足\n3. 全身症状：潮热盗汗、低热、懒言乏力，典型虚热内蕴\n4. 舌脉：舌红少苔、脉细数，确证阴虚内热\n\n周氏指出："此乃久病失治，寒邪循络内侵，入里化热灼伤肺金，肺燥失润，\n气机不得宣发，气血不达，肌肤失于濡养而致。治以滋阴养血通络之法，\n使气血畅通，每获良效。同时换药方法至关重要：初时宜重化腐，\n待腐脱管化改用玉红膏生肌。"\n        	虚热内蕴	滋阴养血，清热通络	{"name": "当归连翘汤", "usage": "水煎服，每日1剂，分2次温服", "composition": [{"herb": "当归", "dosage": "12g"}, {"herb": "连翘", "dosage": "12g"}, {"herb": "生地", "dosage": "12g"}, {"herb": "白芍", "dosage": "10g"}, {"herb": "白芷", "dosage": "6g"}, {"herb": "党参", "dosage": "15g"}, {"herb": "白术", "dosage": "10g"}, {"herb": "阿胶", "dosage": "12g"}, {"herb": "甘草", "dosage": "6g"}, {"herb": "地榆", "dosage": "10g"}, {"herb": "乌梅", "dosage": "10g"}], "modifications": "加鸡血藤15g、丹参12g活血通络，促进肉芽生长"}	[{"name": "玉红膏", "notes": "周济民强调：待腐脱管化后使用，促进创面愈合，防止假愈合", "usage": "清洁创面后涂抹，或用药纱覆盖", "frequency": "每日换药1次"}]	\n周济民换药规律：\n1. 初时宜重化腐：用红粉纱条蚀管祛腐\n2. 待腐脱管化：改用生肌玉红膏换药\n3. 接近愈合时：防止桥形粘连，避免假愈合\n4. 肉芽水肿时：用盐水纱条消肿\n5. 中心小创面：外用珍珠散收口\n        	[{"date": "1978-09-20", "days": 10, "notes": "开始见效", "adjustment": "内服方守方，外用继续玉红膏", "symptoms_change": "脓汁转为黄色粘稠，肉芽颜色转红，开始生长"}, {"date": "1978-10-05", "days": 25, "notes": "疗效显著", "adjustment": "内服方减轻剂量，外用继续", "symptoms_change": "创面明显缩小，肉芽新鲜，脓汁基本消失"}, {"date": "1978-10-25", "days": 45, "notes": "接近痊愈", "adjustment": "外用珍珠散收口", "symptoms_change": "创面基本愈合，仅中心留针尖大小"}, {"date": "1978-11-05", "days": 56, "notes": "临床治愈", "adjustment": "停药", "symptoms_change": "创面完全愈合，无窦道残留"}]	痊愈	56天创面完全愈合，随访半年无复发	\n周济民点评要点：\n1. 辨虚实：术后久不愈合，属虚证而非实证，不可一味清热解毒\n2. 析病机：虚热内蕴，阴虚内热，治以滋阴养血为主，佐以清热通络\n3. 重外治：换药方法至关重要，把握"化腐-生肌"转换时机\n4. 察肉芽：根据肉芽颜色、质地调整用药，是周氏特色经验\n5. 防假愈：接近愈合时注意桥形粘连，防止表面愈合、深部残留\n\n换药规律总结（周济民经验）：\n"初时宜重化腐，待腐脱管化改用玉红膏生肌，接近愈合时防止假愈合"\n这是周济民肛瘘术后处理的核心经验，值得深入学习。\n        	\n适合教学场景：\n- 肛瘘术后处理培训\n- 虚证型肛肠病辨治\n- 创面换药技术教学\n- 学术思想学习\n\n重点教学内容：\n1. 虚实辨证在术后管理中的应用\n2. 换药时机的把握（化腐→生肌→收口）\n3. 肉芽组织观察技巧\n4. 假愈合的预防方法\n5. 内外兼治的临床应用\n        	["疑难病例", "术后处理", "虚证", "换药经验", "内外兼治"]	t	3	0	0	2026-08-14 12:18:26.653102+00	2026-08-14 12:18:26.653102+00
\.


--
-- Data for Name: medicine_batches; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.medicine_batches (id, tenant_id, medicine_id, batch_no, quantity, remaining_quantity, purchase_price, production_date, expiry_date, supplier, created_at) FROM stdin;
\.


--
-- Data for Name: medicines; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.medicines (id, tenant_id, name, pinyin, category, specification, unit, purchase_price, selling_price, stock_quantity, min_stock, max_stock, supplier, storage_condition, is_active, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.patients (id, tenant_id, name, gender, age, phone, id_card, doctor_id, medical_history, allergies, tags, occupation, address, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: prescriptions; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.prescriptions (id, tenant_id, consultation_id, patient_id, doctor_id, formula_name, medicines, dosage_instructions, duration_days, notes, status, created_at) FROM stdin;
\.


--
-- Data for Name: prevention_guides; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.prevention_guides (id, tenant_id, disease_type, title, prevention_points, dietary_advice, lifestyle_advice, exercise_advice, postop_care, acupuncture_points, sitz_bath_formula, warning_signs, created_at) FROM stdin;
8cd6a172-b226-44b9-a0ae-7d037d87443b	\N	痔疮	痔疮预防与保健指南	["保持大便通畅，养成定时排便习惯", "饮食清淡，忌辛辣刺激、酗酒", "避免久坐久立久蹲", "适当运动，坚持提肛锻炼", "保持肛门清洁", "女性注意孕期保健", "避免腹泻和便秘"]	多食蔬菜水果，保持大便通畅。忌食辛辣刺激之品如辣椒、大蒜、烈酒等。宜食清淡易消化食物。	避免久坐久站，适当活动。便后温水坐浴。保持心情舒畅，避免情绪激动。	提肛运动：每日早晚各做30-50次。方法：吸气时提肛，呼气时放松。散步、太极拳等有氧运动亦有益。	化腐期（术后1-7天）：创面分泌物较多，以祛腐为主，使用九华膏纱条换药。生肌期（7-14天）：创面渐洁净，以生肌为主，改用生肌散。收口期（14天后）：创面缩小，促进愈合，使用珍珠散。术后坚持每日温水坐浴，定期扩肛。	["长强：主穴，直刺0.5-1寸", "承山：配穴，直刺1-1.5寸", "百会：虚证配穴，平刺或灸", "足三里：健脾益气，直刺1-2寸", "脾俞：脾虚配穴", "血海：血热配穴", "曲池：血热配穴"]	苦参30克，地榆30克，槐花20克，五倍子15克，明矾10克。煎水熏洗，每日2-3次，每次15-20分钟。	["便血量增多或持续不止", "痔核嵌顿肿痛剧烈", "肛门剧痛伴发热", "大便习惯改变或便中带血需排除肠道肿瘤"]	2026-08-14 12:16:51.337064+00
cc5fce8d-ce49-4900-bc22-1c9b6e263fbf	\N	肛裂	肛裂预防与保健指南	["保持大便软化通畅，多食蔬果纤维", "便后温水坐浴，保持肛门清洁", "避免腹泻和便秘", "及时治疗肛窦炎", "避免过度用力排便", "便后轻柔擦拭，避免损伤"]	多食富含纤维的蔬菜水果，如芹菜、菠菜、香蕉等。多饮水，保持大便软化。忌食辛辣刺激食物。	养成定时排便习惯，便意来时不要忍便。便后温水坐浴可缓解肛门括约肌痉挛。	适当运动促进肠蠕动。提肛运动可增强肛门括约肌功能。避免久坐。	术后每日温水坐浴2-3次，保持创面清洁。局部外用九华膏促进愈合。口服润肠通便之品（麻仁丸等）。避免便秘，保持大便通畅。	["长强：主穴，缓解疼痛", "承山：配穴，止痛", "大肠俞：调理大肠功能", "支沟：通便", "血海：血热配穴", "太冲：气滞配穴"]	苦参20克，黄柏15克，地榆20克，槐花15克，五倍子10克。煎水温洗，每日2-3次。	["疼痛持续加重", "肛裂经久不愈超过2月", "出现肛门狭窄", "形成皮赘或哨兵痔"]	2026-08-14 12:16:51.337071+00
8ed40d6e-0261-44ec-866e-77f932dc2659	\N	肛周脓肿	肛周脓肿预防与保健指南	["保持肛门清洁干燥", "及时治疗肛窦炎和肛乳头炎", "避免辛辣刺激食物", "增强体质，避免过度疲劳", "糖尿病患者控制血糖", "避免肛门外伤"]	饮食清淡，忌食辛辣刺激、油腻食物。多食新鲜蔬果，保持大便通畅。	保持肛周清洁卫生，便后温水清洗。增强体质，避免劳累。糖尿病患者积极控制血糖。	适度运动增强体质，但急性期应休息。待脓肿治愈后可恢复正常运动。	术后充分引流，每日换药，冲洗脓腔。内服清热解毒之品（五味消毒饮等）。注意观察有无肛瘘形成。保持创面清洁，按时换药直至愈合。	["长强：主穴，清热解毒", "会阴：局部取穴", "大肠俞：调理大肠", "曲池：清热解毒", "合谷：热毒盛配穴", "血海：热毒盛配穴"]	金银花30克，野菊花20克，蒲公英30克，地丁20克，苦参20克。煎水熏洗，早期促进消散，后期促进愈合。	["高热不退或寒战", "局部肿痛迅速扩大", "出现尿潴留", "脓肿破溃后形成肛瘘"]	2026-08-14 12:16:51.337075+00
76190f34-671c-4196-8fe8-0607d5ba12f2	\N	直肠脱垂	直肠脱垂预防与保健指南	["增强体质，适当锻炼", "积极治疗慢性咳嗽、便秘、腹泻", "避免蹲厕过久和过度用力", "坚持提肛运动", "小儿注意营养，防止久泻", "老年人避免重体力劳动"]	营养均衡，增强体质。老年人多食易消化食物，保持大便通畅。小儿注意营养，防止腹泻。	养成良好排便习惯，避免蹲厕过久。坚持提肛锻炼。治疗慢性咳嗽、便秘等诱因。	提肛运动：每日3-5次，每次30-50下。仰卧起坐、深蹲等可增强腹肌和盆底肌。老年人量力而行。	术后卧床休息，控制排便3天。进食少渣饮食。口服补中益气丸巩固。坚持提肛运动。避免重体力劳动和腹压增高活动。	["百会：升阳举陷，灸法更佳", "长强：主穴，提肛固脱", "大肠俞：调理大肠", "足三里：健脾益气", "气海：益气固脱，可灸", "脾俞：脾虚配穴"]	五倍子30克，明矾15克，石榴皮20克。煎水坐浴，有收敛固涩作用。每日1-2次。	["脱出物无法回纳", "脱出物发生嵌顿水肿", "伴有便血或黏液便", "合并其他肛肠疾病"]	2026-08-14 12:16:51.337079+00
77f87a4e-998e-4c1b-8147-43c7d0d52d5a	\N	肛门疣赘	肛门疣赘及湿疹预防保健指南	["保持肛门清洁干燥", "避免搔抓刺激", "穿宽松透气内衣", "积极治疗原发病如痔疮、肛瘘", "避免潮湿和过度清洗", "调节情绪，避免精神紧张"]	忌食辛辣刺激、鱼虾海鲜等发物。饮食清淡，多食新鲜蔬果。戒烟限酒。	保持肛周清洁干燥，便后温水清洗，软布擦干。避免搔抓。穿纯棉透气内裤，勤换洗。	适度运动增强体质。避免久坐潮湿环境。保持心情舒畅。	术后保持创面清洁。按医嘱换药。避免刺激性食物。观察有无复发。	["长强：局部取穴", "大肠俞：调理大肠", "曲池：清热止痒", "血海：养血止痒", "三阴交：滋阴止痒"]	苦参30克，地肤子20克，白鲜皮20克，黄柏15克，蛇床子15克。煎水熏洗，清热燥湿止痒。	["瘙痒剧烈影响生活", "疣赘迅速增大", "出现破溃流脓", "顽固不愈超过三月需排除其他疾病"]	2026-08-14 12:16:51.337082+00
daa975e0-0fbb-4868-a020-d5e793bd7fb2	\N	肛门疖肿	肛门疖肿预防保健指南	["保持肛周皮肤清洁", "避免摩擦和外伤", "增强体质，避免熬夜劳累", "糖尿病患者控制血糖", "避免辛辣刺激饮食", "及时治疗毛囊炎、疖肿"]	清淡饮食，忌食辛辣刺激、油腻煎炸食物。多食新鲜蔬果，多饮水。	保持肛周清洁卫生。穿宽松透气内衣。避免局部摩擦刺激。增强体质。	适度运动增强免疫力。急性期应休息，避免剧烈运动。	保持创面清洁，按时换药。内服清热解毒中药。避免再次感染。	["阿是穴：局部取穴", "曲池：清热解毒", "合谷：清热消肿", "足三里：健脾益气"]	金银花20克，野菊花15克，蒲公英20克，地丁15克。煎水温洗，清热解毒消肿。	["疖肿迅速扩大", "伴有发热畏寒", "局部红肿范围扩大", "反复发作需查血糖等"]	2026-08-14 12:16:51.337089+00
\.


--
-- Data for Name: safety_rules; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.safety_rules (id, rule_type, severity, herb_name, conflicting_herbs, contraindication_info, max_dosage, warning_message, suggestion, is_active, created_at) FROM stdin;
ddb7f01a-7587-4262-b48e-5532d677850c	incompatibility	critical	甘草	["甘遂", "大戟", "海藻", "芫花"]	{"type": "十八反", "description": "中药配伍大忌"}	\N	甘草 与 甘遂, 大戟, 海藻, 芫花 相反，属于十八反配伍禁忌，严禁同用！	必须去除 甘草 或 甘遂, 大戟, 海藻, 芫花 之一	1	2026-08-14 12:17:01.040843+00
8881c59a-4fc1-44b7-93a6-ea3e5440a407	incompatibility	critical	乌头	["贝母", "瓜蒌", "半夏", "白蔹", "白及"]	{"type": "十八反", "description": "中药配伍大忌"}	\N	乌头 与 贝母, 瓜蒌, 半夏, 白蔹, 白及 相反，属于十八反配伍禁忌，严禁同用！	必须去除 乌头 或 贝母, 瓜蒌, 半夏, 白蔹, 白及 之一	1	2026-08-14 12:17:01.040843+00
15cba615-3da9-4b05-a732-0ac124b905a6	incompatibility	critical	藜芦	["人参", "沙参", "丹参", "玄参", "细辛", "芍药"]	{"type": "十八反", "description": "中药配伍大忌"}	\N	藜芦 与 人参, 沙参, 丹参, 玄参, 细辛, 芍药 相反，属于十八反配伍禁忌，严禁同用！	必须去除 藜芦 或 人参, 沙参, 丹参, 玄参, 细辛, 芍药 之一	1	2026-08-14 12:17:01.040843+00
4911f46c-fbfb-40f4-bd50-6729bbacaad8	incompatibility	warning	硫黄	["朴硝"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	硫黄 畏 朴硝，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
cb5f65b9-e770-4e75-bf22-15831428d286	incompatibility	warning	水银	["砒霜"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	水银 畏 砒霜，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
4c085405-6f80-4a58-98b8-60b77364246c	incompatibility	warning	狼毒	["密陀僧"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	狼毒 畏 密陀僧，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
b549aa3e-8cf2-4ee8-ad8c-0f4c79082f94	incompatibility	warning	巴豆	["牵牛子"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	巴豆 畏 牵牛子，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
7cab57be-90d1-4f7e-b325-7b4c31a386ef	incompatibility	warning	丁香	["郁金"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	丁香 畏 郁金，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
5951b0c4-856d-4a7e-b6aa-9d792a1b00a1	incompatibility	warning	牙硝	["三棱"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	牙硝 畏 三棱，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
8002e67b-652b-408d-8f3f-32b283cca061	incompatibility	warning	川乌	["犀角"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	川乌 畏 犀角，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
fe729511-937f-4ca9-a7e7-b75ed03c1881	incompatibility	warning	草乌	["犀角"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	草乌 畏 犀角，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
31a69ea8-fa06-4219-8f7f-2015b2206245	incompatibility	warning	人参	["五灵脂"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	人参 畏 五灵脂，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
345ff378-9be5-483c-b0c8-0c15eb803416	incompatibility	warning	官桂	["石脂"]	{"type": "十九畏", "description": "中药配伍警戒"}	\N	官桂 畏 石脂，不宜同用	建议分开使用或调整方剂	1	2026-08-14 12:17:01.040843+00
8b5c9002-8df9-45d5-b506-d31b269ecce3	pregnancy	critical	麝香	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：麝香	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
1001a565-d28e-49e9-a27e-6b55c944edba	pregnancy	critical	斑蝥	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：斑蝥	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
90a18235-b96d-45c7-b671-f75d941f0bcf	pregnancy	critical	天雄	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：天雄	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
fe143a28-78fe-4168-b73e-ac7cd751f9da	pregnancy	critical	巴豆	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：巴豆	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
92c24477-7577-4c12-9d57-685c08f0c7cd	pregnancy	critical	牵牛子	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：牵牛子	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
b9f13891-c1cd-48df-b4ab-4d6ce15ba535	pregnancy	critical	大戟	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：大戟	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
cd746817-c734-4476-9995-735f5e1c32c8	pregnancy	critical	芫花	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：芫花	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
470e7d06-25cb-4feb-b40d-c6fbf1290161	pregnancy	critical	甘遂	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：甘遂	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
29f5090e-b3a8-4cb4-a4b1-c92cdcd1d745	pregnancy	critical	商陆	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：商陆	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
d1465483-c515-40d1-8719-f74702c0a49e	pregnancy	critical	蜈蚣	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：蜈蚣	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
657d801a-8f97-4208-ad50-a89e0b3247b1	pregnancy	critical	水蛭	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：水蛭	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
07c3bb6f-431d-479c-b445-7a99e58eb616	pregnancy	critical	虻虫	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：虻虫	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
a378e323-2a3f-4f10-b91e-7ff8a9be77d4	pregnancy	critical	三棱	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：三棱	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
ba9d18d1-acf2-4594-970a-0172309a697e	pregnancy	critical	莪术	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：莪术	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
1691fb93-dde7-422b-84f8-ae779994f0a0	pregnancy	critical	水银	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：水银	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
bde5e838-1d7a-4de1-9f0e-893086d46cb5	pregnancy	critical	砒霜	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：砒霜	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
0b0f4725-982a-43e6-9477-27bc9828bf55	pregnancy	critical	雄黄	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：雄黄	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
b812a834-642a-4e07-a278-ae177e8a0015	pregnancy	critical	轻粉	null	{"level": "严格禁用", "population": "孕妇"}	\N	孕妇严格禁用：轻粉	必须更换其他药物	1	2026-08-14 12:17:01.040843+00
e6f662d1-86d6-450a-b739-a57e376a192f	pregnancy	warning	桃仁	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：桃仁	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
77be0a53-850a-45e1-b134-9dba3aa17f91	pregnancy	warning	红花	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：红花	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
65d197dc-2f62-4a94-8591-fb1aaa69296a	pregnancy	warning	牛膝	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：牛膝	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
a467f616-f1ca-4030-a204-de612920a0d8	pregnancy	warning	大黄	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：大黄	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
b95711a6-5423-40dd-a16c-28326c08d0da	pregnancy	warning	枳实	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：枳实	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
97a3ded0-5789-4211-b1d2-9a85adf2ba37	pregnancy	warning	附子	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：附子	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
815557b8-9f76-4aaf-b1af-c9ebef44eed8	pregnancy	warning	肉桂	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：肉桂	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
548e685c-43d9-4e63-a627-9b3593256c1c	pregnancy	warning	干姜	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：干姜	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
d0500ba0-e16c-4a52-b763-e3b19eadfb0d	pregnancy	warning	半夏	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：半夏	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
e2394a03-d20c-4bd4-a174-ab907f4288b3	pregnancy	warning	南星	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：南星	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
c1b1f098-d9d5-48db-a546-812dba8ed56d	pregnancy	warning	通草	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：通草	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
d18fc460-3d8b-4cdd-9ba2-b60c0b1492e6	pregnancy	warning	瞿麦	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：瞿麦	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
88dcdc25-f8ea-4ec8-a337-24165a446db5	pregnancy	warning	木通	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：木通	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
05e8ea8b-7abb-4f38-b573-eb42e9131ae5	pregnancy	warning	薏苡仁	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：薏苡仁	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
dc7a23e8-df36-413e-b18b-39ff57ce18d2	pregnancy	warning	代赭石	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：代赭石	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
7e623166-e55d-4174-ad30-2f67ef817c88	pregnancy	warning	芒硝	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：芒硝	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
baba7e61-a0ff-4987-8260-00d6b3560fd4	pregnancy	warning	牡丹皮	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：牡丹皮	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
9368938a-e077-4ab2-8d6f-339e94a3000d	pregnancy	warning	茜草	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：茜草	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
53e73e6a-faf3-4fdd-8210-37dbe43f60c8	pregnancy	warning	苏木	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：苏木	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
094df5bb-7484-43f1-a740-6288540be41e	pregnancy	warning	刘寄奴	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：刘寄奴	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
4422d6ac-6b30-453f-9c06-92fd19d99776	pregnancy	warning	益母草	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：益母草	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
980f844a-5299-474c-8267-63cd3ad8637a	pregnancy	warning	茺蔚子	null	{"level": "慎用", "population": "孕妇"}	\N	孕妇慎用：茺蔚子	请谨慎使用，密切观察	1	2026-08-14 12:17:01.040843+00
dda71f91-ad5c-415b-94de-ed416454aab5	dosage	critical	附子	null	{"unit": "克/日", "max_dosage": 15, "typical_dosage": 6}	15	附子 最大安全剂量 15克/日（常用量 6克）	大剂量需久煎60分钟以上，防乌头碱中毒	1	2026-08-14 12:17:01.040843+00
18b7dce0-6d6b-4727-9396-5ae517e83b6a	dosage	critical	细辛	null	{"unit": "克/日", "max_dosage": 3, "typical_dosage": 1}	3	细辛 最大安全剂量 3克/日（常用量 1克）	细辛不过钱（3克），过量可致呼吸抑制	1	2026-08-14 12:17:01.040843+00
406b4dac-1122-4fc8-b655-dc56c976f664	dosage	critical	马钱子	null	{"unit": "克/日", "max_dosage": 0.6, "typical_dosage": 0.3}	0.6	马钱子 最大安全剂量 0.6克/日（常用量 0.3克）	剧毒药，需炮制，过量致惊厥	1	2026-08-14 12:17:01.040843+00
a5fd2641-e89b-47b2-8816-72c9f043dc44	dosage	critical	川乌	null	{"unit": "克/日", "max_dosage": 6, "typical_dosage": 3}	6	川乌 最大安全剂量 6克/日（常用量 3克）	需先煎30-60分钟，生川乌禁用	1	2026-08-14 12:17:01.040843+00
45d87e62-860d-4716-ad0d-fdc9d406ca3a	dosage	critical	草乌	null	{"unit": "克/日", "max_dosage": 6, "typical_dosage": 3}	6	草乌 最大安全剂量 6克/日（常用量 3克）	需先煎30-60分钟，生草乌禁用	1	2026-08-14 12:17:01.040843+00
b22ad6f7-f616-4e44-a414-8dddd0797410	dosage	critical	大黄	null	{"unit": "克/日", "max_dosage": 15, "typical_dosage": 6}	15	大黄 最大安全剂量 15克/日（常用量 6克）	大剂量致泻，孕妇慎用	1	2026-08-14 12:17:01.040843+00
ab754a17-c98e-45e0-bf91-84d246755aea	dosage	critical	芒硝	null	{"unit": "克/日", "max_dosage": 15, "typical_dosage": 10}	15	芒硝 最大安全剂量 15克/日（常用量 10克）	后下或冲服，孕妇禁用	1	2026-08-14 12:17:01.040843+00
62be7b01-bbb1-44ee-a54d-172c7326933f	dosage	critical	巴豆	null	{"unit": "克/日", "max_dosage": 0.3, "typical_dosage": 0.1}	0.3	巴豆 最大安全剂量 0.3克/日（常用量 0.1克）	峻下药，去油用，孕妇禁用	1	2026-08-14 12:17:01.040843+00
e615e4fa-49f0-4289-85db-14d9211a12be	dosage	critical	甘遂	null	{"unit": "克/日", "max_dosage": 1.5, "typical_dosage": 0.5}	1.5	甘遂 最大安全剂量 1.5克/日（常用量 0.5克）	峻下逐水药，醋炙用	1	2026-08-14 12:17:01.040843+00
b726afb1-3cdd-4060-914a-6cccb2a5c0b0	dosage	critical	芫花	null	{"unit": "克/日", "max_dosage": 6, "typical_dosage": 3}	6	芫花 最大安全剂量 6克/日（常用量 3克）	峻下逐水药，醋炙用	1	2026-08-14 12:17:01.040843+00
242abb6d-4e3f-433a-bd9d-1095eb03009c	dosage	critical	商陆	null	{"unit": "克/日", "max_dosage": 6, "typical_dosage": 3}	6	商陆 最大安全剂量 6克/日（常用量 3克）	有毒，需炮制	1	2026-08-14 12:17:01.040843+00
b5e5807e-ac9a-4096-806c-c7ef3c3c9d42	dosage	critical	雄黄	null	{"unit": "克/日", "max_dosage": 1.5, "typical_dosage": 0.3}	1.5	雄黄 最大安全剂量 1.5克/日（常用量 0.3克）	外用为主，内服需微量	1	2026-08-14 12:17:01.040843+00
07624aad-e089-47d2-9979-b4f7ba6ace92	dosage	critical	轻粉	null	{"unit": "克/日", "max_dosage": 0.3, "typical_dosage": 0.1}	0.3	轻粉 最大安全剂量 0.3克/日（常用量 0.1克）	含汞，外用为主	1	2026-08-14 12:17:01.040843+00
8f5f8890-5af2-4534-a7a7-243f3fcebebd	dosage	critical	朱砂	null	{"unit": "克/日", "max_dosage": 1, "typical_dosage": 0.3}	1	朱砂 最大安全剂量 1克/日（常用量 0.3克）	含汞，不入煎剂，冲服	1	2026-08-14 12:17:01.040843+00
\.


--
-- Data for Name: stock_alerts; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.stock_alerts (id, tenant_id, medicine_id, alert_type, message, is_resolved, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: stock_transactions; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.stock_transactions (id, tenant_id, medicine_id, batch_id, transaction_type, quantity, reason, reference_id, operator_id, created_at) FROM stdin;
\.


--
-- Data for Name: symptom_dictionary; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.symptom_dictionary (id, category, subcategory, name, display_name, options, weight, description, created_at) FROM stdin;
d370a90b-5df5-4f2e-9653-5f740cb61628	望诊	舌质	tongue_color	舌质	{"type": "select", "choices": ["淡红", "红", "深红", "淡白", "紫暗", "青紫"]}	3	\N	2026-08-14 12:16:52.048334+00
9147ae7e-b08f-4799-9c0e-32d29afa7fae	望诊	舌苔	tongue_coating	舌苔	{"type": "select", "choices": ["薄白", "黄", "黄腻", "白厚", "少苔", "无苔", "腻苔"]}	3	\N	2026-08-14 12:16:52.048334+00
6bf9f335-0802-4d0c-ac6e-acf1c25ddb96	望诊	舌形	tongue_shape	舌形	{"type": "select", "choices": ["正常", "胖大齿痕", "瘦薄", "裂纹"]}	2	\N	2026-08-14 12:16:52.048334+00
fd55e2f7-5bc6-4a1d-8aa2-880de3c2b2f4	望诊	肛门局部	anal_color	肛门色泽	{"type": "select", "choices": ["鲜红", "暗红", "紫暗", "淡白", "正常"]}	2	\N	2026-08-14 12:16:52.048334+00
a5da34af-88b9-4315-8624-0ad91f58d264	望诊	肛门局部	anal_swelling	肿胀程度	{"type": "select", "choices": ["无", "轻度", "中度", "重度"]}	2	\N	2026-08-14 12:16:52.048334+00
c5e400b4-d90b-4474-b75a-974678f5e9d8	望诊	肛门局部	prolapse	有无脱出	{"type": "select", "choices": ["无", "便时脱出自回", "便时脱出需手托", "常脱出"]}	3	\N	2026-08-14 12:16:52.048334+00
0c07a3b8-596c-4b55-8942-992a95358f26	望诊	肛门局部	secretion	分泌物	{"type": "select", "choices": ["无", "血性", "脓性", "粘液性"]}	2	\N	2026-08-14 12:16:52.048334+00
5168a505-682a-49ad-9633-be955ca42ce0	望诊	肛门局部	ulceration	糜烂溃疡	{"type": "select", "choices": ["无", "轻度", "明显"]}	2	\N	2026-08-14 12:16:52.048334+00
aa0f1b96-e29c-4338-927b-d6ab57c5ad73	闻诊	气味	odor	气味	{"type": "select", "choices": ["无异味", "腥臭", "恶臭"]}	2	\N	2026-08-14 12:16:52.048334+00
10e7963e-4863-4c1f-b4be-0a3275d8ac73	闻诊	语声	voice	语声	{"type": "select", "choices": ["洪亮", "低微", "气短懒言"]}	1	\N	2026-08-14 12:16:52.048334+00
928db37f-8b90-4058-abd5-1d3c796d8baf	问诊	主症	bleeding	便血	{"type": "compound", "fields": {"color": {"type": "select", "label": "颜色", "choices": ["鲜红", "暗红", "紫黑"]}, "timing": {"type": "select", "label": "时机", "choices": ["便前", "便中", "便后", "不定"]}, "volume": {"type": "select", "label": "量", "choices": ["点滴", "少量", "中量", "大量", "射血"]}, "present": {"type": "boolean", "label": "是否便血"}}}	5	\N	2026-08-14 12:16:52.048334+00
b09c450f-72f8-492e-9da6-3fcf079b3fa7	问诊	主症	pain	疼痛	{"type": "compound", "fields": {"degree": {"type": "select", "label": "程度", "choices": ["轻度", "中度", "重度", "剧烈"]}, "nature": {"type": "select", "label": "性质", "choices": ["刺痛", "胀痛", "灼痛", "隐痛", "跳痛"]}, "timing": {"type": "select", "label": "时机", "choices": ["便时", "便后持续", "夜间加重", "持续痛"]}, "present": {"type": "boolean", "label": "是否疼痛"}}}	5	\N	2026-08-14 12:16:52.048334+00
b95e1ebb-377c-42ec-a629-4f99dee06881	问诊	主症	prolapse_symptom	脱出	{"type": "compound", "fields": {"degree": {"type": "select", "label": "程度", "choices": ["I度", "II度", "III度", "IV度"]}, "present": {"type": "boolean", "label": "是否脱出"}}}	4	\N	2026-08-14 12:16:52.048334+00
8d05b336-d6ba-4dd9-97fd-d5e6010ca913	问诊	主症	swelling_symptom	肿胀	{"type": "compound", "fields": {"present": {"type": "boolean", "label": "是否肿胀"}, "location": {"type": "select", "label": "部位", "choices": ["内痔", "外痔", "混合痔", "肛周"]}}}	3	\N	2026-08-14 12:16:52.048334+00
d5f6bdfd-1c5a-41a9-9acc-948361d50f88	问诊	主症	itching	瘙痒	{"type": "compound", "fields": {"degree": {"type": "select", "label": "程度", "choices": ["轻度", "中度", "重度"]}, "present": {"type": "boolean", "label": "是否瘙痒"}}}	3	\N	2026-08-14 12:16:52.048334+00
7f24ea06-8241-4643-9e4e-af9fddd87f29	问诊	次症	stool_condition	大便	{"type": "select", "choices": ["正常", "干结", "溏泄", "秘结", "先干后溏"]}	2	\N	2026-08-14 12:16:52.048334+00
00dcd2d4-0883-4e88-b824-35435a3a3dc7	问诊	次症	urination	小便	{"type": "select", "choices": ["正常", "短赤", "清长", "频数"]}	2	\N	2026-08-14 12:16:52.048334+00
5897a277-014d-427f-a7c4-e1663b51e732	问诊	次症	thirst	口渴	{"type": "select", "choices": ["不渴", "口渴喜冷饮", "口渴喜热饮", "口干不欲饮"]}	2	\N	2026-08-14 12:16:52.048334+00
c80c9d91-fa10-4ff8-a69f-75df840fab32	问诊	次症	fever	发热	{"type": "select", "choices": ["无", "低热", "高热", "恶寒发热", "潮热"]}	2	\N	2026-08-14 12:16:52.048334+00
41299846-a7a3-4b64-8972-8be34ecd6b7c	问诊	次症	fatigue	神疲乏力	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
fb64ac02-13a0-4695-8132-5a83c8f7b752	问诊	次症	pale_complexion	面色无华	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
20dd3191-6474-4b47-95b5-1c7b42a08ac5	问诊	次症	poor_appetite	食欲不振	{"type": "boolean"}	1	\N	2026-08-14 12:16:52.048334+00
763f38c1-b9e2-444e-ba62-d90f958f2d33	问诊	次症	insomnia	心烦失眠	{"type": "boolean"}	1	\N	2026-08-14 12:16:52.048334+00
ac0ea60d-d305-4f27-aedd-cd736370be6b	问诊	次症	lumbar_soreness	腰膝酸软	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
f2517b73-ff00-4d96-8b53-260074f8f469	问诊	次症	bitter_mouth	口苦	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
7f7ccf56-3006-463c-9a71-fd0e4801a0d1	切诊	脉象	pulse_floating	浮脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
33577328-996f-4cf8-b0e2-9c3a56330b66	切诊	脉象	pulse_deep	沉脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
7b20385b-fae2-4459-a237-d33b66d19085	切诊	脉象	pulse_slow	迟脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
14fa8b2b-0310-4760-8f2d-a8d498a9bbd6	切诊	脉象	pulse_rapid	数脉	{"type": "boolean"}	3	\N	2026-08-14 12:16:52.048334+00
4a08d04d-1d4d-4d06-af5c-0c7f33e43297	切诊	脉象	pulse_wiry	弦脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
f4328964-0277-4b5c-84de-056088552810	切诊	脉象	pulse_slippery	滑脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
4ff74f6c-4e06-4fa2-a4fe-7ff8f40e7a2b	切诊	脉象	pulse_fine	细脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
848006b8-adfc-4a76-80b9-1f6e93620993	切诊	脉象	pulse_weak	弱脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
5a90cd65-a376-4b1b-a648-7cbb6b2b1ae9	切诊	脉象	pulse_surging	洪脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
fca24dd4-8ffa-49dc-89f1-b710995660d4	切诊	脉象	pulse_full	实脉	{"type": "boolean"}	2	\N	2026-08-14 12:16:52.048334+00
20aae780-3127-429d-b9d2-414592e1fe40	切诊	腹诊	abdomen	腹部	{"type": "select", "choices": ["腹部柔软", "腹胀", "按之痛"]}	1	\N	2026-08-14 12:16:52.048334+00
84c7e577-7a3c-40e2-a60c-d66d2e0dbbdc	切诊	肛门指诊	sphincter	括约肌	{"type": "select", "choices": ["正常", "松弛", "痉挛"]}	2	\N	2026-08-14 12:16:52.048334+00
23ea1690-3005-4d35-bec5-bcd995993332	切诊	肛门指诊	mass	触及肿块	{"type": "compound", "fields": {"size": {"type": "text", "label": "大小"}, "present": {"type": "boolean", "label": "有无肿块"}, "texture": {"type": "select", "label": "质地", "choices": ["软", "中等", "硬"]}, "location": {"type": "text", "label": "位置"}}}	2	\N	2026-08-14 12:16:52.048334+00
\.


--
-- Data for Name: symptom_templates; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.symptom_templates (id, tenant_id, created_by, disease_type, syndrome_code, template_name, description, symptoms_data, template_type, usage_count, is_active, created_at, updated_at) FROM stdin;
5b3fdb84-da42-4584-ac09-a6281bd2feda	\N	\N	便秘	BM_WCRJ	胃肠热结（一键辨证）	治则：清热通腑，润肠导滞；舌脉：舌红苔黄燥，脉滑数	{"urination": "短赤", "pulse_rapid": true, "bitter_mouth": true, "pulse_slippery": true, "tongue_coating": "黄", "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
4bd490f3-7dd5-430e-9a3f-614ae32944ce	\N	\N	便秘	BM_QXLK	气血两亏（一键辨证）	治则：补气养血，润肠通便；舌脉：舌淡苔薄，脉细弱	{"fatigue": true, "insomnia": true, "pulse_fine": true, "pulse_weak": true, "tongue_color": "淡白", "pale_complexion": true, "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
8b0149a8-ff15-4b6e-9618-d88b168fe10f	\N	\N	便秘	BM_DCJJ	大肠津亏（一键辨证）	治则：增液润肠，通便导下；舌脉：舌红少津，脉细	{"thirst": "口干不欲饮", "pulse_fine": true, "tongue_color": "红", "tongue_coating": "少苔", "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
d1e3473c-ee18-48b7-b083-1a9e95b215ba	\N	\N	便秘	BM_YXBJ	阴虚便结（一键辨证）	治则：滋阴润肠，增水行舟；舌脉：舌红少苔，脉细数	{"fever": "潮热", "insomnia": true, "pulse_fine": true, "pulse_rapid": true, "tongue_color": "红", "tongue_coating": "少苔", "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
59382a58-6838-470a-b61e-420e89689c34	\N	\N	便秘	BM_QXBJ	气虚便结（一键辨证）	治则：益气润肠，健脾通便；舌脉：舌淡苔薄，脉虚	{"fatigue": true, "pulse_weak": true, "tongue_color": "淡", "poor_appetite": true, "pale_complexion": true, "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
c63fd3e9-a433-46d6-983f-1cb2b16e6b86	\N	\N	便秘	BM_DCHJ	大肠寒结（一键辨证）	治则：温里散寒，通便止痛；舌脉：舌淡苔白滑，脉沉迟	{"abdomen": "腹胀", "pulse_deep": true, "pulse_slow": true, "tongue_coating": "白滑", "stool_condition": "秘结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
639aba81-15e0-4c2a-a4f6-de6bb03f08e1	\N	\N	便秘	BM_QZBX	气滞不行（一键辨证）	治则：行气导滞，通便除胀；舌脉：舌淡红苔薄，脉弦	{"abdomen": "腹胀", "insomnia": true, "pulse_wiry": true, "poor_appetite": true, "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
badf9f88-0ae1-4be5-b806-2c163806f441	\N	\N	痔疮	ZC_SRYS	湿热瘀滞型（一键辨证）	治则：清热除湿，活血化瘀；舌脉：舌质红，苔黄腻，脉弦滑数	{"pain": {"present": true}, "urination": "短赤", "pulse_wiry": true, "bitter_mouth": true, "anal_swelling": "中度", "tongue_coating": "黄腻", "stool_condition": "干结", "swelling_symptom": {"present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
4ae250c2-22ed-4f5f-aacc-00fe3430cc6e	\N	\N	痔疮	ZC_QXKS	气血亏损，气不摄血（一键辨证）	治则：补气益血；舌脉：舌质淡，苔薄白，脉细弱	{"fatigue": true, "bleeding": {"color": "淡红", "present": true}, "pulse_fine": true, "pulse_weak": true, "tongue_color": "淡白", "poor_appetite": true, "pale_complexion": true, "stool_condition": "干结", "prolapse_symptom": {"present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
23984a9e-5ff1-4e9b-a61d-f4705af3a649	\N	\N	痔疮	ZC_QZXY	气滞血瘀（一键辨证）	治则：活血化瘀，行气止痛；舌脉：{'pulse': '脉弦或涩', 'tongue': '舌质紫暗或有瘀斑'}	{"pain": {"nature": "刺痛", "present": true}, "bleeding": {"color": "暗红", "present": true}, "anal_color": "紫暗", "pulse_wiry": true, "tongue_color": "紫暗", "stool_condition": "干结", "swelling_symptom": {"present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
48112239-c51e-4230-b1ab-d8bbea30644d	\N	\N	痔疮	ZC_SHINY	实热内蕴，血热肠燥（一键辨证）	治则：清热止血，润肠通便；舌脉：{'pulse': '脉弦数或数', 'tongue': '舌红苔黄'}	{"pain": {"present": true}, "bleeding": {"color": "鲜红", "present": true}, "urination": "短赤", "pulse_wiry": true, "pulse_rapid": true, "bitter_mouth": true, "tongue_color": "红", "tongue_coating": "黄", "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
bd0cbc51-d909-4882-af44-c546909379dd	\N	\N	痔疮	ZC_SRXZ	湿热下注，气滞血瘀（一键辨证）	治则：清热利湿，活血化瘀；舌脉：{'pulse': '脉弦滑数', 'tongue': '舌质红，苔黄腻'}	{"pain": {"nature": "胀痛", "present": true}, "urination": "短赤", "anal_color": "暗红", "pulse_wiry": true, "bitter_mouth": true, "tongue_color": "红", "anal_swelling": "中度", "poor_appetite": true, "pulse_slippery": true, "tongue_coating": "黄腻", "swelling_symptom": {"present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
60a4e75e-ce74-4870-9919-ad229689668c	\N	\N	痔疮	ZC_PXQX	脾虚气陷（一键辨证）	治则：补中益气，升阳举陷；舌脉：{'pulse': '脉弱或虚', 'tongue': '舌淡胖齿痕，苔薄白'}	{"fatigue": true, "bleeding": {"volume": "点滴", "present": true}, "pulse_weak": true, "tongue_color": "淡红", "tongue_shape": "胖大齿痕", "poor_appetite": true, "lumbar_soreness": true, "pale_complexion": true, "stool_condition": "溏泄", "prolapse_symptom": {"degree": "II度", "present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
2023e949-090a-4d8a-8e60-fceb45b8a678	\N	\N	直肠脱垂	ZC_QXLX	气血两虚型（一键辨证）	治则：补气养血，升举固脱；舌脉：舌质淡红，苔薄白，脉细弱	{"fatigue": true, "bleeding": {"color": "淡红"}, "insomnia": true, "pulse_fine": true, "pulse_weak": true, "tongue_color": "淡白", "poor_appetite": true, "pale_complexion": true, "prolapse_symptom": {"degree": "III度", "present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
21b11d7d-6daa-45a8-8e70-6c5ecc898a91	\N	\N	直肠脱垂	ZC_ZQXX	中气下陷（一键辨证）	治则：补中益气，升阳举陷；舌脉：舌淡或胖大齿痕，脉虚弱	{"fatigue": true, "pulse_weak": true, "poor_appetite": true, "pale_complexion": true, "stool_condition": "溏泄", "prolapse_symptom": {"present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
01bcfc46-419a-4fde-bdbd-9dc8519cfb68	\N	\N	直肠脱垂	ZCTH_SG	肾虚不固型（一键辨证）	治则：补肾纳气，温阳固脱；舌脉：舌淡或淡胖，脉沉细/弱	{"fatigue": true, "urination": "频数", "pulse_deep": true, "lumbar_soreness": true, "pale_complexion": true, "stool_condition": "溏泄", "prolapse_symptom": {"present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
c118f6f6-cf09-4738-bf6a-e6619c370fd3	\N	\N	直肠脱垂	ZCTH_XE	小儿气血未壮型（一键辨证）	治则：补中益气，升阳举陷；结合原发腹泻调治；舌脉：舌淡，脉虚弱	{"fatigue": true, "age_group": "小儿", "tongue_color": "淡", "poor_appetite": true, "pale_complexion": true, "stool_condition": "溏泄", "prolapse_symptom": {"present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
06dc3c8b-cef0-4ec6-9b1d-c21eda426fab	\N	\N	直肠脱垂	ZC_FXKC	肺虚咳喘型（一键辨证）	治则：温肺益气，定喘固脱；舌脉：舌淡，苔白滑，脉沉细略滑	{"cough": true, "fatigue": true, "pulse_weak": true, "tongue_color": "淡", "tongue_coating": "白滑", "pale_complexion": true, "prolapse_symptom": {"present": true}, "shortness_of_breath": true}	system	0	1	2026-08-14 12:16:59.668009+00	\N
719031bd-2d94-47eb-a083-bc8f4fcac58b	\N	\N	直肠脱垂	ZCTH_SR	湿热下注努挣型（一键辨证）	治则：清利湿热，通便降浊，兼顾升提；舌脉：舌红苔黄腻，脉滑数	{"urination": "短赤", "bitter_mouth": true, "anal_swelling": "中度", "pulse_slippery": true, "tongue_coating": "黄腻", "stool_condition": "干结", "prolapse_symptom": {"present": true}}	system	0	1	2026-08-14 12:16:59.668009+00	\N
e150a57d-7fe8-45e0-a520-32ee188bc015	\N	\N	肛周脓肿	GZ_XR	虚热型脓肿（一键辨证）	治则：清虚热，散毒气；舌脉：舌质淡，苔薄白，脉弦细弱	{"pain": {"degree": "轻度"}, "fever": "低热", "fatigue": true, "pulse_fine": true, "pulse_weak": true, "night_sweats": true, "tongue_color": "淡", "anal_swelling": "轻度", "pale_complexion": true}	system	0	1	2026-08-14 12:16:59.668009+00	\N
92f3224a-208e-43b1-9db2-41c2292d0f3b	\N	\N	肛周脓肿	GZ_RTYJ	热毒蕴结（一键辨证）	治则：清泻实热，宣散郁结；舌脉：{'pulse': '脉洪数或弦数', 'tongue': '舌红苔黄腻'}	{"odor": "恶臭", "pain": {"degree": "重度", "nature": "跳痛", "present": true}, "fever": "高热", "thirst": "口渴喜冷饮", "urination": "短赤", "pulse_rapid": true, "tongue_color": "红", "anal_swelling": "中度", "pulse_surging": true, "tongue_coating": "黄腻", "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
0fe3084a-77e1-4a31-959a-b1ad46a21787	\N	\N	肛瘘	GL_HFQ	化腐期（一键辨证）	治则：保持引流，清除腐败组织；严禁自行探查或腐蚀；舌脉：局部创面阶段字段	{"secretion": "脓性", "wound_phase": "腐肉"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
1db6eb25-309e-4bb0-b008-5f4f7edad1bd	\N	\N	肛瘘	GL_TDQ	托毒期（一键辨证）	治则：评估主管、支管和死腔，保证脓毒外泄，防止假愈合；舌脉：局部创面阶段字段	{"secretion": "脓性", "wound_phase": "脓液"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
af17ffce-6086-4582-935d-a9bd9b4d8770	\N	\N	肛瘘	GL_SJQ	生肌期（一键辨证）	治则：腐脱管化后促进新鲜肉芽生长，由专业人员换药；舌脉：局部创面阶段字段	{"secretion": "无", "wound_phase": "肉芽"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
a736012e-0835-4d7b-9e2d-de5ef41699e2	\N	\N	肛瘘	GL_SQK	收口期（一键辨证）	治则：检查桥形粘连、残余窦道和假愈合，审慎促进收口；舌脉：局部创面阶段字段	{"wound_phase": "收口", "bridge_adhesion": true}	system	0	1	2026-08-14 12:16:59.668009+00	\N
f1880c63-835e-4eb3-b8a6-30d0c96e8b65	\N	\N	肛裂	GL_SR	湿热证（一键辨证）	治则：清热利湿，润燥止痛；舌脉：舌质红，苔黄腻，脉滑数	{"pain": {"degree": "重度", "present": true}, "secretion": "脓性", "urination": "短赤", "pulse_rapid": true, "bitter_mouth": true, "anal_swelling": "中度", "poor_appetite": true, "tongue_coating": "黄腻", "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
75ee8d7a-6354-4b69-b2c4-e6199e55ea6e	\N	\N	肛裂	GL_YXJK	阴虚津亏（一键辨证）	治则：养阴润燥，润肠通便；舌脉：{'pulse': '脉细数', 'tongue': '舌红少苔或无苔'}	{"pain": {"nature": "灼痛", "present": true}, "thirst": "口干不欲饮", "insomnia": true, "pulse_fine": true, "tongue_color": "红", "tongue_coating": "少苔", "lumbar_soreness": true, "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
f1b964de-7e24-4492-a419-c65eea0c74c6	\N	\N	肛裂	GL_XRCZ	血热肠燥（一键辨证）	治则：凉血止血，养阴润燥；舌脉：{'pulse': '脉数', 'tongue': '舌红苔黄'}	{"pain": {"nature": "刺痛", "timing": "便后持续", "present": true}, "thirst": "口渴喜冷饮", "bleeding": {"color": "鲜红", "timing": "便时", "present": true}, "sphincter": "痉挛", "urination": "短赤", "pulse_rapid": true, "tongue_color": "红", "tongue_coating": "黄", "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
4adf34b4-c9c1-4a39-893d-2c04007b05cd	\N	\N	肛门湿疹	SZ_SRXZ	湿热下注（一键辨证）	治则：清热利湿，祛风止痒；舌脉：舌红苔黄腻，脉弦滑	{"itching": {"present": true}, "urination": "短赤", "pulse_wiry": true, "bitter_mouth": true, "tongue_color": "红", "pulse_slippery": true, "tongue_coating": "黄腻"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
2b53bf20-7f15-4219-afdf-04b26ac59ce4	\N	\N	肛门湿疹	SZ_ZQXJ	中气下陷（脾虚湿蕴）（一键辨证）	治则：补中益气，升阳举陷，兼清湿热；舌脉：舌淡苔薄，脉弱	{"fatigue": true, "itching": {"present": true}, "pulse_weak": true, "tongue_color": "淡", "poor_appetite": true, "pale_complexion": true, "stool_condition": "溏泄"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
781120a3-013e-4cce-a108-971998fe948f	\N	\N	肛门湿疹	SZ_XSFZ	血虚风燥（一键辨证）	治则：养血润燥，祛风止痒；舌脉：舌淡苔薄，脉细	{"fatigue": true, "itching": {"present": true}, "insomnia": true, "pulse_fine": true, "tongue_color": "淡", "pale_complexion": true}	system	0	1	2026-08-14 12:16:59.668009+00	\N
45a4eb02-c9c5-4f0b-ab2c-e8a176316942	\N	\N	肛门疖肿	JZ_RDYJ	热毒蕴结（一键辨证）	治则：清热解毒，消肿排脓；舌脉：舌红苔黄，脉滑数	{"pain": {"present": true}, "fever": "高热", "pulse_rapid": true, "tongue_color": "红", "anal_swelling": "中度", "tongue_coating": "黄", "stool_condition": "干结"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
4029012a-9816-41f7-9a04-f0fadc78118c	\N	\N	肛门疖肿	JZ_SRJB	湿热搏结（一键辨证）	治则：清热利湿，解毒消肿；舌脉：舌红苔黄腻，脉弦滑	{"secretion": "脓性", "bitter_mouth": true, "anal_swelling": "轻度", "poor_appetite": true, "pulse_slippery": true, "tongue_coating": "黄腻"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
e00f6a5b-d11d-4fa1-ae0c-aaffbdbce564	\N	\N	肛门疣赘	YZ_SRXZ	湿热下注（一键辨证）	治则：清热解毒，利湿散结；舌脉：舌红苔黄腻，脉弦滑	{"odor": "腥臭", "itching": {"present": true}, "secretion": "粘液性", "anal_color": "红", "tongue_color": "红", "pulse_slippery": true, "tongue_coating": "黄腻"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
ddf4132a-ce75-464d-a983-e18257badcb7	\N	\N	肛门疣赘	YZ_QXZH	气滞血瘀（一键辨证）	治则：行气活血，解毒散结；舌脉：舌暗或有瘀斑，脉弦涩	{"pain": {"present": true}, "anal_color": "紫暗", "pulse_wiry": true, "tongue_color": "紫暗"}	system	0	1	2026-08-14 12:16:59.668009+00	\N
a5b54049-9b3b-4bd6-bd35-d6dc34efe022	\N	\N	肛门疣赘	YZ_GSYX	肝肾阴虚（一键辨证）	治则：滋补肝肾；舌脉：舌红苔少，脉细数	{"fatigue": true, "insomnia": true, "pulse_fine": true, "pulse_rapid": true, "tongue_color": "红", "tongue_coating": "少苔", "pale_complexion": true}	system	0	1	2026-08-14 12:16:59.668009+00	\N
adcb5528-c2ee-45c1-93a3-acd87e6fe3ca	\N	\N	痔疮	ZC_VHAN	虚寒证（一键辨证）	治则：健脾温中，固脱止血；舌脉：{'pulse': '脉沉迟或细弱', 'tongue': '舌质淡，苔淡白'}	{"abdomen": "腹胀", "fatigue": true, "bleeding": {"color": "晦暗", "present": true}, "urination": "清长", "pulse_weak": true, "tongue_color": "淡白", "poor_appetite": true, "pale_complexion": true, "stool_condition": "稀软", "prolapse_symptom": {"present": true}}	system	0	1	2026-08-14 12:18:35.805938+00	\N
b602db99-59bd-4b90-9007-d0f6140ded2e	\N	\N	肛瘘	GL_XRNY	虚热内蕴（一键辨证）	治则：滋阴养血，清热通络；舌脉：{'pulse': '脉细弱', 'tongue': '舌质红，苔少或无苔'}	{"fatigue": true, "pulse_fine": true, "pulse_weak": true, "night_sweats": true, "tongue_color": "红", "poor_appetite": true, "tongue_coating": "少苔", "pale_complexion": true}	system	0	1	2026-08-14 12:18:35.805938+00	\N
\.


--
-- Data for Name: syndrome_rules; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.syndrome_rules (id, disease_type, syndrome_name, syndrome_code, required_symptoms, optional_symptoms, tongue_pulse, treatment_principle, recommended_formulas, confidence_threshold, modification_rules, priority, is_active, created_at) FROM stdin;
0ff1b16a-83dd-42ce-af0b-22652c3ae12a	痔疮	实热内蕴，血热肠燥	ZC_SHINY	{"bleeding": {"color": "鲜红", "present": true}, "pulse_rapid": true, "tongue_color": ["红", "深红"], "tongue_coating": ["黄", "黄腻"], "stool_condition": "干结"}	{"pain": {"present": true}, "urination": "短赤", "pulse_wiry": true, "bitter_mouth": true}	{"pulse": "脉弦数或数", "tongue": "舌红苔黄"}	清热止血，润肠通便	[{"name": "槐花散加味", "priority": 1, "match_rate": 0.95}, {"name": "地榆散加味", "priority": 2, "match_rate": 0.85}]	0.7	{"伴湿热": {"add": ["黄柏10克", "苍术10克"]}, "便秘严重": {"add": ["大黄6克(后下)", "芒硝10克"]}, "出血量大": {"add": ["仙鹤草30克", "三七粉3克(冲)"]}, "疼痛明显": {"add": ["延胡索10克", "川楝子10克"]}}	1	1	2026-08-14 12:16:52.712075+00
30478a4e-833d-4d93-a61d-5060f8844732	痔疮	湿热下注，气滞血瘀	ZC_SRXZ	{"pain": {"nature": "胀痛", "present": true}, "pulse_wiry": true, "tongue_color": "红", "pulse_slippery": true, "tongue_coating": ["黄腻", "白厚"], "swelling_symptom": {"present": true}}	{"urination": "短赤", "anal_color": ["暗红", "紫暗"], "bitter_mouth": true, "anal_swelling": ["中度", "重度"], "poor_appetite": true}	{"pulse": "脉弦滑数", "tongue": "舌质红，苔黄腻"}	清热利湿，活血化瘀	[{"name": "五神汤加味", "priority": 1, "match_rate": 0.95}, {"name": "活血散瘀汤", "priority": 2, "match_rate": 0.85}]	0.7	{"便秘": {"add": ["大黄6克(后下)"]}, "湿热重": {"add": ["薏苡仁30克", "白术10克"]}, "疼痛剧烈": {"add": ["白芷10克", "乳香10克", "没药10克"]}, "肿胀明显": {"add": ["泽兰10克", "益母草15克"]}}	1	1	2026-08-14 12:16:52.712075+00
c70c728b-8c31-413b-9e69-bfa385574d8c	痔疮	脾虚气陷	ZC_PXQX	{"fatigue": true, "pulse_weak": true, "tongue_color": ["淡红", "淡白"], "tongue_shape": "胖大齿痕", "poor_appetite": true, "prolapse_symptom": {"degree": ["II度", "III度", "IV度"], "present": true}}	{"bleeding": {"volume": "点滴", "present": true}, "lumbar_soreness": true, "pale_complexion": true, "stool_condition": "溏泄"}	{"pulse": "脉弱或虚", "tongue": "舌淡胖齿痕，苔薄白"}	补中益气，升阳举陷	[{"name": "补中益气汤", "priority": 1, "match_rate": 0.95}]	0.7	{"久泻": {"add": ["煨诃子10克", "石榴皮10克"]}, "便血": {"add": ["白及10克", "仙鹤草20克"]}, "腰酸": {"add": ["杜仲12克", "续断10克"]}, "脱垂严重": {"add": ["补骨脂12克", "肉豆蔻10克", "五倍子10克"]}}	1	1	2026-08-14 12:16:52.712075+00
d7bf531b-e30a-4be2-849e-42bf77c9ae57	痔疮	气滞血瘀	ZC_QZXY	{"pain": {"nature": ["刺痛", "胀痛"], "present": true}, "anal_color": ["紫暗", "暗红"], "pulse_wiry": true}	{"bleeding": {"color": "暗红", "present": true}, "tongue_color": "紫暗", "stool_condition": "干结", "swelling_symptom": {"present": true}}	{"pulse": "脉弦或涩", "tongue": "舌质紫暗或有瘀斑"}	活血化瘀，行气止痛	[{"name": "活血散瘀汤", "priority": 1, "match_rate": 0.9}]	0.65	{"便秘": {"add": ["桃仁12克", "火麻仁15克"]}, "嵌顿": {"add": ["牛膝15克", "红花10克"]}, "血瘀重": {"add": ["三棱10克", "莪术10克"]}, "疼痛剧烈": {"add": ["延胡索12克", "川楝子10克", "白芷10克"]}}	2	1	2026-08-14 12:16:52.712075+00
d0af448c-8bbc-461d-baf4-0bada52ac09f	肛裂	血热肠燥	GL_XRCZ	{"pain": {"nature": ["刺痛", "灼痛"], "timing": "便后持续", "present": true}, "bleeding": {"color": "鲜红", "timing": "便时", "present": true}, "pulse_rapid": true, "tongue_color": ["红", "深红"], "tongue_coating": "黄", "stool_condition": "干结"}	{"thirst": "口渴喜冷饮", "sphincter": "痉挛", "urination": "短赤"}	{"pulse": "脉数", "tongue": "舌红苔黄"}	凉血止血，养阴润燥	[{"name": "凉血地黄汤", "priority": 1, "match_rate": 0.95}]	0.7	{"便秘重": {"add": ["火麻仁15克", "郁李仁10克"]}, "出血多": {"add": ["地榆炭15克", "槐花炭12克"]}, "疼痛剧烈": {"add": ["延胡索10克", "白芷10克"]}, "括约肌痉挛": {"add": ["白芍15克", "甘草10克"]}}	1	1	2026-08-14 12:16:52.712075+00
fbe3a6ad-3114-4a8e-aa2f-66bb51f6b602	肛裂	阴虚津亏	GL_YXJK	{"pain": {"nature": "灼痛", "present": true}, "pulse_fine": true, "tongue_color": "红", "tongue_coating": ["少苔", "无苔"], "stool_condition": "干结"}	{"thirst": "口干不欲饮", "insomnia": true, "lumbar_soreness": true}	{"pulse": "脉细数", "tongue": "舌红少苔或无苔"}	养阴润燥，润肠通便	[{"name": "润肠汤", "priority": 1, "match_rate": 0.9}]	0.65	{"失眠": {"add": ["酸枣仁15克", "柏子仁10克"]}, "腰酸": {"add": ["枸杞子12克", "女贞子12克"]}, "阴虚重": {"add": ["玄参15克", "麦冬15克", "石斛12克"]}, "便秘顽固": {"add": ["肉苁蓉15克", "锁阳12克"]}}	2	1	2026-08-14 12:16:52.712075+00
38b16ec8-9b3b-4544-a8eb-d01d98cbeb43	肛周脓肿	热毒蕴结	GZ_RTYJ	{"pain": {"degree": ["重度", "剧烈"], "nature": "跳痛", "present": true}, "fever": ["高热", "恶寒发热"], "pulse_rapid": true, "tongue_color": "红", "anal_swelling": ["中度", "重度"], "pulse_surging": true, "tongue_coating": "黄腻"}	{"odor": "恶臭", "thirst": "口渴喜冷饮", "urination": "短赤", "stool_condition": "干结"}	{"pulse": "脉洪数或弦数", "tongue": "舌红苔黄腻"}	清泻实热，宣散郁结	[{"name": "内疏黄连汤加减", "priority": 1, "match_rate": 0.95}, {"name": "仙方活命饮", "priority": 2, "match_rate": 0.85}]	0.75	{"便秘": {"add": ["大黄10克(后下)", "芒硝10克(冲)"]}, "高热": {"add": ["石膏30克", "知母12克"]}, "热毒重": {"add": ["蒲公英30克", "紫花地丁20克"]}, "脓肿未溃": {"add": ["皂角刺15克", "穿山甲10克"]}}	1	1	2026-08-14 12:16:52.712075+00
59a86664-e66e-4557-8c42-715e5a288b61	肛门疣赘	湿热下注	YZ_SRXZ	{"secretion": ["粘液性", "脓性"], "anal_color": ["红", "鲜红"]}	{"odor": ["腥臭", "恶臭"], "itching": {"present": true}, "tongue_color": "红", "pulse_slippery": true, "tongue_coating": "黄腻"}	"舌红苔黄腻，脉弦滑"	清热解毒，利湿散结	["萆薢渗湿汤"]	0.6	{}	70	1	2026-08-14 12:16:53.39331+00
142ce84f-a6ec-4811-a778-683bcdc1a453	肛门疣赘	气滞血瘀	YZ_QXZH	{"pain": {"present": true}, "anal_color": ["紫暗", "暗红"]}	{"pain": {"nature": ["刺痛", "胀痛"]}, "pulse_wiry": true, "tongue_color": ["紫暗", "暗红"]}	"舌暗或有瘀斑，脉弦涩"	行气活血，解毒散结	["丹栀逍遥散"]	0.6	{}	65	1	2026-08-14 12:16:53.39331+00
da8d159c-636d-4fbd-86b5-6eafbcbf1897	肛门疖肿	热毒蕴结	JZ_RDYJ	{"pain": {"present": true}, "fever": ["高热", "恶寒发热"], "anal_swelling": ["中度", "重度"]}	{"pulse_rapid": true, "tongue_color": "红", "tongue_coating": ["黄", "黄腻"], "stool_condition": "干结"}	"舌红苔黄，脉滑数"	清热解毒，消肿排脓	["五味消毒饮"]	0.6	{}	70	1	2026-08-14 12:16:53.39331+00
d34ab2d0-2983-49cb-ab45-f5b2983bc0f1	肛门疖肿	湿热搏结	JZ_SRJB	{"secretion": ["脓性", "粘液性"], "anal_swelling": ["轻度", "中度", "重度"]}	{"bitter_mouth": true, "poor_appetite": true, "pulse_slippery": true, "tongue_coating": "黄腻"}	"舌红苔黄腻，脉弦滑"	清热利湿，解毒消肿	["黄芩滑石汤加减"]	0.6	{}	65	1	2026-08-14 12:16:53.39331+00
c6cf3ee2-6757-4110-91e6-471dc9454134	痔疮	湿热瘀滞型	ZC_SRYS	{"pain": {"present": true}, "stool_condition": "干结", "swelling_symptom": {"present": true}}	{"urination": "短赤", "pulse_wiry": true, "bitter_mouth": true, "anal_swelling": ["中度", "重度"], "tongue_coating": ["黄腻", "白厚"]}	"舌质红，苔黄腻，脉弦滑数"	清热除湿，活血化瘀	["五神汤加味", "活血散瘀汤"]	0.65	{"便秘严重": "加大黄10g、芒硝6g增强泻下", "出血量大": "加仙鹤草15g、茜草10g止血", "疼痛剧烈": "加延胡索10g、川楝子10g止痛", "肿胀明显": "加泽兰10g、泽泻12g消肿利湿"}	85	1	2026-08-14 12:16:53.39331+00
371e3b37-a073-478b-82f8-98b1e1ce84b5	肛裂	湿热证	GL_SR	{"pain": {"degree": "重度", "present": true}, "anal_swelling": "中度", "stool_condition": "干结"}	{"secretion": "脓性", "urination": "短赤", "pulse_rapid": true, "bitter_mouth": true, "poor_appetite": true, "tongue_coating": "黄腻"}	"舌质红，苔黄腻，脉滑数"	清热利湿，润燥止痛	["止痛如神汤"]	0.65	{"便秘严重": "重用大黄至15g", "分泌脓液": "加金银花20g、连翘15g", "疼痛剧烈": "加白芷10g、延胡索10g", "肿胀明显": "加泽泻12g、车前子10g"}	75	1	2026-08-14 12:16:53.39331+00
a737d51a-1215-43d0-aa75-cd67fcdc0beb	直肠脱垂	气血两虚型	ZC_QXLX	{"fatigue": true, "pale_complexion": true, "prolapse_symptom": {"degree": "III度", "present": true}}	{"bleeding": {"color": "淡红"}, "insomnia": true, "pulse_fine": true, "pulse_weak": true, "tongue_color": "淡白", "poor_appetite": true}	"舌质淡红，苔薄白，脉细弱"	补气养血，升举固脱	["八珍汤加味", "参茸提肛散"]	0.7	{"便秘": "加肉苁蓉15g、麻仁12g润肠", "气虚明显": "重用黄芪至30g，加升麻6g", "脱垂严重": "加鹿茸4g、补骨脂6g", "血虚明显": "加熟地12g、阿胶12g"}	80	1	2026-08-14 12:16:53.39331+00
50be6ba2-f269-4813-8ad4-40fd94ceef51	直肠脱垂	肺虚咳喘型	ZC_FXKC	{"cough": true, "prolapse_symptom": {"present": true}, "shortness_of_breath": true}	{"fatigue": true, "pulse_weak": true, "tongue_color": "淡", "tongue_coating": "白滑", "pale_complexion": true}	"舌淡，苔白滑，脉沉细略滑"	温肺益气，定喘固脱	["定喘固脱汤"]	0.75	{"肺寒": "加干姜6g、细辛3g温肺", "咳喘严重": "加桑白皮8g、贝母8g", "气虚明显": "重用黄芪至20g", "脱垂严重": "加升麻12g、肉桂6g"}	70	1	2026-08-14 12:16:53.39331+00
48600b69-9d63-4022-a2d3-9cbc8873d8c4	直肠脱垂	小儿气血未壮型	ZCTH_XE	{"age_group": "小儿", "stool_condition": ["溏泄", "腹泻"], "prolapse_symptom": {"present": true}}	{"fatigue": true, "tongue_color": ["淡", "淡白"], "poor_appetite": true, "pale_complexion": true}	"舌淡，脉虚弱"	补中益气，升阳举陷；结合原发腹泻调治	["补中益气汤"]	0.65	{}	71	1	2026-08-14 12:16:56.262833+00
830939bf-3f0c-430e-b51a-f4e258e252f7	肛瘘	化腐期	GL_HFQ	{"wound_phase": "腐肉"}	{"secretion": ["脓性", "血性"]}	"局部创面阶段字段"	保持引流，清除腐败组织；严禁自行探查或腐蚀	[]	0.65	{}	80	1	2026-08-14 12:16:56.262833+00
d92fc088-e90e-4ac5-8191-9bd34f6299c6	肛瘘	托毒期	GL_TDQ	{"wound_phase": "脓液"}	{"secretion": "脓性"}	"局部创面阶段字段"	评估主管、支管和死腔，保证脓毒外泄，防止假愈合	[]	0.65	{}	79	1	2026-08-14 12:16:56.262833+00
6b2dcf99-9a4d-47c7-ad27-9ef6fe184e0f	肛瘘	生肌期	GL_SJQ	{"wound_phase": "肉芽"}	{"secretion": ["无", "血性"]}	"局部创面阶段字段"	腐脱管化后促进新鲜肉芽生长，由专业人员换药	[]	0.65	{}	78	1	2026-08-14 12:16:56.262833+00
a1aeb881-89e7-4984-bd8d-f692bbfd353b	肛周脓肿	虚热型脓肿	GZ_XR	{"fever": "低热", "fatigue": true, "anal_swelling": ["轻度", "中度", "重度"]}	{"pain": {"degree": "轻度"}, "pulse_fine": true, "pulse_weak": true, "night_sweats": true, "tongue_color": "淡", "pale_complexion": true}	"舌质淡，苔薄白，脉弦细弱"	清虚热，散毒气	["青蒿鳖甲汤加减"]	0.7	{"脓未成": "加红花6g、桃仁9g活血消散", "气虚明显": "加黄芪15g、党参12g", "血虚明显": "加当归12g、川芎9g", "阴虚明显": "加麦冬12g、知母10g"}	75	1	2026-08-14 12:16:53.39331+00
e51662d2-6d26-498a-8cb7-8af3344147a5	肛瘘	收口期	GL_SQK	{"wound_phase": "收口"}	{"bridge_adhesion": true}	"局部创面阶段字段"	检查桥形粘连、残余窦道和假愈合，审慎促进收口	[]	0.65	{}	77	1	2026-08-14 12:16:56.262833+00
057e50e5-d200-40a5-a297-2aef1cc59b9c	肛门疣赘	肝肾阴虚	YZ_GSYX	{"tongue_color": "红", "tongue_coating": ["少苔", "无苔"]}	{"fatigue": true, "insomnia": true, "pulse_fine": true, "pulse_rapid": true, "pale_complexion": true}	"舌红苔少，脉细数"	滋补肝肾	["杞菊地黄汤"]	0.6	{"失眠重": "加酸枣仁15g、远志10g安神", "潮热盗汗": "加地骨皮10g、银柴胡10g退虚热", "阴虚明显": "加麦冬12g、玄参12g养阴"}	60	1	2026-08-14 12:16:56.972051+00
d60c9b81-ccc0-4509-8864-53a15532c42b	直肠脱垂	肾虚不固型	ZCTH_SG	{"urination": ["频数", "清长"], "lumbar_soreness": true, "prolapse_symptom": {"present": true}}	{"fatigue": true, "pulse_deep": true, "pale_complexion": true, "stool_condition": ["溏泄", "先干后溏"]}	"舌淡或淡胖，脉沉细/弱"	补肾纳气，温阳固脱	["参蚧散", "补肾固脱散"]	0.65	{"久泻不止": "加肉豆蔻6g、补骨脂10g温脾固涩", "阳虚肢冷": "加肉桂6g、制附片6g（先煎）温阳", "腰膝酸软明显": "加杜仲10g、续断10g补肾强腰"}	72	1	2026-08-14 12:16:56.262833+00
674ea7fb-cc45-4d68-aac0-3a55fa2781c5	直肠脱垂	湿热下注努挣型	ZCTH_SR	{"bitter_mouth": true, "stool_condition": ["干结", "秘结"], "prolapse_symptom": {"present": true}}	{"urination": "短赤", "anal_swelling": ["中度", "重度"], "pulse_slippery": true, "tongue_coating": "黄腻"}	"舌红苔黄腻，脉滑数"	清利湿热，通便降浊，兼顾升提	["升阳除湿汤"]	0.65	{"便溏": "加茯苓12g、泽泻10g分利水湿", "湿热重": "加黄柏10g、苍术10g清利湿热", "下坠明显": "加升麻3g、柴胡6g升阳举陷", "小便不畅": "加车前子10g、木通6g通淋"}	69	1	2026-08-14 12:16:56.262833+00
b7c86c70-9655-4b48-9d11-26919d055e9a	痔疮	气血亏损，气不摄血	ZC_QXKS	{"fatigue": true, "bleeding": {"color": "淡红", "present": true}, "pale_complexion": true}	{"pulse_fine": true, "pulse_weak": true, "tongue_color": "淡白", "poor_appetite": true, "stool_condition": "干结", "prolapse_symptom": {"present": true}}	"舌质淡，苔薄白，脉细弱"	补气益血	["八珍汤", "补中益气汤·痔疮气血亏损", "当归连翘汤"]	0.7	{"气虚明显": "重用黄芪至30g", "脱垂严重": "加升麻12g、柴胡10g升提", "虚中兼湿热": "选当归连翘汤，补虚中兼清湿热和血疏风", "出血日久不止": "加阿胶12g、艾叶炭10g止血"}	80	1	2026-08-14 12:16:52.712075+00
b5f30b0e-8b35-4fcc-a036-42f347c364d7	直肠脱垂	中气下陷	ZC_ZQXX	{"prolapse_symptom": {"present": true}}	{"fatigue": true, "pulse_weak": true, "poor_appetite": true, "pale_complexion": true, "stool_condition": ["溏泄", "腹泻"]}	"舌淡或胖大齿痕，脉虚弱"	补中益气，升阳举陷	["补中益气汤·脱垂中气下陷"]	0.65	{"久泻不止": "加肉豆蔻6g、补骨脂10g温脾固涩", "纳差明显": "加鸡内金10g、麦芽10g健胃消食", "脱垂严重": "加升麻6g、乌梅10g、五味子10g收敛升提"}	74	1	2026-08-14 12:16:52.712075+00
ba873c8b-bf93-485b-ab98-2ec16f1e3879	便秘	胃肠热结	BM_WCRJ	{"tongue_coating": ["黄", "黄燥", "黄腻"], "stool_condition": ["干结", "秘结"]}	{"urination": "短赤", "pulse_rapid": true, "bitter_mouth": true, "pulse_slippery": true}	"舌红苔黄燥，脉滑数"	清热通腑，润肠导滞	["麻子仁丸"]	0.65	{"热结重": "加大黄9g（后下）通腑", "腹胀满甚": "加枳实10g、厚朴10g行气"}	62	1	2026-08-14 12:16:58.354616+00
64055772-2085-4ac5-880f-95ff02b093a8	便秘	气虚便结	BM_QXBJ	{"fatigue": true, "stool_condition": ["干结", "秘结"]}	{"pulse_weak": true, "tongue_color": ["淡", "淡白"], "poor_appetite": true, "pale_complexion": true}	"舌淡苔薄，脉虚"	益气润肠，健脾通便	["黄芪汤", "补中益气汤"]	0.65	{"纳差": "加党参12g、白术12g健脾", "气虚明显": "重用黄芪至30g"}	59	1	2026-08-14 12:16:58.354616+00
9c749901-e267-40f3-bc76-594e208198e4	便秘	气滞不行	BM_QZBX	{"abdomen": "腹胀", "stool_condition": ["干结", "秘结"]}	{"insomnia": true, "pulse_wiry": true, "poor_appetite": true}	"舌淡红苔薄，脉弦"	行气导滞，通便除胀	["六磨汤"]	0.65	{"嗳气频作": "加陈皮10g、半夏9g和胃", "胸胁胀满": "加柴胡10g、香附10g疏肝"}	57	1	2026-08-14 12:16:58.354616+00
20a5a04e-178d-45b1-81c8-a8eebc84a28f	便秘	气血两亏	BM_QXLK	{"fatigue": true, "pale_complexion": true, "stool_condition": ["干结", "秘结"]}	{"insomnia": true, "pulse_fine": true, "pulse_weak": true, "tongue_color": "淡白"}	"舌淡苔薄，脉细弱"	补气养血，润肠通便	["八珍汤", "当归连翘汤"]	0.65	{"便秘重": "加火麻仁15g、肉苁蓉15g润肠", "血虚明显": "加熟地15g、何首乌15g养血"}	61	1	2026-08-14 12:16:58.354616+00
445dc8cb-0557-473c-9fa7-cb7cd8cfc775	便秘	阴虚便结	BM_YXBJ	{"tongue_color": "红", "tongue_coating": ["少苔", "无苔"], "stool_condition": ["干结", "秘结"]}	{"fever": "潮热", "insomnia": true, "pulse_fine": true, "pulse_rapid": true}	"舌红少苔，脉细数"	滋阴润肠，增水行舟	["增液汤", "麻仁滋脾丸"]	0.65	{"五心烦热": "加地骨皮10g、银柴胡10g退虚热", "便如羊屎": "加火麻仁15g、郁李仁12g润肠"}	60	1	2026-08-14 12:16:58.354616+00
24b33fe0-ef99-46ee-be50-84ce909ff3b3	肛门湿疹	湿热下注	SZ_SRXZ	{"itching": {"present": true}, "tongue_coating": ["黄腻", "黄"]}	{"urination": "短赤", "pulse_wiry": true, "bitter_mouth": true, "tongue_color": "红", "pulse_slippery": true}	"舌红苔黄腻，脉弦滑"	清热利湿，祛风止痒	["萆薢渗湿汤", "三妙丸"]	0.65	{"瘙痒剧烈": "加白鲜皮15g、地肤子10g止痒", "渗出糜烂重": "加薏苡仁15g、土茯苓15g利湿"}	60	1	2026-08-14 12:16:58.354616+00
3bf533ea-28fa-4ed3-9d6a-d2896d29036a	肛门湿疹	血虚风燥	SZ_XSFZ	{"itching": {"present": true}, "pale_complexion": true}	{"fatigue": true, "insomnia": true, "pulse_fine": true, "tongue_color": ["淡", "淡白"]}	"舌淡苔薄，脉细"	养血润燥，祛风止痒	["当归饮子"]	0.65	{"入夜痒甚": "加酸枣仁15g、夜交藤15g安神", "皮肤干燥肥厚": "加玄参15g、天花粉15g润燥"}	58	1	2026-08-14 12:16:58.354616+00
067a735a-c9ee-4516-9aca-383e2dd9c653	肛门湿疹	中气下陷（脾虚湿蕴）	SZ_ZQXJ	{"fatigue": true, "itching": {"present": true}, "poor_appetite": true}	{"pulse_weak": true, "tongue_color": ["淡", "淡白"], "pale_complexion": true, "stool_condition": "溏泄"}	"舌淡苔薄，脉弱"	补中益气，升阳举陷，兼清湿热	["补中益气汤", "三妙丸"]	0.65	{"兼湿热": "合三妙丸清利湿热", "下坠明显": "加升麻6g、柴胡6g升阳"}	59	1	2026-08-14 12:16:58.354616+00
313f5825-6699-4414-a676-26d3a7df9136	便秘	大肠津亏	BM_DCJJ	{"tongue_coating": ["少苔", "无苔"], "stool_condition": ["干结", "秘结"]}	{"thirst": ["口干不欲饮", "口渴喜热饮"], "pulse_fine": true, "tongue_color": "红"}	"舌红少津，脉细"	增液润肠，通便导下	["增液汤", "麻仁润肠丸"]	0.65	{"便结难解": "加火麻仁15g、郁李仁12g润肠", "口干明显": "加天花粉15g、石斛12g生津"}	60	1	2026-08-14 12:16:58.354616+00
cab1a53b-a1cd-4dd6-95ab-2c9ae5882e3f	便秘	大肠寒结	BM_DCHJ	{"tongue_coating": ["白滑", "白厚", "薄白"], "stool_condition": ["秘结", "干结"]}	{"abdomen": "腹胀", "pulse_deep": true, "pulse_slow": true}	"舌淡苔白滑，脉沉迟"	温里散寒，通便止痛	["大黄附子汤"]	0.65	{"寒甚": "加附子6g（先煎）", "腹冷痛明显": "加干姜6g、肉桂6g温中"}	58	1	2026-08-14 12:16:58.354616+00
87af854a-94e8-4699-89a6-b9a7887d52e8	痔疮	虚寒证	ZC_VHAN	{"fatigue": true, "bleeding": {"color": "晦暗", "present": true}, "pale_complexion": true, "stool_condition": "稀软"}	{"abdomen": "腹胀", "urination": "清长", "pulse_weak": true, "tongue_color": "淡白", "poor_appetite": true, "prolapse_symptom": {"present": true}}	{"pulse": "脉沉迟或细弱", "tongue": "舌质淡，苔淡白"}	健脾温中，固脱止血	["归脾汤加味", "黄芪建中汤加减"]	0.65	{"腹泻": "加煨葛根12g、炒白芍10g止泻", "消化不良": "加砂仁6g、木香6g健脾和胃", "长期便血": "加灶心土30g、陈棕炭10g固脱止血", "内痔脱出严重": "加升麻10g、柴胡10g升提"}	75	1	2026-08-14 12:18:26.076603+00
bdb54efc-821b-4d8f-a3dd-3395fca793a5	肛瘘	虚热内蕴	GL_XRNY	{"fatigue": true, "pale_complexion": true}	{"pulse_fine": true, "pulse_weak": true, "night_sweats": true, "tongue_color": "红", "poor_appetite": true, "tongue_coating": ["少苔", "无苔"]}	{"pulse": "脉细弱", "tongue": "舌质红，苔少或无苔"}	滋阴养血，清热通络	["当归连翘汤", "八珍汤加减"]	0.65	{"懒言乏力": "加白术10g、茯苓12g健脾益气", "潮热盗汗": "加地骨皮10g、青蒿10g清虚热", "肉芽不良": "加鸡血藤15g、丹参12g活血通络", "脓汁清稀": "加黄芪15g、党参12g托脓外出"}	70	1	2026-08-14 12:18:26.076603+00
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.tenants (id, name, plan, trial_end, contact_phone, address, created_at, updated_at) FROM stdin;
bfc0ce8c-1969-404a-87d6-bce21c1db7f3	痔漏专科诊所（演示）	pro	2027-08-14 12:16:08.022215+00	\N	\N	2026-08-14 12:16:08.907294+00	2026-08-14 12:16:08.907299+00
31aba808-467e-40a0-ad5e-f1b02056d3bb	中医	trial	2026-09-13 12:34:09.533646+00	\N	\N	2026-08-14 12:34:09.534956+00	2026-08-14 12:34:09.53496+00
7357f285-a665-412e-a958-613daf0e32be	888	trial	2026-09-14 03:37:25.682557+00	\N	\N	2026-08-15 03:37:25.683993+00	2026-08-15 03:37:25.683996+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: zhilou_user
--

COPY public.users (id, tenant_id, email, name, hashed_password, role, is_active, phone, created_at, updated_at) FROM stdin;
ca25f243-12c2-46a8-9d0c-e5dcc98be37b	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	admin@zhilou.com	管理员	$2b$12$YKOSQyyqX09rIO6u1.Q0PON/IuOGU08M5DnpNxU0tYUWqDSDzuH9.	admin	t	\N	2026-08-14 12:16:08.910354+00	2026-08-14 12:16:08.910358+00
2f876a37-a243-4f79-94d7-7683870d2e13	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	doctor@zhilou.com	周医师	$2b$12$br.zq502bPnP2pwUoQndJe7OBoSl0IIL9fZ54UAYHJ.kuy7CglNWG	doctor	t	\N	2026-08-14 12:16:08.910361+00	2026-08-14 12:16:08.910362+00
ec6379e6-960a-4bf0-a814-f7da324bab43	bfc0ce8c-1969-404a-87d6-bce21c1db7f3	cashier@zhilou.com	收银员	$2b$12$QKfTW4L3NOsWwsgy2ilUZe68s9Ffwd1rvA/jwgq.GxtitCpKvw4qq	cashier	t	\N	2026-08-14 12:16:08.910363+00	2026-08-14 12:16:08.910364+00
7c84d784-5bfb-4eb5-97d9-055d4431fc42	31aba808-467e-40a0-ad5e-f1b02056d3bb	2634556737@qq.com	laozhenghua	$2b$12$HCa9S.L9bdN1q9vtr/9z7Oivn8PhNIRHbq8Y8wm4FrAb//ArYDH/y	admin	t	\N	2026-08-14 12:34:09.84195+00	2026-08-14 12:34:09.841955+00
78af4e74-08e3-4d4a-8219-6d189e606fb0	7357f285-a665-412e-a958-613daf0e32be	123038383@qq.com	lzh	$2b$12$ghnRJ8ngpUeUJfFbGUq7iO3w.j8zeOa7DYI0e3EEIVOY9Y3bbo/.q	admin	t	\N	2026-08-15 03:37:25.968864+00	2026-08-15 03:37:25.968869+00
\.


--
-- Name: anorectal_cases anorectal_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.anorectal_cases
    ADD CONSTRAINT anorectal_cases_pkey PRIMARY KEY (id);


--
-- Name: anorectal_formulas anorectal_formulas_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.anorectal_formulas
    ADD CONSTRAINT anorectal_formulas_pkey PRIMARY KEY (id);


--
-- Name: anorectal_herbs anorectal_herbs_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.anorectal_herbs
    ADD CONSTRAINT anorectal_herbs_pkey PRIMARY KEY (id);


--
-- Name: bill_items bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_pkey PRIMARY KEY (id);


--
-- Name: bill_payments bill_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_pkey PRIMARY KEY (id);


--
-- Name: bills bills_bill_no_key; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_bill_no_key UNIQUE (bill_no);


--
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (id);


--
-- Name: charge_items charge_items_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.charge_items
    ADD CONSTRAINT charge_items_pkey PRIMARY KEY (id);


--
-- Name: consultations consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_pkey PRIMARY KEY (id);


--
-- Name: daily_revenue daily_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.daily_revenue
    ADD CONSTRAINT daily_revenue_pkey PRIMARY KEY (id);


--
-- Name: diagnosis_records diagnosis_records_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.diagnosis_records
    ADD CONSTRAINT diagnosis_records_pkey PRIMARY KEY (id);


--
-- Name: external_treatment_records external_treatment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.external_treatment_records
    ADD CONSTRAINT external_treatment_records_pkey PRIMARY KEY (id);


--
-- Name: external_treatments external_treatments_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.external_treatments
    ADD CONSTRAINT external_treatments_pkey PRIMARY KEY (id);


--
-- Name: followups followups_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.followups
    ADD CONSTRAINT followups_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: medical_cases medical_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.medical_cases
    ADD CONSTRAINT medical_cases_pkey PRIMARY KEY (id);


--
-- Name: medicine_batches medicine_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.medicine_batches
    ADD CONSTRAINT medicine_batches_pkey PRIMARY KEY (id);


--
-- Name: medicines medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: prescriptions prescriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_pkey PRIMARY KEY (id);


--
-- Name: prevention_guides prevention_guides_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.prevention_guides
    ADD CONSTRAINT prevention_guides_pkey PRIMARY KEY (id);


--
-- Name: safety_rules safety_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.safety_rules
    ADD CONSTRAINT safety_rules_pkey PRIMARY KEY (id);


--
-- Name: stock_alerts stock_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.stock_alerts
    ADD CONSTRAINT stock_alerts_pkey PRIMARY KEY (id);


--
-- Name: stock_transactions stock_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_pkey PRIMARY KEY (id);


--
-- Name: symptom_dictionary symptom_dictionary_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.symptom_dictionary
    ADD CONSTRAINT symptom_dictionary_pkey PRIMARY KEY (id);


--
-- Name: symptom_templates symptom_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.symptom_templates
    ADD CONSTRAINT symptom_templates_pkey PRIMARY KEY (id);


--
-- Name: syndrome_rules syndrome_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.syndrome_rules
    ADD CONSTRAINT syndrome_rules_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_anorectal_cases_disease_type; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_anorectal_cases_disease_type ON public.anorectal_cases USING btree (disease_type);


--
-- Name: ix_anorectal_cases_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_anorectal_cases_tenant_id ON public.anorectal_cases USING btree (tenant_id);


--
-- Name: ix_anorectal_formulas_name; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_anorectal_formulas_name ON public.anorectal_formulas USING btree (name);


--
-- Name: ix_anorectal_formulas_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_anorectal_formulas_tenant_id ON public.anorectal_formulas USING btree (tenant_id);


--
-- Name: ix_anorectal_herbs_name; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_anorectal_herbs_name ON public.anorectal_herbs USING btree (name);


--
-- Name: ix_anorectal_herbs_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_anorectal_herbs_tenant_id ON public.anorectal_herbs USING btree (tenant_id);


--
-- Name: ix_bill_items_bill_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_bill_items_bill_id ON public.bill_items USING btree (bill_id);


--
-- Name: ix_bill_payments_bill_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_bill_payments_bill_id ON public.bill_payments USING btree (bill_id);


--
-- Name: ix_bill_payments_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_bill_payments_tenant_id ON public.bill_payments USING btree (tenant_id);


--
-- Name: ix_bills_patient_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_bills_patient_id ON public.bills USING btree (patient_id);


--
-- Name: ix_bills_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_bills_tenant_id ON public.bills USING btree (tenant_id);


--
-- Name: ix_charge_items_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_charge_items_tenant_id ON public.charge_items USING btree (tenant_id);


--
-- Name: ix_consultations_patient_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_consultations_patient_id ON public.consultations USING btree (patient_id);


--
-- Name: ix_consultations_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_consultations_tenant_id ON public.consultations USING btree (tenant_id);


--
-- Name: ix_daily_revenue_date; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_daily_revenue_date ON public.daily_revenue USING btree (date);


--
-- Name: ix_daily_revenue_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_daily_revenue_tenant_id ON public.daily_revenue USING btree (tenant_id);


--
-- Name: ix_external_treatment_records_consultation_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_external_treatment_records_consultation_id ON public.external_treatment_records USING btree (consultation_id);


--
-- Name: ix_external_treatment_records_patient_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_external_treatment_records_patient_id ON public.external_treatment_records USING btree (patient_id);


--
-- Name: ix_external_treatment_records_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_external_treatment_records_tenant_id ON public.external_treatment_records USING btree (tenant_id);


--
-- Name: ix_external_treatments_name; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_external_treatments_name ON public.external_treatments USING btree (name);


--
-- Name: ix_external_treatments_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_external_treatments_tenant_id ON public.external_treatments USING btree (tenant_id);


--
-- Name: ix_external_treatments_treatment_type; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_external_treatments_treatment_type ON public.external_treatments USING btree (treatment_type);


--
-- Name: ix_followups_patient_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_followups_patient_id ON public.followups USING btree (patient_id);


--
-- Name: ix_followups_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_followups_tenant_id ON public.followups USING btree (tenant_id);


--
-- Name: ix_images_consultation_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_images_consultation_id ON public.images USING btree (consultation_id);


--
-- Name: ix_images_patient_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_images_patient_id ON public.images USING btree (patient_id);


--
-- Name: ix_images_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_images_tenant_id ON public.images USING btree (tenant_id);


--
-- Name: ix_medical_cases_case_number; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE UNIQUE INDEX ix_medical_cases_case_number ON public.medical_cases USING btree (case_number);


--
-- Name: ix_medical_cases_disease_type; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_medical_cases_disease_type ON public.medical_cases USING btree (disease_type);


--
-- Name: ix_medical_cases_is_classic; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_medical_cases_is_classic ON public.medical_cases USING btree (is_classic);


--
-- Name: ix_medical_cases_syndrome_type; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_medical_cases_syndrome_type ON public.medical_cases USING btree (syndrome_type);


--
-- Name: ix_medicine_batches_expiry_date; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_medicine_batches_expiry_date ON public.medicine_batches USING btree (expiry_date);


--
-- Name: ix_medicine_batches_medicine_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_medicine_batches_medicine_id ON public.medicine_batches USING btree (medicine_id);


--
-- Name: ix_medicine_batches_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_medicine_batches_tenant_id ON public.medicine_batches USING btree (tenant_id);


--
-- Name: ix_medicines_name; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_medicines_name ON public.medicines USING btree (name);


--
-- Name: ix_medicines_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_medicines_tenant_id ON public.medicines USING btree (tenant_id);


--
-- Name: ix_patients_phone; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_patients_phone ON public.patients USING btree (phone);


--
-- Name: ix_patients_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_patients_tenant_id ON public.patients USING btree (tenant_id);


--
-- Name: ix_prescriptions_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_prescriptions_tenant_id ON public.prescriptions USING btree (tenant_id);


--
-- Name: ix_prevention_guides_disease_type; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_prevention_guides_disease_type ON public.prevention_guides USING btree (disease_type);


--
-- Name: ix_prevention_guides_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_prevention_guides_tenant_id ON public.prevention_guides USING btree (tenant_id);


--
-- Name: ix_stock_alerts_medicine_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_stock_alerts_medicine_id ON public.stock_alerts USING btree (medicine_id);


--
-- Name: ix_stock_alerts_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_stock_alerts_tenant_id ON public.stock_alerts USING btree (tenant_id);


--
-- Name: ix_stock_transactions_medicine_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_stock_transactions_medicine_id ON public.stock_transactions USING btree (medicine_id);


--
-- Name: ix_stock_transactions_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_stock_transactions_tenant_id ON public.stock_transactions USING btree (tenant_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_tenant_id; Type: INDEX; Schema: public; Owner: zhilou_user
--

CREATE INDEX ix_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: anorectal_cases anorectal_cases_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.anorectal_cases
    ADD CONSTRAINT anorectal_cases_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: anorectal_formulas anorectal_formulas_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.anorectal_formulas
    ADD CONSTRAINT anorectal_formulas_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: anorectal_herbs anorectal_herbs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.anorectal_herbs
    ADD CONSTRAINT anorectal_herbs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: bill_items bill_items_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.bills(id);


--
-- Name: bill_items bill_items_charge_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_charge_item_id_fkey FOREIGN KEY (charge_item_id) REFERENCES public.charge_items(id);


--
-- Name: bill_payments bill_payments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.bills(id);


--
-- Name: bill_payments bill_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: bill_payments bill_payments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: bills bills_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id);


--
-- Name: bills bills_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: bills bills_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: bills bills_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: charge_items charge_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.charge_items
    ADD CONSTRAINT charge_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: consultations consultations_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.users(id);


--
-- Name: consultations consultations_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: consultations consultations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: daily_revenue daily_revenue_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.daily_revenue
    ADD CONSTRAINT daily_revenue_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: diagnosis_records diagnosis_records_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.diagnosis_records
    ADD CONSTRAINT diagnosis_records_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id);


--
-- Name: diagnosis_records diagnosis_records_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.diagnosis_records
    ADD CONSTRAINT diagnosis_records_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: external_treatment_records external_treatment_records_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.external_treatment_records
    ADD CONSTRAINT external_treatment_records_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id);


--
-- Name: external_treatment_records external_treatment_records_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.external_treatment_records
    ADD CONSTRAINT external_treatment_records_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: external_treatment_records external_treatment_records_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.external_treatment_records
    ADD CONSTRAINT external_treatment_records_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: external_treatment_records external_treatment_records_treatment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.external_treatment_records
    ADD CONSTRAINT external_treatment_records_treatment_id_fkey FOREIGN KEY (treatment_id) REFERENCES public.external_treatments(id);


--
-- Name: external_treatments external_treatments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.external_treatments
    ADD CONSTRAINT external_treatments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: followups followups_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.followups
    ADD CONSTRAINT followups_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id);


--
-- Name: followups followups_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.followups
    ADD CONSTRAINT followups_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.users(id);


--
-- Name: followups followups_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.followups
    ADD CONSTRAINT followups_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: followups followups_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.followups
    ADD CONSTRAINT followups_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: images images_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id);


--
-- Name: images images_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: images images_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: medical_cases medical_cases_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.medical_cases
    ADD CONSTRAINT medical_cases_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: medicine_batches medicine_batches_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.medicine_batches
    ADD CONSTRAINT medicine_batches_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id);


--
-- Name: medicine_batches medicine_batches_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.medicine_batches
    ADD CONSTRAINT medicine_batches_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: medicines medicines_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: patients patients_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.users(id);


--
-- Name: patients patients_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: prescriptions prescriptions_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id);


--
-- Name: prescriptions prescriptions_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.users(id);


--
-- Name: prescriptions prescriptions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- Name: prescriptions prescriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: prevention_guides prevention_guides_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.prevention_guides
    ADD CONSTRAINT prevention_guides_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: stock_alerts stock_alerts_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.stock_alerts
    ADD CONSTRAINT stock_alerts_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id);


--
-- Name: stock_alerts stock_alerts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.stock_alerts
    ADD CONSTRAINT stock_alerts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: stock_transactions stock_transactions_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.medicine_batches(id);


--
-- Name: stock_transactions stock_transactions_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicines(id);


--
-- Name: stock_transactions stock_transactions_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id);


--
-- Name: stock_transactions stock_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zhilou_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 6MI1mXOh0IInO3lbnpTavmZYQ6czEELev4XphexGEYcbcgvm6AlTxL0aA5XVwmf

