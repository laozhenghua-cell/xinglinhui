from .user import User
from .patient import Patient
from .ulcer_consultation import UlcerConsultation
from .ulcer_image import UlcerImage
from .ulcer_knowledge import UlcerKnowledge
from .consultation_request import ConsultationRequest
from .expert_response import ExpertResponse
from .expert_profile import ExpertProfile
from .treatment_outcome import TreatmentOutcome

__all__ = [
    "User",
    "Patient",
    "UlcerConsultation",
    "UlcerImage",
    "UlcerKnowledge",
    "ConsultationRequest",
    "ExpertResponse",
    "ExpertProfile",
    "TreatmentOutcome",
]
